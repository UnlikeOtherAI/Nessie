--
-- PostgreSQL database dump
--

\restrict rKXiwBraP3bBVLfCuv48jU310eumMq4qcN1pxwrZbKkh0s04DkqaGxo7ODyVvJn

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: AgentDelegationMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentDelegationMode" AS ENUM (
    'none',
    'act_as_requesting_user'
);


--
-- Name: AgentEffort; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentEffort" AS ENUM (
    'low',
    'medium',
    'high',
    'xhigh'
);


--
-- Name: AgentExecutionMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentExecutionMode" AS ENUM (
    'inference',
    'external_mcp'
);


--
-- Name: AgentKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentKind" AS ENUM (
    'shared',
    'personal_assistant'
);


--
-- Name: AgentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentStatus" AS ENUM (
    'idle',
    'thinking',
    'executing',
    'waiting_approval',
    'error',
    'offline'
);


--
-- Name: AgentSurfacePolicy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentSurfacePolicy" AS ENUM (
    'shared',
    'dm_only'
);


--
-- Name: AgentTriggerDeliveryStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentTriggerDeliveryStatus" AS ENUM (
    'pending',
    'delivered',
    'failed',
    'skipped'
);


--
-- Name: AgentTriggerStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentTriggerStatus" AS ENUM (
    'active',
    'paused',
    'error'
);


--
-- Name: AgentTriggerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentTriggerType" AS ENUM (
    'manual',
    'scheduled',
    'webhook',
    'event',
    'interval'
);


--
-- Name: ApprovalStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ApprovalStatus" AS ENUM (
    'pending',
    'approved',
    'rejected',
    'expired'
);


--
-- Name: AuditActorType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditActorType" AS ENUM (
    'user',
    'agent',
    'service',
    'system'
);


--
-- Name: AuditOutcome; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditOutcome" AS ENUM (
    'success',
    'denied',
    'error'
);


--
-- Name: BoardStyle; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BoardStyle" AS ENUM (
    'kanban',
    'scrum'
);


--
-- Name: BudgetMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BudgetMode" AS ENUM (
    'off',
    'warn',
    'enforce',
    'degrade',
    'unlimited'
);


--
-- Name: BudgetPeriod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BudgetPeriod" AS ENUM (
    'weekly',
    'monthly',
    'yearly'
);


--
-- Name: BudgetScopeType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BudgetScopeType" AS ENUM (
    'organization',
    'project',
    'team'
);


--
-- Name: ChannelSystemType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ChannelSystemType" AS ENUM (
    'personal_assistant',
    'external_agent'
);


--
-- Name: ChannelType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ChannelType" AS ENUM (
    'standard',
    'dm'
);


--
-- Name: ChannelVisibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ChannelVisibility" AS ENUM (
    'public',
    'protected',
    'private'
);


--
-- Name: ColumnCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ColumnCategory" AS ENUM (
    'todo',
    'in_progress',
    'review',
    'done'
);


--
-- Name: CommsConnectionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommsConnectionStatus" AS ENUM (
    'active',
    'needs_reauthorization',
    'disconnected',
    'error'
);


--
-- Name: CommsProvider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommsProvider" AS ENUM (
    'slack',
    'google',
    'microsoft'
);


--
-- Name: CommsSubscriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommsSubscriptionStatus" AS ENUM (
    'active',
    'expired',
    'failed'
);


--
-- Name: CommsSyncPhase; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommsSyncPhase" AS ENUM (
    'history',
    'incremental',
    'reconciliation'
);


--
-- Name: CommsSyncStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommsSyncStatus" AS ENUM (
    'pending',
    'running',
    'completed',
    'failed'
);


--
-- Name: ConnectorType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ConnectorType" AS ENUM (
    'mcp',
    'http',
    'web_search',
    'web_fetch',
    'storage',
    'push',
    'github',
    'oauth',
    'other'
);


--
-- Name: DevicePlatform; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DevicePlatform" AS ENUM (
    'ios',
    'android'
);


--
-- Name: ExecutionEnvironmentInstanceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExecutionEnvironmentInstanceStatus" AS ENUM (
    'pending',
    'provisioning',
    'ready',
    'failed',
    'terminated'
);


--
-- Name: ExecutionLeaseStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExecutionLeaseStatus" AS ENUM (
    'issued',
    'acknowledged',
    'completed',
    'revoked',
    'expired'
);


--
-- Name: ExecutionMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExecutionMode" AS ENUM (
    'container',
    'vm',
    'function'
);


--
-- Name: ExecutionProvider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExecutionProvider" AS ENUM (
    'docker',
    'gcloud'
);


--
-- Name: ExecutionRunnerStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExecutionRunnerStatus" AS ENUM (
    'active',
    'draining',
    'offline'
);


--
-- Name: FavoriteTargetType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FavoriteTargetType" AS ENUM (
    'agent',
    'channel',
    'user'
);


--
-- Name: InferenceCapabilitySource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceCapabilitySource" AS ENUM (
    'static',
    'live',
    'manual'
);


--
-- Name: InferenceConnectorKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceConnectorKind" AS ENUM (
    'compiled',
    'openai-compatible'
);


--
-- Name: InferenceExposure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceExposure" AS ENUM (
    'standard',
    'admin-only'
);


--
-- Name: InferenceHealthStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceHealthStatus" AS ENUM (
    'healthy',
    'degraded',
    'unreachable',
    'unknown'
);


--
-- Name: InferenceLifecycleStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceLifecycleStatus" AS ENUM (
    'draft',
    'approved',
    'deprecated'
);


--
-- Name: InferenceRoutingMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceRoutingMode" AS ENUM (
    'single',
    'fallback',
    'committee',
    'pipeline',
    'shadow'
);


--
-- Name: InferenceStageRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceStageRole" AS ENUM (
    'advisor',
    'executor',
    'synthesizer',
    'judge',
    'shadow'
);


--
-- Name: InferenceStreamPolicy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InferenceStreamPolicy" AS ENUM (
    'primary-only',
    'buffered-judge'
);


--
-- Name: IntegratedProductAuthMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."IntegratedProductAuthMode" AS ENUM (
    'uoa_sso',
    'api_key',
    'oauth_mcp',
    'local_mcp'
);


--
-- Name: IntegratedProductCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."IntegratedProductCategory" AS ENUM (
    'research',
    'security',
    'development',
    'project_management'
);


--
-- Name: IntegratedProductHealthStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."IntegratedProductHealthStatus" AS ENUM (
    'unknown',
    'healthy',
    'degraded',
    'unreachable',
    'setup_required'
);


--
-- Name: IntegratedProductInstallState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."IntegratedProductInstallState" AS ENUM (
    'link_only',
    'installable',
    'native'
);


--
-- Name: IterationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."IterationStatus" AS ENUM (
    'planned',
    'active',
    'completed'
);


--
-- Name: KnowledgeAnnotationKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KnowledgeAnnotationKind" AS ENUM (
    'comment',
    'note'
);


--
-- Name: KnowledgeAnnotationState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KnowledgeAnnotationState" AS ENUM (
    'open',
    'resolved'
);


--
-- Name: KnowledgeAuthorType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KnowledgeAuthorType" AS ENUM (
    'user',
    'agent'
);


--
-- Name: KnowledgePageKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KnowledgePageKind" AS ENUM (
    'document',
    'file'
);


--
-- Name: KnowledgePageStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KnowledgePageStatus" AS ENUM (
    'draft',
    'published',
    'archived'
);


--
-- Name: MailboxMessageStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MailboxMessageStatus" AS ENUM (
    'queued',
    'processing',
    'delivered',
    'dead_letter'
);


--
-- Name: McpCatalogAuthMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpCatalogAuthMethod" AS ENUM (
    'api_key',
    'bearer',
    'basic',
    'oauth2',
    'none'
);


--
-- Name: McpCatalogProtocol; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpCatalogProtocol" AS ENUM (
    'stdio',
    'http',
    'sse',
    'ws'
);


--
-- Name: McpCatalogStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpCatalogStatus" AS ENUM (
    'draft',
    'pending_approval',
    'published',
    'rejected',
    'deprecated'
);


--
-- Name: McpCatalogVisibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpCatalogVisibility" AS ENUM (
    'private',
    'public'
);


--
-- Name: McpCredentialPrincipalType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpCredentialPrincipalType" AS ENUM (
    'user',
    'agent',
    'channel',
    'team',
    'project',
    'organization'
);


--
-- Name: McpServerLifecycleState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpServerLifecycleState" AS ENUM (
    'pending_setup',
    'active',
    'paused',
    'error'
);


--
-- Name: McpServerScopeType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."McpServerScopeType" AS ENUM (
    'system',
    'organization',
    'project',
    'team',
    'channel',
    'user'
);


--
-- Name: MemberRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MemberRole" AS ENUM (
    'owner',
    'admin',
    'member',
    'viewer'
);


--
-- Name: MessageRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageRole" AS ENUM (
    'user',
    'assistant',
    'system'
);


--
-- Name: OperationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OperationType" AS ENUM (
    'chat',
    'completion',
    'embedding',
    'translation',
    'reasoning',
    'tool-translation',
    'other'
);


--
-- Name: OutcomeStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OutcomeStatus" AS ENUM (
    'pending',
    'successful',
    'partially',
    'failed',
    'superseded'
);


--
-- Name: PlanStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanStatus" AS ENUM (
    'draft',
    'active',
    'waiting',
    'completed',
    'failed',
    'cancelled'
);


--
-- Name: PlanStepStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanStepStatus" AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'skipped',
    'blocked'
);


--
-- Name: PolicyAction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PolicyAction" AS ENUM (
    'view',
    'invoke',
    'create',
    'edit',
    'assign',
    'approve',
    'review',
    'search',
    'export',
    'admin',
    'resolve',
    'rotate',
    'revoke',
    'bind',
    'link',
    'reindex',
    'summarize',
    'read',
    'import',
    'grant',
    'enroll',
    'challenge'
);


--
-- Name: PolicyEffect; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PolicyEffect" AS ENUM (
    'allow',
    'deny'
);


--
-- Name: PolicyResourceType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PolicyResourceType" AS ENUM (
    'agent',
    'channel',
    'project',
    'tool',
    'session',
    'task',
    'review',
    'approval',
    'admin',
    'secret',
    'knowledge_space',
    'knowledge_page'
);


--
-- Name: PolicyScope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PolicyScope" AS ENUM (
    'organization',
    'project',
    'team',
    'channel',
    'agent',
    'tool',
    'user'
);


--
-- Name: PricingSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PricingSource" AS ENUM (
    'provider-default',
    'org-override',
    'team-override',
    'manual'
);


--
-- Name: ProductAccountLinkStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductAccountLinkStatus" AS ENUM (
    'linked',
    'needs_auth',
    'revoked',
    'error'
);


--
-- Name: ProductIntegrationRunStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductIntegrationRunStatus" AS ENUM (
    'queued',
    'running',
    'needs_setup',
    'completed',
    'failed',
    'warning'
);


--
-- Name: PushApnsEnvironment; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushApnsEnvironment" AS ENUM (
    'sandbox',
    'production'
);


--
-- Name: PushDeliveryStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushDeliveryStatus" AS ENUM (
    'sent',
    'failed',
    'dead'
);


--
-- Name: PushProvider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushProvider" AS ENUM (
    'apns',
    'fcm',
    'webpush'
);


--
-- Name: ReasoningType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReasoningType" AS ENUM (
    'decision',
    'evaluation',
    'constraint',
    'pattern',
    'correction',
    'validation'
);


--
-- Name: ResourceLockType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ResourceLockType" AS ENUM (
    'exclusive',
    'shared'
);


--
-- Name: RunStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RunStatus" AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'cancelled',
    'waiting_approval'
);


--
-- Name: SensitivityTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SensitivityTier" AS ENUM (
    'normal',
    'sensitive',
    'restricted'
);


--
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


--
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'inbox',
    'assigned',
    'in_progress',
    'review',
    'done',
    'failed',
    'cancelled',
    'awaiting_approval'
);


--
-- Name: ThoughtAudienceType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ThoughtAudienceType" AS ENUM (
    'user',
    'channel',
    'team',
    'project',
    'organization'
);


--
-- Name: ThoughtLinkRelation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ThoughtLinkRelation" AS ENUM (
    'supersedes',
    'derived_from',
    'contradicts',
    'supports',
    'relates_to'
);


--
-- Name: ThoughtMemoryCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ThoughtMemoryCategory" AS ENUM (
    'intent',
    'reason',
    'constraint',
    'preference',
    'fact'
);


--
-- Name: ThoughtMemoryType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ThoughtMemoryType" AS ENUM (
    'episodic',
    'semantic',
    'procedural'
);


--
-- Name: ThoughtOwnerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ThoughtOwnerType" AS ENUM (
    'user',
    'agent',
    'service'
);


--
-- Name: ThoughtVisibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ThoughtVisibility" AS ENUM (
    'private',
    'channel',
    'team',
    'project',
    'organization'
);


--
-- Name: ToolBundleStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ToolBundleStatus" AS ENUM (
    'pending_review',
    'approved',
    'rejected',
    'disabled'
);


--
-- Name: ToolGrantSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ToolGrantSource" AS ENUM (
    'role',
    'agent-override'
);


--
-- Name: ToolGrantState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ToolGrantState" AS ENUM (
    'inherit',
    'allowed',
    'denied'
);


--
-- Name: ToolRegistryEntryStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ToolRegistryEntryStatus" AS ENUM (
    'active',
    'pending_review',
    'disabled'
);


--
-- Name: ToolRegistrySource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ToolRegistrySource" AS ENUM (
    'builtin',
    'custom',
    'mcp-remote',
    'interactive-session'
);


--
-- Name: ToolRegistryTransport; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ToolRegistryTransport" AS ENUM (
    'direct',
    'mcp',
    'http',
    'stdio',
    'pty'
);


--
-- Name: UserPresenceManualState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserPresenceManualState" AS ENUM (
    'active',
    'away'
);


--
-- Name: UserStatusRuleScope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatusRuleScope" AS ENUM (
    'fallback',
    'channel',
    'project'
);


--
-- Name: UserStatusScheduleKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatusScheduleKind" AS ENUM (
    'date_range',
    'weekly'
);


--
-- Name: WorkflowInstallationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkflowInstallationStatus" AS ENUM (
    'draft',
    'active',
    'paused',
    'disabled'
);


--
-- Name: WorkflowRunStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkflowRunStatus" AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'cancelled'
);


--
-- Name: WorkflowStepRunStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkflowStepRunStatus" AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'skipped',
    'blocked'
);


--
-- Name: channel_audience_within_project(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.channel_audience_within_project(output_channel_id uuid, target_project_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  IF output_channel_id IS NULL OR target_project_id IS NULL THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM "channels" AS c
    JOIN "teams" AS t
      ON t."id" = c."team_id"
    WHERE c."id" = output_channel_id
      AND t."project_id" = target_project_id
      AND NOT EXISTS (
        SELECT 1
        FROM "channel_members" AS cm
        WHERE cm."channel_id" = c."id"
          AND NOT EXISTS (
            SELECT 1
            FROM "project_members" AS pm
            WHERE pm."project_id" = t."project_id"
              AND pm."user_id" = cm."user_id"
          )
      )
  );
END
$$;


--
-- Name: channel_audience_within_team(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.channel_audience_within_team(output_channel_id uuid, target_team_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  IF output_channel_id IS NULL OR target_team_id IS NULL THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM "channels" AS c
    WHERE c."id" = output_channel_id
      AND c."team_id" = target_team_id
      AND NOT EXISTS (
        SELECT 1
        FROM "channel_members" AS cm
        WHERE cm."channel_id" = c."id"
          AND NOT EXISTS (
            SELECT 1
            FROM "team_members" AS tm
            WHERE tm."team_id" = c."team_id"
              AND tm."user_id" = cm."user_id"
          )
      )
  );
END
$$;


--
-- Name: match_thoughts_hybrid(public.vector, text, uuid, uuid, public."ThoughtAudienceType", uuid, double precision, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.match_thoughts_hybrid(query_embedding public.vector, query_text text, match_org_id uuid, match_user_id uuid, output_audience_type public."ThoughtAudienceType", output_audience_id uuid, match_threshold double precision DEFAULT 0.3, match_limit integer DEFAULT 10) RETURNS TABLE(id uuid, content text, content_hash text, owner_id text, owner_type text, organization_id uuid, project_id uuid, team_id uuid, channel_id uuid, thread_id uuid, visibility text, sensitivity_tier text, importance double precision, metadata jsonb, created_at timestamp with time zone, similarity double precision)
    LANGUAGE sql STABLE
    AS $$
  WITH accessible_thoughts AS (
    SELECT *
    FROM scoped_thought_candidates(
      match_org_id,
      match_user_id,
      output_audience_type,
      output_audience_id
    )
  ),
  search_query AS (
    SELECT websearch_to_tsquery('english', query_text) AS ts_query
  ),
  semantic_candidates AS (
    SELECT
      t.id,
      t.content,
      t.content_hash,
      t.owner_id,
      t.owner_type,
      t.organization_id,
      t.project_id,
      t.team_id,
      t.channel_id,
      t.thread_id,
      t.visibility,
      t.sensitivity_tier,
      t.importance,
      t.metadata,
      t.created_at,
      t.last_accessed_at,
      thought_outcome_score(t.id) AS outcome_score,
      1 - (t.embedding <=> query_embedding) AS semantic_similarity
    FROM accessible_thoughts AS t
    WHERE t.embedding IS NOT NULL
      AND 1 - (t.embedding <=> query_embedding) > match_threshold
    ORDER BY semantic_similarity DESC, t.created_at DESC
    LIMIT GREATEST(match_limit * 5, 25)
  ),
  semantic_ranked AS (
    SELECT
      sc.*,
      ROW_NUMBER() OVER (ORDER BY sc.semantic_similarity DESC, sc.created_at DESC) AS semantic_rank
    FROM semantic_candidates AS sc
  ),
  lexical_candidates AS (
    SELECT
      t.id,
      t.content,
      t.content_hash,
      t.owner_id,
      t.owner_type,
      t.organization_id,
      t.project_id,
      t.team_id,
      t.channel_id,
      t.thread_id,
      t.visibility,
      t.sensitivity_tier,
      t.importance,
      t.metadata,
      t.created_at,
      t.last_accessed_at,
      thought_outcome_score(t.id) AS outcome_score,
      ts_rank_cd(t.search_vector, sq.ts_query, 32) AS lexical_similarity
    FROM accessible_thoughts AS t
    CROSS JOIN search_query AS sq
    WHERE numnode(sq.ts_query) > 0
      AND t.search_vector @@ sq.ts_query
    ORDER BY lexical_similarity DESC, t.created_at DESC
    LIMIT GREATEST(match_limit * 5, 25)
  ),
  lexical_ranked AS (
    SELECT
      lc.*,
      ROW_NUMBER() OVER (ORDER BY lc.lexical_similarity DESC, lc.created_at DESC) AS lexical_rank
    FROM lexical_candidates AS lc
  ),
  fused AS (
    SELECT
      COALESCE(sr.id, lr.id) AS id,
      COALESCE(sr.content, lr.content) AS content,
      COALESCE(sr.content_hash, lr.content_hash) AS content_hash,
      COALESCE(sr.owner_id, lr.owner_id) AS owner_id,
      COALESCE(sr.owner_type, lr.owner_type) AS owner_type,
      COALESCE(sr.organization_id, lr.organization_id) AS organization_id,
      COALESCE(sr.project_id, lr.project_id) AS project_id,
      COALESCE(sr.team_id, lr.team_id) AS team_id,
      COALESCE(sr.channel_id, lr.channel_id) AS channel_id,
      COALESCE(sr.thread_id, lr.thread_id) AS thread_id,
      COALESCE(sr.visibility, lr.visibility) AS visibility,
      COALESCE(sr.sensitivity_tier, lr.sensitivity_tier) AS sensitivity_tier,
      COALESCE(sr.importance, lr.importance) AS importance,
      COALESCE(sr.metadata, lr.metadata) AS metadata,
      COALESCE(sr.created_at, lr.created_at) AS created_at,
      COALESCE(sr.outcome_score, lr.outcome_score, 0.33) AS outcome_score,
      COALESCE(1.0 / (60 + sr.semantic_rank), 0.0)
        + COALESCE(1.0 / (60 + lr.lexical_rank), 0.0) AS rrf_score,
      1.0 / (
        1.0
        + (
          EXTRACT(
            EPOCH FROM (
              now()
              - COALESCE(
                sr.last_accessed_at,
                lr.last_accessed_at,
                sr.created_at,
                lr.created_at
              )
            )
          ) / 86400.0
        ) * 0.01
      ) AS recency_score
    FROM semantic_ranked AS sr
    FULL OUTER JOIN lexical_ranked AS lr
      ON sr.id = lr.id
  )
  SELECT
    id,
    content,
    content_hash,
    owner_id,
    owner_type,
    organization_id,
    project_id,
    team_id,
    channel_id,
    thread_id,
    visibility,
    sensitivity_tier,
    importance,
    metadata,
    created_at,
    rrf_score
      + (recency_score * 0.01)
      + (outcome_score * 0.005) AS similarity
  FROM fused
  ORDER BY similarity DESC, created_at DESC
  LIMIT match_limit;
$$;


--
-- Name: match_thoughts_in_scopes(public.vector, text, uuid, text[], uuid[], public."ThoughtAudienceType", uuid, uuid, double precision, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.match_thoughts_in_scopes(query_embedding public.vector, query_text text, match_org_id uuid, audience_types text[], audience_ids uuid[], current_audience_type public."ThoughtAudienceType", current_audience_id uuid, running_agent_id uuid, match_threshold double precision DEFAULT 0.3, match_limit integer DEFAULT 10) RETURNS TABLE(id uuid, content text, content_hash text, owner_id text, owner_type text, organization_id uuid, project_id uuid, team_id uuid, channel_id uuid, thread_id uuid, visibility text, sensitivity_tier text, importance double precision, metadata jsonb, created_at timestamp with time zone, similarity double precision)
    LANGUAGE sql STABLE
    AS $$
  WITH scope_set AS (
    SELECT
      s.atype::"ThoughtAudienceType" AS audience_type,
      s.aid AS audience_id
    FROM unnest(audience_types, audience_ids) AS s(atype, aid)
  ),
  accessible_thoughts AS (
    SELECT
      t.id,
      t.content,
      t.content_hash,
      t.owner_id,
      t.owner_type::text AS owner_type,
      t.organization_id,
      t.project_id,
      t.team_id,
      t.channel_id,
      t.thread_id,
      t.visibility::text AS visibility,
      t.sensitivity_tier::text AS sensitivity_tier,
      t.importance,
      t.metadata,
      t.created_at,
      t.embedding,
      t.search_vector,
      t.last_accessed_at
    FROM "thoughts" AS t
    CROSS JOIN LATERAL (
      SELECT
        resolve_thought_audience_type(
          t.audience_type,
          t.visibility,
          t.owner_type,
          t.owner_id,
          t.user_id,
          t.organization_id,
          t.project_id,
          t.team_id,
          t.channel_id
        ) AS audience_type,
        resolve_thought_audience_id(
          t.audience_id,
          resolve_thought_audience_type(
            t.audience_type,
            t.visibility,
            t.owner_type,
            t.owner_id,
            t.user_id,
            t.organization_id,
            t.project_id,
            t.team_id,
            t.channel_id
          ),
          t.organization_id,
          t.project_id,
          t.team_id,
          t.channel_id,
          t.user_id,
          t.owner_type,
          t.owner_id
        ) AS audience_id
    ) AS resolved
    JOIN scope_set AS ss
      ON ss.audience_type = resolved.audience_type
     AND ss.audience_id = resolved.audience_id
    WHERE t.organization_id = match_org_id
      AND t.deleted_at IS NULL
      AND resolved.audience_type IS NOT NULL
      AND resolved.audience_id IS NOT NULL
      AND thought_audience_compatible_with_output(
        resolved.audience_type,
        resolved.audience_id,
        current_audience_type,
        current_audience_id,
        t.organization_id
      )
      AND (
        t.private_to_agent_id IS NULL
        OR t.private_to_agent_id = running_agent_id
      )
  ),
  search_query AS (
    SELECT websearch_to_tsquery('english', query_text) AS ts_query
  ),
  semantic_candidates AS (
    SELECT
      t.id,
      t.content,
      t.content_hash,
      t.owner_id,
      t.owner_type,
      t.organization_id,
      t.project_id,
      t.team_id,
      t.channel_id,
      t.thread_id,
      t.visibility,
      t.sensitivity_tier,
      t.importance,
      t.metadata,
      t.created_at,
      t.last_accessed_at,
      thought_outcome_score(t.id) AS outcome_score,
      1 - (t.embedding <=> query_embedding) AS semantic_similarity
    FROM accessible_thoughts AS t
    WHERE t.embedding IS NOT NULL
      AND 1 - (t.embedding <=> query_embedding) > match_threshold
    ORDER BY semantic_similarity DESC, t.created_at DESC
    LIMIT GREATEST(match_limit * 5, 25)
  ),
  semantic_ranked AS (
    SELECT
      sc.*,
      ROW_NUMBER() OVER (ORDER BY sc.semantic_similarity DESC, sc.created_at DESC) AS semantic_rank
    FROM semantic_candidates AS sc
  ),
  lexical_candidates AS (
    SELECT
      t.id,
      t.content,
      t.content_hash,
      t.owner_id,
      t.owner_type,
      t.organization_id,
      t.project_id,
      t.team_id,
      t.channel_id,
      t.thread_id,
      t.visibility,
      t.sensitivity_tier,
      t.importance,
      t.metadata,
      t.created_at,
      t.last_accessed_at,
      thought_outcome_score(t.id) AS outcome_score,
      ts_rank_cd(t.search_vector, sq.ts_query, 32) AS lexical_similarity
    FROM accessible_thoughts AS t
    CROSS JOIN search_query AS sq
    WHERE numnode(sq.ts_query) > 0
      AND t.search_vector @@ sq.ts_query
    ORDER BY lexical_similarity DESC, t.created_at DESC
    LIMIT GREATEST(match_limit * 5, 25)
  ),
  lexical_ranked AS (
    SELECT
      lc.*,
      ROW_NUMBER() OVER (ORDER BY lc.lexical_similarity DESC, lc.created_at DESC) AS lexical_rank
    FROM lexical_candidates AS lc
  ),
  fused AS (
    SELECT
      COALESCE(sr.id, lr.id) AS id,
      COALESCE(sr.content, lr.content) AS content,
      COALESCE(sr.content_hash, lr.content_hash) AS content_hash,
      COALESCE(sr.owner_id, lr.owner_id) AS owner_id,
      COALESCE(sr.owner_type, lr.owner_type) AS owner_type,
      COALESCE(sr.organization_id, lr.organization_id) AS organization_id,
      COALESCE(sr.project_id, lr.project_id) AS project_id,
      COALESCE(sr.team_id, lr.team_id) AS team_id,
      COALESCE(sr.channel_id, lr.channel_id) AS channel_id,
      COALESCE(sr.thread_id, lr.thread_id) AS thread_id,
      COALESCE(sr.visibility, lr.visibility) AS visibility,
      COALESCE(sr.sensitivity_tier, lr.sensitivity_tier) AS sensitivity_tier,
      COALESCE(sr.importance, lr.importance) AS importance,
      COALESCE(sr.metadata, lr.metadata) AS metadata,
      COALESCE(sr.created_at, lr.created_at) AS created_at,
      COALESCE(sr.outcome_score, lr.outcome_score, 0.33) AS outcome_score,
      COALESCE(1.0 / (60 + sr.semantic_rank), 0.0)
        + COALESCE(1.0 / (60 + lr.lexical_rank), 0.0) AS rrf_score,
      1.0 / (
        1.0
        + (
          EXTRACT(
            EPOCH FROM (
              now()
              - COALESCE(
                sr.last_accessed_at,
                lr.last_accessed_at,
                sr.created_at,
                lr.created_at
              )
            )
          ) / 86400.0
        ) * 0.01
      ) AS recency_score
    FROM semantic_ranked AS sr
    FULL OUTER JOIN lexical_ranked AS lr
      ON sr.id = lr.id
  )
  SELECT
    id,
    content,
    content_hash,
    owner_id,
    owner_type,
    organization_id,
    project_id,
    team_id,
    channel_id,
    thread_id,
    visibility,
    sensitivity_tier,
    importance,
    metadata,
    created_at,
    rrf_score
      + (recency_score * 0.01)
      + (outcome_score * 0.005) AS similarity
  FROM fused
  ORDER BY similarity DESC, created_at DESC
  LIMIT match_limit;
$$;


--
-- Name: match_thoughts_lexical(text, uuid, uuid, public."ThoughtAudienceType", uuid, double precision, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.match_thoughts_lexical(query_text text, match_org_id uuid, match_user_id uuid, output_audience_type public."ThoughtAudienceType", output_audience_id uuid, match_threshold double precision DEFAULT 0.3, match_limit integer DEFAULT 10) RETURNS TABLE(id uuid, content text, content_hash text, owner_id text, owner_type text, organization_id uuid, project_id uuid, team_id uuid, channel_id uuid, thread_id uuid, visibility text, sensitivity_tier text, importance double precision, metadata jsonb, created_at timestamp with time zone, similarity double precision)
    LANGUAGE sql STABLE
    AS $$
  WITH search_query AS (
    SELECT websearch_to_tsquery('english', query_text) AS ts_query
  ),
  lexical_candidates AS (
    SELECT
      t.id,
      t.content,
      t.content_hash,
      t.owner_id,
      t.owner_type,
      t.organization_id,
      t.project_id,
      t.team_id,
      t.channel_id,
      t.thread_id,
      t.visibility,
      t.sensitivity_tier,
      t.importance,
      t.metadata,
      t.created_at,
      ts_rank_cd(t.search_vector, sq.ts_query, 32) AS lexical_similarity
    FROM scoped_thought_candidates(
      match_org_id,
      match_user_id,
      output_audience_type,
      output_audience_id
    ) AS t
    CROSS JOIN search_query AS sq
    WHERE numnode(sq.ts_query) > 0
      AND t.search_vector @@ sq.ts_query
      AND ts_rank_cd(t.search_vector, sq.ts_query, 32) > match_threshold
    ORDER BY lexical_similarity DESC, t.created_at DESC
    LIMIT GREATEST(match_limit * 5, 25)
  )
  SELECT
    id,
    content,
    content_hash,
    owner_id,
    owner_type,
    organization_id,
    project_id,
    team_id,
    channel_id,
    thread_id,
    visibility,
    sensitivity_tier,
    importance,
    metadata,
    created_at,
    lexical_similarity + (thought_outcome_score(id) * 0.005) AS similarity
  FROM lexical_candidates
  ORDER BY similarity DESC, created_at DESC
  LIMIT match_limit;
$$;


--
-- Name: match_thoughts_scoped(public.vector, uuid, uuid, public."ThoughtAudienceType", uuid, double precision, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.match_thoughts_scoped(query_embedding public.vector, match_org_id uuid, match_user_id uuid, output_audience_type public."ThoughtAudienceType", output_audience_id uuid, match_threshold double precision DEFAULT 0.3, match_limit integer DEFAULT 10) RETURNS TABLE(id uuid, content text, content_hash text, owner_id text, owner_type text, organization_id uuid, project_id uuid, team_id uuid, channel_id uuid, thread_id uuid, visibility text, sensitivity_tier text, importance double precision, metadata jsonb, created_at timestamp with time zone, similarity double precision)
    LANGUAGE sql STABLE
    AS $$
  SELECT
    t.id,
    t.content,
    t.content_hash,
    t.owner_id,
    t.owner_type,
    t.organization_id,
    t.project_id,
    t.team_id,
    t.channel_id,
    t.thread_id,
    t.visibility,
    t.sensitivity_tier,
    t.importance,
    t.metadata,
    t.created_at,
    (1 - (t.embedding <=> query_embedding))
      + (thought_outcome_score(t.id) * 0.005) AS similarity
  FROM scoped_thought_candidates(
    match_org_id,
    match_user_id,
    output_audience_type,
    output_audience_id
  ) AS t
  WHERE t.embedding IS NOT NULL
    AND 1 - (t.embedding <=> query_embedding) > match_threshold
  ORDER BY similarity DESC, t.created_at DESC
  LIMIT match_limit;
$$;


--
-- Name: nessie_reject_deepwater_usage_cost(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.nessie_reject_deepwater_usage_cost() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (
    NEW."target" = 'deep-water'
    OR NEW."metadata" ->> 'productSlug' = 'deep-water'
    OR NEW."metadata" ->> 'product_slug' = 'deep-water'
    OR NEW."metadata" ->> 'product' = 'deep-water'
    OR NEW."metadata" ->> 'source' = 'deep_water_run_update'
  ) AND (NEW."cost_amount" IS NOT NULL OR NEW."cost_currency" IS NOT NULL) THEN
    RAISE EXCEPTION 'DeepWater connector cost persistence is forbidden; UOA is authoritative'
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: resolve_thought_audience_id(uuid, public."ThoughtAudienceType", uuid, uuid, uuid, uuid, uuid, public."ThoughtOwnerType", text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_thought_audience_id(stored_audience_id uuid, resolved_audience_type public."ThoughtAudienceType", stored_organization_id uuid, stored_project_id uuid, stored_team_id uuid, stored_channel_id uuid, stored_user_id uuid, stored_owner_type public."ThoughtOwnerType", stored_owner_id text) RETURNS uuid
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  IF stored_audience_id IS NOT NULL THEN
    RETURN stored_audience_id;
  END IF;

  CASE resolved_audience_type
    WHEN 'user' THEN
      RETURN COALESCE(
        stored_user_id,
        CASE
          WHEN stored_owner_type = 'user' THEN safe_uuid(stored_owner_id)
          ELSE NULL
        END
      );
    WHEN 'channel' THEN
      RETURN stored_channel_id;
    WHEN 'team' THEN
      RETURN stored_team_id;
    WHEN 'project' THEN
      RETURN stored_project_id;
    WHEN 'organization' THEN
      RETURN stored_organization_id;
    ELSE
      RETURN NULL;
  END CASE;
END
$$;


--
-- Name: resolve_thought_audience_type(public."ThoughtAudienceType", public."ThoughtVisibility", public."ThoughtOwnerType", text, uuid, uuid, uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_thought_audience_type(stored_audience_type public."ThoughtAudienceType", stored_visibility public."ThoughtVisibility", stored_owner_type public."ThoughtOwnerType", stored_owner_id text, stored_user_id uuid, stored_organization_id uuid, stored_project_id uuid, stored_team_id uuid, stored_channel_id uuid) RETURNS public."ThoughtAudienceType"
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  IF stored_audience_type IS NOT NULL THEN
    RETURN stored_audience_type;
  END IF;

  CASE stored_visibility
    WHEN 'private' THEN
      IF stored_user_id IS NOT NULL OR (
        stored_owner_type = 'user'
        AND safe_uuid(stored_owner_id) IS NOT NULL
      ) THEN
        RETURN 'user'::"ThoughtAudienceType";
      END IF;

      IF stored_channel_id IS NOT NULL THEN
        RETURN 'channel'::"ThoughtAudienceType";
      END IF;

      IF stored_team_id IS NOT NULL THEN
        RETURN 'team'::"ThoughtAudienceType";
      END IF;

      IF stored_project_id IS NOT NULL THEN
        RETURN 'project'::"ThoughtAudienceType";
      END IF;

      IF stored_organization_id IS NOT NULL THEN
        RETURN 'organization'::"ThoughtAudienceType";
      END IF;

      RETURN NULL;
    WHEN 'channel' THEN
      RETURN 'channel'::"ThoughtAudienceType";
    WHEN 'team' THEN
      RETURN 'team'::"ThoughtAudienceType";
    WHEN 'project' THEN
      RETURN 'project'::"ThoughtAudienceType";
    WHEN 'organization' THEN
      RETURN 'organization'::"ThoughtAudienceType";
    ELSE
      RETURN NULL;
  END CASE;
END
$$;


--
-- Name: safe_uuid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.safe_uuid(value text) RETURNS uuid
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
BEGIN
  IF value IS NULL THEN
    RETURN NULL;
  END IF;

  IF value ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN
    RETURN value::uuid;
  END IF;

  RETURN NULL;
END
$_$;


--
-- Name: scoped_thought_candidates(uuid, uuid, public."ThoughtAudienceType", uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.scoped_thought_candidates(match_org_id uuid, match_user_id uuid, output_audience_type public."ThoughtAudienceType", output_audience_id uuid) RETURNS TABLE(id uuid, content text, content_hash text, owner_id text, owner_type text, organization_id uuid, project_id uuid, team_id uuid, channel_id uuid, thread_id uuid, visibility text, sensitivity_tier text, importance double precision, metadata jsonb, created_at timestamp with time zone, embedding public.vector, search_vector tsvector, last_accessed_at timestamp with time zone, access_count integer)
    LANGUAGE sql STABLE
    AS $$
  SELECT
    t.id,
    t.content,
    t.content_hash,
    t.owner_id,
    t.owner_type::text,
    t.organization_id,
    t.project_id,
    t.team_id,
    t.channel_id,
    t.thread_id,
    t.visibility::text,
    t.sensitivity_tier::text,
    t.importance,
    t.metadata,
    t.created_at,
    t.embedding,
    t.search_vector,
    t.last_accessed_at,
    t.access_count
  FROM "thoughts" AS t
  CROSS JOIN LATERAL (
    SELECT
      resolve_thought_audience_type(
        t.audience_type,
        t.visibility,
        t.owner_type,
        t.owner_id,
        t.user_id,
        t.organization_id,
        t.project_id,
        t.team_id,
        t.channel_id
      ) AS audience_type,
      resolve_thought_audience_id(
        t.audience_id,
        resolve_thought_audience_type(
          t.audience_type,
          t.visibility,
          t.owner_type,
          t.owner_id,
          t.user_id,
          t.organization_id,
          t.project_id,
          t.team_id,
          t.channel_id
        ),
        t.organization_id,
        t.project_id,
        t.team_id,
        t.channel_id,
        t.user_id,
        t.owner_type,
        t.owner_id
      ) AS audience_id
  ) AS resolved
  WHERE t.organization_id = match_org_id
    AND t.deleted_at IS NULL
    AND resolved.audience_type IS NOT NULL
    AND resolved.audience_id IS NOT NULL
    AND thought_requester_has_access(
      match_user_id,
      output_audience_type,
      output_audience_id,
      t.organization_id
    )
    AND thought_requester_has_access(
      match_user_id,
      resolved.audience_type,
      resolved.audience_id,
      t.organization_id
    )
    AND thought_audience_compatible_with_output(
      resolved.audience_type,
      resolved.audience_id,
      output_audience_type,
      output_audience_id,
      t.organization_id
    );
$$;


--
-- Name: team_audience_within_project(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.team_audience_within_project(output_team_id uuid, target_project_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  IF output_team_id IS NULL OR target_project_id IS NULL THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM "teams" AS t
    WHERE t."id" = output_team_id
      AND t."project_id" = target_project_id
      AND NOT EXISTS (
        SELECT 1
        FROM "team_members" AS tm
        WHERE tm."team_id" = t."id"
          AND NOT EXISTS (
            SELECT 1
            FROM "project_members" AS pm
            WHERE pm."project_id" = t."project_id"
              AND pm."user_id" = tm."user_id"
          )
      )
  );
END
$$;


--
-- Name: thought_audience_compatible_with_output(public."ThoughtAudienceType", uuid, public."ThoughtAudienceType", uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.thought_audience_compatible_with_output(memory_audience_type public."ThoughtAudienceType", memory_audience_id uuid, output_audience_type public."ThoughtAudienceType", output_audience_id uuid, organization_id uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  -- A memory is always compatible with its own audience: recall in the exact
  -- same audience must succeed even if member resolution is momentarily empty
  -- (e.g. a channel whose membership rows are not yet populated). This can
  -- never leak — the audiences are identical. Otherwise fall back to the
  -- deny-bias subset check (output's members must all be able to see source).
  SELECT
    (
      output_audience_type = memory_audience_type
      AND output_audience_id = memory_audience_id
    )
    OR thought_audience_is_subset(
      output_audience_type,
      output_audience_id,
      memory_audience_type,
      memory_audience_id,
      organization_id
    );
$$;


--
-- Name: thought_audience_is_subset(public."ThoughtAudienceType", uuid, public."ThoughtAudienceType", uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.thought_audience_is_subset(current_audience_type public."ThoughtAudienceType", current_audience_id uuid, source_audience_type public."ThoughtAudienceType", source_audience_id uuid, input_organization_id uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_members AS (
    SELECT user_id
    FROM thought_audience_member_ids(
      current_audience_type,
      current_audience_id,
      input_organization_id
    )
  ),
  source_members AS (
    SELECT user_id
    FROM thought_audience_member_ids(
      source_audience_type,
      source_audience_id,
      input_organization_id
    )
  )
  SELECT EXISTS (SELECT 1 FROM current_members)
    AND NOT EXISTS (
      SELECT 1
      FROM current_members AS current_member
      WHERE NOT EXISTS (
        SELECT 1
        FROM source_members AS source_member
        WHERE source_member.user_id = current_member.user_id
      )
    );
$$;


--
-- Name: thought_audience_member_ids(public."ThoughtAudienceType", uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.thought_audience_member_ids(input_audience_type public."ThoughtAudienceType", input_audience_id uuid, input_organization_id uuid) RETURNS TABLE(user_id uuid)
    LANGUAGE sql STABLE
    AS $$
  SELECT om."user_id"
  FROM "organization_members" AS om
  WHERE input_audience_type = 'organization'::"ThoughtAudienceType"
    AND input_audience_id = input_organization_id
    AND om."organization_id" = input_organization_id

  UNION

  SELECT pm."user_id"
  FROM "project_members" AS pm
  JOIN "projects" AS p
    ON p."id" = pm."project_id"
  WHERE input_audience_type = 'project'::"ThoughtAudienceType"
    AND pm."project_id" = input_audience_id
    AND p."organization_id" = input_organization_id

  UNION

  SELECT tm."user_id"
  FROM "team_members" AS tm
  JOIN "teams" AS t
    ON t."id" = tm."team_id"
  JOIN "projects" AS p
    ON p."id" = t."project_id"
  WHERE input_audience_type = 'team'::"ThoughtAudienceType"
    AND tm."team_id" = input_audience_id
    AND p."organization_id" = input_organization_id

  UNION

  SELECT cm."user_id"
  FROM "channel_members" AS cm
  JOIN "channels" AS c
    ON c."id" = cm."channel_id"
  WHERE input_audience_type = 'channel'::"ThoughtAudienceType"
    AND cm."channel_id" = input_audience_id
    AND c."organization_id" = input_organization_id

  UNION

  SELECT u."id" AS user_id
  FROM "users" AS u
  WHERE input_audience_type = 'user'::"ThoughtAudienceType"
    AND u."id" = input_audience_id
    AND EXISTS (
      SELECT 1
      FROM "organization_members" AS om
      WHERE om."organization_id" = input_organization_id
        AND om."user_id" = u."id"
    );
$$;


--
-- Name: thought_outcome_score(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.thought_outcome_score(input_thought_id uuid) RETURNS double precision
    LANGUAGE sql STABLE
    AS $$
  SELECT COALESCE(
    MAX(
      CASE tr."outcome"
        WHEN 'successful'::"OutcomeStatus" THEN 1.0
        WHEN 'partially'::"OutcomeStatus" THEN 0.66
        WHEN 'pending'::"OutcomeStatus" THEN 0.33
        WHEN 'superseded'::"OutcomeStatus" THEN 0.16
        WHEN 'failed'::"OutcomeStatus" THEN 0.0
        ELSE 0.33
      END
    ),
    0.33
  )
  FROM "thought_reasonings" AS tr
  WHERE tr."thought_id" = input_thought_id;
$$;


--
-- Name: thought_requester_has_access(uuid, public."ThoughtAudienceType", uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.thought_requester_has_access(requester_user_id uuid, audience_type public."ThoughtAudienceType", audience_id uuid, organization_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  IF requester_user_id IS NULL OR audience_type IS NULL OR audience_id IS NULL THEN
    RETURN false;
  END IF;

  CASE audience_type
    WHEN 'user' THEN
      RETURN audience_id = requester_user_id;
    WHEN 'channel' THEN
      RETURN EXISTS (
        SELECT 1
        FROM "channel_members" AS cm
        WHERE cm."channel_id" = audience_id
          AND cm."user_id" = requester_user_id
      );
    WHEN 'team' THEN
      RETURN EXISTS (
        SELECT 1
        FROM "team_members" AS tm
        WHERE tm."team_id" = audience_id
          AND tm."user_id" = requester_user_id
      );
    WHEN 'project' THEN
      RETURN EXISTS (
        SELECT 1
        FROM "project_members" AS pm
        WHERE pm."project_id" = audience_id
          AND pm."user_id" = requester_user_id
      );
    WHEN 'organization' THEN
      RETURN audience_id = organization_id
        AND EXISTS (
          SELECT 1
          FROM "organization_members" AS om
          WHERE om."organization_id" = organization_id
            AND om."user_id" = requester_user_id
        );
    ELSE
      RETURN false;
  END CASE;
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: agent_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_bindings (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: agent_mailbox_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_mailbox_messages (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    plan_id uuid,
    plan_step_id uuid,
    from_agent_id uuid,
    to_agent_id uuid,
    channel_id uuid,
    subject text,
    body text NOT NULL,
    correlation_id text,
    status public."MailboxMessageStatus" DEFAULT 'queued'::public."MailboxMessageStatus" NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    visible_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    claimed_at timestamp(3) without time zone,
    delivered_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    thread_id uuid,
    workflow_run_id uuid,
    workflow_step_run_id uuid,
    actor_id uuid,
    actor_type text
);


--
-- Name: agent_trigger_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_trigger_deliveries (
    id uuid NOT NULL,
    trigger_id uuid NOT NULL,
    status public."AgentTriggerDeliveryStatus" DEFAULT 'pending'::public."AgentTriggerDeliveryStatus" NOT NULL,
    source text,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message text,
    delivered_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    dedupe_key text,
    retry_count integer DEFAULT 0 NOT NULL,
    next_retry_at timestamp(3) without time zone
);


--
-- Name: agent_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_triggers (
    id uuid NOT NULL,
    agent_id uuid,
    type public."AgentTriggerType" NOT NULL,
    status public."AgentTriggerStatus" DEFAULT 'active'::public."AgentTriggerStatus" NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    name text,
    description text,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_fired_at timestamp(3) without time zone,
    next_run_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    target_channel_id uuid,
    target_thread_id uuid,
    scheduler_claim_id uuid,
    scheduler_claimed_at timestamp(3) without time zone,
    workflow_installation_id uuid,
    signing_secret text,
    CONSTRAINT agent_triggers_target_exclusive CHECK ((((agent_id IS NOT NULL) AND (workflow_installation_id IS NULL)) OR ((agent_id IS NULL) AND (workflow_installation_id IS NOT NULL))))
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'assistant'::text NOT NULL,
    status public."AgentStatus" DEFAULT 'idle'::public."AgentStatus" NOT NULL,
    system_prompt text,
    tool_policy jsonb,
    parent_agent_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    model text,
    provider text,
    organization_id uuid,
    project_id uuid,
    team_id uuid,
    routing_profile_id uuid,
    agent_kind public."AgentKind" DEFAULT 'shared'::public."AgentKind" NOT NULL,
    delegation_mode public."AgentDelegationMode" DEFAULT 'none'::public."AgentDelegationMode" NOT NULL,
    surface_policy public."AgentSurfacePolicy" DEFAULT 'shared'::public."AgentSurfacePolicy" NOT NULL,
    system_managed boolean DEFAULT false NOT NULL,
    avatar_attachment_id uuid,
    execution_mode public."AgentExecutionMode" DEFAULT 'inference'::public."AgentExecutionMode" NOT NULL,
    effort public."AgentEffort" DEFAULT 'medium'::public."AgentEffort" NOT NULL,
    CONSTRAINT agents_system_managed_invariants_chk CHECK ((((system_managed = false) AND (agent_kind = 'shared'::public."AgentKind") AND (surface_policy = 'shared'::public."AgentSurfacePolicy") AND (delegation_mode = 'none'::public."AgentDelegationMode")) OR ((system_managed = true) AND (agent_kind = 'personal_assistant'::public."AgentKind") AND (surface_policy = 'dm_only'::public."AgentSurfacePolicy") AND (delegation_mode = 'act_as_requesting_user'::public."AgentDelegationMode")) OR ((system_managed = true) AND (agent_kind = 'shared'::public."AgentKind") AND (surface_policy = 'shared'::public."AgentSurfacePolicy") AND (delegation_mode = 'none'::public."AgentDelegationMode"))))
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    task_id uuid,
    run_id uuid,
    agent_id uuid NOT NULL,
    requester_id text NOT NULL,
    action text NOT NULL,
    reason text NOT NULL,
    context jsonb,
    status public."ApprovalStatus" DEFAULT 'pending'::public."ApprovalStatus" NOT NULL,
    resolver_id text,
    resolved_at timestamp(3) without time zone,
    resolution text,
    resolution_note text,
    continuation_token text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    required_approver_role text
);


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    uploader_id uuid,
    message_id uuid,
    kind text NOT NULL,
    mime text NOT NULL,
    filename text NOT NULL,
    size_bytes bigint NOT NULL,
    storage_key text NOT NULL,
    width integer,
    height integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    knowledge_page_id uuid
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    actor_type public."AuditActorType" NOT NULL,
    actor_id text NOT NULL,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id text,
    outcome public."AuditOutcome" NOT NULL,
    reason text,
    metadata jsonb,
    request_id text NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: board_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_columns (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name text NOT NULL,
    category public."ColumnCategory" NOT NULL,
    "position" integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    scope_type public."BudgetScopeType" NOT NULL,
    scope_id uuid NOT NULL,
    cost_limit_usd numeric(14,4),
    token_limit integer,
    mode public."BudgetMode" DEFAULT 'off'::public."BudgetMode" NOT NULL,
    period public."BudgetPeriod" DEFAULT 'monthly'::public."BudgetPeriod" NOT NULL,
    warn_threshold_percent integer DEFAULT 80 NOT NULL,
    block_humans_when_over boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    degrade_model text,
    degrade_provider text,
    storage_limit_bytes bigint
);


--
-- Name: call_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.call_participants (
    id uuid NOT NULL,
    call_id uuid NOT NULL,
    user_id uuid NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    left_at timestamp(3) without time zone
);


--
-- Name: calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calls (
    id uuid NOT NULL,
    channel_id uuid NOT NULL,
    room_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    started_by_id uuid NOT NULL,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ended_at timestamp(3) without time zone
);


--
-- Name: channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_members (
    id uuid NOT NULL,
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    role public."MemberRole" DEFAULT 'member'::public."MemberRole" NOT NULL,
    muted boolean DEFAULT false NOT NULL
);


--
-- Name: channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channels (
    id uuid NOT NULL,
    label text NOT NULL,
    organization_id uuid NOT NULL,
    team_id uuid NOT NULL,
    visibility public."ChannelVisibility" DEFAULT 'public'::public."ChannelVisibility" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    type public."ChannelType" DEFAULT 'standard'::public."ChannelType" NOT NULL,
    dm_key text,
    system_channel_type public."ChannelSystemType",
    topic text,
    description text,
    archived_at timestamp(3) without time zone,
    project_id uuid NOT NULL,
    slug text,
    CONSTRAINT channels_personal_assistant_surface_chk CHECK (((system_channel_type IS NULL) OR ((type = 'dm'::public."ChannelType") AND (visibility = 'private'::public."ChannelVisibility") AND (dm_key ~~ 'pa:%'::text)))),
    CONSTRAINT channels_standard_slug_required CHECK (((type <> 'standard'::public."ChannelType") OR (slug IS NOT NULL)))
);


--
-- Name: comms_connection_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_connection_credentials (
    id uuid NOT NULL,
    connection_id uuid NOT NULL,
    access_token_ciphertext text NOT NULL,
    refresh_token_ciphertext text,
    expires_at timestamp(3) without time zone,
    key_version integer DEFAULT 1 NOT NULL,
    scope_hash text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: comms_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_connections (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    provider public."CommsProvider" NOT NULL,
    external_tenant_id text NOT NULL,
    external_user_id text NOT NULL,
    status public."CommsConnectionStatus" DEFAULT 'active'::public."CommsConnectionStatus" NOT NULL,
    granted_scopes jsonb DEFAULT '[]'::jsonb NOT NULL,
    initial_sync_completed_at timestamp(3) without time zone,
    last_successful_sync_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: comms_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_events (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    canonical_message_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    edited_at timestamp(3) without time zone,
    provider public."CommsProvider" NOT NULL,
    external_tenant_id text NOT NULL,
    conversation_id text NOT NULL,
    thread_id text,
    message_id text NOT NULL,
    event_type text NOT NULL,
    occurred_at timestamp(3) without time zone NOT NULL,
    sender_external_id text,
    sender_display_name text,
    sender_email text,
    participants jsonb DEFAULT '[]'::jsonb NOT NULL,
    subject text,
    content_text text,
    content_html text,
    attachments jsonb DEFAULT '[]'::jsonb NOT NULL,
    mentions jsonb DEFAULT '[]'::jsonb NOT NULL,
    reactions jsonb DEFAULT '[]'::jsonb NOT NULL,
    visibility text NOT NULL,
    source_url text,
    raw_payload_ref text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: comms_oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_oauth_states (
    token text NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    provider public."CommsProvider" NOT NULL,
    payload jsonb NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    consumed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: comms_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_resources (
    id uuid NOT NULL,
    connection_id uuid NOT NULL,
    resource_type text NOT NULL,
    external_id text NOT NULL,
    name text,
    visibility text,
    user_has_access boolean DEFAULT true NOT NULL,
    sync_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: comms_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_subscriptions (
    id uuid NOT NULL,
    connection_id uuid NOT NULL,
    resource_id uuid,
    provider public."CommsProvider" NOT NULL,
    external_subscription_id text NOT NULL,
    client_state text,
    expires_at timestamp(3) without time zone NOT NULL,
    status public."CommsSubscriptionStatus" DEFAULT 'active'::public."CommsSubscriptionStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: comms_sync_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comms_sync_jobs (
    id uuid NOT NULL,
    connection_id uuid NOT NULL,
    resource_id uuid,
    phase public."CommsSyncPhase" NOT NULL,
    cursor text,
    oldest_imported_at timestamp(3) without time zone,
    newest_imported_at timestamp(3) without time zone,
    status public."CommsSyncStatus" DEFAULT 'pending'::public."CommsSyncStatus" NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: connector_usage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_usage_events (
    id uuid NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    thread_id uuid,
    task_id uuid,
    run_id uuid,
    agent_id uuid,
    actor_id text NOT NULL,
    actor_type public."AuditActorType",
    request_id text,
    correlation_id text,
    connector_type public."ConnectorType" NOT NULL,
    connector_id uuid,
    target text,
    operation text,
    calls integer DEFAULT 1 NOT NULL,
    units integer,
    unit_type text,
    cost_amount numeric(20,8),
    cost_currency text,
    success boolean,
    latency_ms integer,
    metadata jsonb,
    user_id uuid
);


--
-- Name: device_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_tokens (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    platform public."DevicePlatform" NOT NULL,
    token text NOT NULL,
    app_version text,
    last_seen_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: execution_environment_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_environment_instances (
    id uuid NOT NULL,
    template_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    workflow_run_id uuid,
    workflow_step_run_id uuid,
    run_id uuid,
    agent_id uuid,
    status public."ExecutionEnvironmentInstanceStatus" DEFAULT 'pending'::public."ExecutionEnvironmentInstanceStatus" NOT NULL,
    launched_by_actor_type text NOT NULL,
    launched_by_actor_id text NOT NULL,
    provider_instance_ref text,
    launch_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message text,
    started_at timestamp(3) without time zone,
    ready_at timestamp(3) without time zone,
    terminated_at timestamp(3) without time zone,
    last_heartbeat_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: execution_environment_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_environment_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    name text NOT NULL,
    description text,
    provider public."ExecutionProvider" NOT NULL,
    mode public."ExecutionMode" NOT NULL,
    image text,
    launch_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    pricing_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_by_actor_type text NOT NULL,
    created_by_actor_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: execution_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_leases (
    id uuid NOT NULL,
    instance_id uuid NOT NULL,
    runner_id uuid NOT NULL,
    status public."ExecutionLeaseStatus" DEFAULT 'issued'::public."ExecutionLeaseStatus" NOT NULL,
    lease_token text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    acknowledged_at timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: execution_runners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_runners (
    id uuid NOT NULL,
    organization_id uuid,
    provider public."ExecutionProvider" NOT NULL,
    label text NOT NULL,
    capabilities jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public."ExecutionRunnerStatus" DEFAULT 'active'::public."ExecutionRunnerStatus" NOT NULL,
    heartbeat_at timestamp(3) without time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: execution_usage_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_usage_ledger (
    id uuid NOT NULL,
    instance_id uuid NOT NULL,
    template_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    workflow_run_id uuid,
    workflow_step_run_id uuid,
    run_id uuid,
    agent_id uuid,
    actor_type public."AuditActorType" NOT NULL,
    actor_id text NOT NULL,
    meter_type text NOT NULL,
    quantity numeric(20,8) NOT NULL,
    unit_price numeric(20,8),
    cost_amount numeric(14,4),
    currency text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    recorded_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    target_type public."FavoriteTargetType" NOT NULL,
    target_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    attachment_id uuid,
    github_issue_number integer,
    github_issue_url text,
    status text DEFAULT 'saved'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: inference_credential_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inference_credential_bindings (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    label text NOT NULL,
    auth_secret_ref text NOT NULL,
    created_by_actor_id text NOT NULL,
    revoked_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: inference_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inference_models (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    model text NOT NULL,
    display_name text,
    enabled boolean DEFAULT false NOT NULL,
    lifecycle_status public."InferenceLifecycleStatus" DEFAULT 'draft'::public."InferenceLifecycleStatus" NOT NULL,
    capability_snapshot_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    source public."InferenceCapabilitySource" DEFAULT 'static'::public."InferenceCapabilitySource" NOT NULL,
    discovered_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_verified_at timestamp(3) without time zone,
    created_by_actor_id text NOT NULL,
    updated_by_actor_id text NOT NULL,
    approved_by_actor_id text,
    approved_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: inference_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inference_providers (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    provider_key text NOT NULL,
    connector_kind public."InferenceConnectorKind" NOT NULL,
    display_name text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    lifecycle_status public."InferenceLifecycleStatus" DEFAULT 'draft'::public."InferenceLifecycleStatus" NOT NULL,
    base_url text,
    supports_model_discovery boolean DEFAULT true NOT NULL,
    active_credential_binding_id uuid,
    health_status public."InferenceHealthStatus" DEFAULT 'unknown'::public."InferenceHealthStatus" NOT NULL,
    last_checked_at timestamp(3) without time zone,
    created_by_actor_id text NOT NULL,
    updated_by_actor_id text NOT NULL,
    approved_by_actor_id text,
    approved_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: inference_routing_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inference_routing_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    label text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    exposure public."InferenceExposure" DEFAULT 'standard'::public."InferenceExposure" NOT NULL,
    lifecycle_status public."InferenceLifecycleStatus" DEFAULT 'draft'::public."InferenceLifecycleStatus" NOT NULL,
    mode public."InferenceRoutingMode" NOT NULL,
    stream_policy public."InferenceStreamPolicy" DEFAULT 'primary-only'::public."InferenceStreamPolicy" NOT NULL,
    tool_mediator_profile_id uuid,
    route_graph_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_actor_id text NOT NULL,
    updated_by_actor_id text NOT NULL,
    approved_by_actor_id text,
    approved_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: integrated_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.integrated_products (
    id uuid NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    summary text NOT NULL,
    category public."IntegratedProductCategory" NOT NULL,
    launch_url text,
    api_base_url text,
    auth_mode public."IntegratedProductAuthMode" NOT NULL,
    default_install_state public."IntegratedProductInstallState" NOT NULL,
    mcp_catalog_entry_id uuid,
    plugin_manifest_ref text,
    health_status public."IntegratedProductHealthStatus" DEFAULT 'unknown'::public."IntegratedProductHealthStatus" NOT NULL,
    health_detail text,
    capabilities text[] DEFAULT ARRAY[]::text[] NOT NULL,
    setup_hint text,
    sort_order integer DEFAULT 100 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: iterations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iterations (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name text NOT NULL,
    goal text,
    status public."IterationStatus" DEFAULT 'planned'::public."IterationStatus" NOT NULL,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    capacity integer,
    "position" integer NOT NULL,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: knowledge_page_annotation_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_page_annotation_reactions (
    id uuid NOT NULL,
    annotation_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid,
    agent_id uuid,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: knowledge_page_annotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_page_annotations (
    id uuid NOT NULL,
    page_id uuid NOT NULL,
    space_id uuid NOT NULL,
    kind public."KnowledgeAnnotationKind" NOT NULL,
    state public."KnowledgeAnnotationState" DEFAULT 'open'::public."KnowledgeAnnotationState" NOT NULL,
    parent_id uuid,
    body text NOT NULL,
    author_type public."KnowledgeAuthorType" NOT NULL,
    author_id text NOT NULL,
    delegated_by_agent_id uuid,
    anchor jsonb,
    anchor_version_id uuid,
    orphaned boolean DEFAULT false NOT NULL,
    resolved_at timestamp(3) without time zone,
    resolved_by_type public."KnowledgeAuthorType",
    resolved_by_id text,
    organization_id uuid NOT NULL,
    edited_at timestamp(3) without time zone,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: knowledge_page_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_page_chunks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    version_id uuid NOT NULL,
    chunk_index integer NOT NULL,
    content text NOT NULL,
    content_hash text NOT NULL,
    start_offset integer NOT NULL,
    end_offset integer NOT NULL,
    token_count integer,
    embedding public.vector(1536),
    embedding_model text,
    dims integer,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(content, ''::text))) STORED,
    organization_id uuid NOT NULL,
    project_id uuid NOT NULL,
    team_id uuid,
    channel_id uuid,
    thread_id uuid,
    user_id uuid,
    visibility public."ThoughtVisibility" DEFAULT 'project'::public."ThoughtVisibility" NOT NULL,
    sensitivity_tier public."SensitivityTier" DEFAULT 'normal'::public."SensitivityTier" NOT NULL,
    private_to_agent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    task_id uuid
);


--
-- Name: knowledge_page_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_page_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    source_page_id uuid NOT NULL,
    target_page_id uuid,
    target_title text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: knowledge_page_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_page_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    version_number integer NOT NULL,
    body text,
    body_ref text,
    author_type public."KnowledgeAuthorType" NOT NULL,
    author_id text NOT NULL,
    change_comment text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    attachment_id uuid
);


--
-- Name: knowledge_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    space_id uuid NOT NULL,
    title text NOT NULL,
    summary text,
    metadata jsonb,
    parent_page_id uuid,
    "position" integer DEFAULT 0 NOT NULL,
    status public."KnowledgePageStatus" DEFAULT 'draft'::public."KnowledgePageStatus" NOT NULL,
    published_version_id uuid,
    private_to_agent_id uuid,
    organization_id uuid NOT NULL,
    project_id uuid NOT NULL,
    team_id uuid,
    channel_id uuid,
    thread_id uuid,
    user_id uuid,
    visibility public."ThoughtVisibility" DEFAULT 'project'::public."ThoughtVisibility" NOT NULL,
    sensitivity_tier public."SensitivityTier" DEFAULT 'normal'::public."SensitivityTier" NOT NULL,
    created_by text NOT NULL,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    kind public."KnowledgePageKind" DEFAULT 'document'::public."KnowledgePageKind" NOT NULL,
    task_id uuid
);


--
-- Name: knowledge_space_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_space_members (
    id uuid NOT NULL,
    space_id uuid NOT NULL,
    user_id uuid,
    organization_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    agent_id uuid
);


--
-- Name: knowledge_spaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_spaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    metadata jsonb,
    private_to_agent_id uuid,
    organization_id uuid NOT NULL,
    project_id uuid NOT NULL,
    team_id uuid,
    channel_id uuid,
    thread_id uuid,
    user_id uuid,
    visibility public."ThoughtVisibility" DEFAULT 'project'::public."ThoughtVisibility" NOT NULL,
    sensitivity_tier public."SensitivityTier" DEFAULT 'normal'::public."SensitivityTier" NOT NULL,
    created_by text NOT NULL,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    write_restricted boolean DEFAULT false NOT NULL
);


--
-- Name: mcp_catalog_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_catalog_entries (
    id uuid NOT NULL,
    organization_id uuid,
    name text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    protocol public."McpCatalogProtocol" NOT NULL,
    auth_method public."McpCatalogAuthMethod" NOT NULL,
    auth_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    default_transport_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    icon_url text,
    vendor text,
    source_url text,
    signature text,
    status public."McpCatalogStatus" DEFAULT 'draft'::public."McpCatalogStatus" NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    visibility public."McpCatalogVisibility" DEFAULT 'private'::public."McpCatalogVisibility" NOT NULL,
    owner_user_id uuid,
    submitted_at timestamp(3) without time zone,
    reviewed_at timestamp(3) without time zone,
    reviewed_by uuid,
    rejection_reason text,
    locked boolean DEFAULT false NOT NULL,
    locked_at timestamp(3) without time zone,
    locked_by uuid
);


--
-- Name: mcp_oauth_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_oauth_clients (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    issuer text NOT NULL,
    client_id text NOT NULL,
    client_secret_ref text,
    redirect_uris text[],
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: mcp_oauth_secret; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_oauth_secret (
    ref text NOT NULL,
    ciphertext text NOT NULL,
    iv text NOT NULL,
    auth_tag text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: mcp_oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_oauth_states (
    token text NOT NULL,
    payload jsonb NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: mcp_server_credential_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_server_credential_overrides (
    id uuid NOT NULL,
    instance_id uuid NOT NULL,
    principal_type public."McpCredentialPrincipalType" NOT NULL,
    principal_id uuid NOT NULL,
    credential_ref text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: mcp_server_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_server_instances (
    id uuid NOT NULL,
    catalog_entry_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    scope_type public."McpServerScopeType" NOT NULL,
    scope_id uuid NOT NULL,
    credential_ref text,
    transport_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    discovered_tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    lifecycle_state public."McpServerLifecycleState" DEFAULT 'pending_setup'::public."McpServerLifecycleState" NOT NULL,
    health_last_checked_at timestamp(3) without time zone,
    health_failure_count integer DEFAULT 0 NOT NULL,
    installed_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    last_error text
);


--
-- Name: message_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reactions (
    id uuid NOT NULL,
    message_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid NOT NULL,
    thread_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    edited_at timestamp(3) without time zone,
    deleted_at timestamp(3) without time zone
);


--
-- Name: model_pricing_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_pricing_profiles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    provider text NOT NULL,
    model_pattern text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    source public."PricingSource" NOT NULL,
    input_per_million numeric(20,8),
    output_per_million numeric(20,8),
    cached_input_per_million numeric(20,8),
    cached_output_per_million numeric(20,8),
    cache_read_per_million numeric(20,8),
    cache_write_per_million numeric(20,8),
    effective_from timestamp(6) with time zone NOT NULL,
    effective_to timestamp(6) with time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: organization_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_members (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public."MemberRole" DEFAULT 'member'::public."MemberRole" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deactivated_at timestamp(3) without time zone
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    logo_attachment_id uuid
);


--
-- Name: page_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_labels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    page_id uuid NOT NULL,
    name text NOT NULL,
    normalized_name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: plan_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_steps (
    id uuid NOT NULL,
    plan_id uuid NOT NULL,
    assigned_agent_id uuid,
    type text NOT NULL,
    title text NOT NULL,
    sequence integer NOT NULL,
    status public."PlanStepStatus" DEFAULT 'pending'::public."PlanStepStatus" NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb,
    artifacts jsonb DEFAULT '{}'::jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plans (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    run_id uuid,
    agent_id uuid,
    goal text NOT NULL,
    summary text,
    status public."PlanStatus" DEFAULT 'draft'::public."PlanStatus" NOT NULL,
    created_by_actor_type text NOT NULL,
    created_by_actor_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: policy_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_bindings (
    id uuid NOT NULL,
    policy_rule_id uuid NOT NULL,
    actor_type text NOT NULL,
    actor_id text NOT NULL
);


--
-- Name: policy_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_rules (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    scope public."PolicyScope" NOT NULL,
    scope_id text NOT NULL,
    resource_type public."PolicyResourceType" NOT NULL,
    action public."PolicyAction" NOT NULL,
    effect public."PolicyEffect" NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    conditions jsonb,
    created_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: product_account_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_account_links (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    product_slug text NOT NULL,
    uoa_sub text,
    external_account_id text,
    active_org_id text,
    active_team_id text,
    status public."ProductAccountLinkStatus" NOT NULL,
    last_verified_at timestamp(3) without time zone,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    uoa_token_version integer,
    CONSTRAINT product_account_links_uoa_token_version_nonnegative CHECK (((uoa_token_version IS NULL) OR (uoa_token_version >= 0)))
);


--
-- Name: product_integration_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_integration_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    team_id uuid NOT NULL,
    product_slug text NOT NULL,
    requested_by_user_id uuid,
    connector_id uuid,
    channel_id uuid,
    thread_id uuid,
    message_id uuid,
    external_run_id text,
    status public."ProductIntegrationRunStatus" DEFAULT 'queued'::public."ProductIntegrationRunStatus" NOT NULL,
    title text,
    query_preview text DEFAULT ''::text NOT NULL,
    input_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_count integer,
    knowledge_page_id uuid,
    requested_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: product_team_enablements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_team_enablements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    team_id uuid NOT NULL,
    product_slug text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    external_org_id text,
    external_team_id text,
    configured_by_user_id uuid,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: product_webhook_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_webhook_secrets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    product_slug text NOT NULL,
    ciphertext text NOT NULL,
    iv text NOT NULL,
    auth_tag text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: project_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_members (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public."MemberRole" DEFAULT 'member'::public."MemberRole" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    name text NOT NULL,
    organization_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    board_style public."BoardStyle" DEFAULT 'kanban'::public."BoardStyle" NOT NULL
);


--
-- Name: push_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_credentials (
    id uuid NOT NULL,
    provider public."PushProvider" NOT NULL,
    secret_ref text NOT NULL,
    apns_key_id text,
    apns_team_id text,
    apns_topic text,
    apns_environment public."PushApnsEnvironment",
    fcm_project_id text,
    fcm_client_email text,
    updated_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: push_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_deliveries (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    message_id uuid,
    provider public."PushProvider" NOT NULL,
    status public."PushDeliveryStatus" NOT NULL,
    error_code text,
    attempts integer DEFAULT 1 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: queue_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queue_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    topic text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    idempotency_key text,
    attempt integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    locked_until timestamp(6) with time zone,
    enqueued_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamp(6) with time zone,
    completed_at timestamp(6) with time zone,
    error_message text
);


--
-- Name: realtime_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realtime_events (
    id bigint NOT NULL,
    organization_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: realtime_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.realtime_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: realtime_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.realtime_events_id_seq OWNED BY public.realtime_events.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    family_id uuid NOT NULL,
    session_id uuid NOT NULL,
    provider_id text NOT NULL,
    provider_type text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    revoked_at timestamp(3) without time zone,
    replaced_by_id uuid,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    replay_protected_until timestamp(6) with time zone
);


--
-- Name: resource_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_locks (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    plan_id uuid,
    run_id uuid,
    agent_id uuid NOT NULL,
    resource_path text NOT NULL,
    lock_type public."ResourceLockType" DEFAULT 'exclusive'::public."ResourceLockType" NOT NULL,
    acquired_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    released_at timestamp(3) without time zone
);


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    status public."RunStatus" DEFAULT 'pending'::public."RunStatus" NOT NULL,
    started_at timestamp(3) without time zone,
    finished_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    trigger_id uuid,
    trigger_delivery_id uuid
);


--
-- Name: storage_usage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_usage_events (
    id uuid NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    space_id uuid,
    uploader_id uuid,
    attachment_id uuid,
    delta_bytes bigint NOT NULL,
    operation text NOT NULL,
    actor_id text NOT NULL,
    actor_type public."AuditActorType",
    request_id text,
    correlation_id text,
    metadata jsonb
);


--
-- Name: task_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_events (
    id uuid NOT NULL,
    task_id uuid NOT NULL,
    event_type text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    run_id uuid,
    agent_id uuid,
    parent_task_id uuid,
    status public."TaskStatus" DEFAULT 'inbox'::public."TaskStatus" NOT NULL,
    purpose text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    organization_id uuid NOT NULL,
    title text,
    assignee_user_id uuid,
    owner_user_id uuid,
    created_by_user_id uuid,
    project_id uuid,
    column_id uuid,
    iteration_id uuid,
    story_points integer,
    priority public."TaskPriority" DEFAULT 'medium'::public."TaskPriority" NOT NULL,
    due_date timestamp(3) without time zone,
    detail text,
    assignee_agent_id uuid,
    archived_at timestamp(3) without time zone,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    id uuid NOT NULL,
    team_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public."MemberRole" DEFAULT 'member'::public."MemberRole" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id uuid NOT NULL,
    name text NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    system_managed boolean DEFAULT false NOT NULL,
    external_workspace_id text,
    external_org_id text
);


--
-- Name: temporary_context_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.temporary_context_sessions (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    agent_id uuid,
    run_id uuid,
    thread_id uuid,
    title text,
    tool_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by_actor_type text NOT NULL,
    created_by_actor_id text NOT NULL,
    dropped_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: thought_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thought_audit_logs (
    id uuid NOT NULL,
    thought_id uuid NOT NULL,
    action text NOT NULL,
    actor_type text NOT NULL,
    actor_id text NOT NULL,
    diff jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: thought_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thought_links (
    id uuid NOT NULL,
    source_id uuid NOT NULL,
    target_id uuid NOT NULL,
    relation public."ThoughtLinkRelation" NOT NULL,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: thought_reasonings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thought_reasonings (
    id uuid NOT NULL,
    thought_id uuid NOT NULL,
    reasoning_type public."ReasoningType" NOT NULL,
    alternatives jsonb,
    criteria jsonb,
    constraints jsonb,
    tradeoffs text,
    confidence double precision,
    reasoning text NOT NULL,
    actor_type text NOT NULL,
    actor_id text NOT NULL,
    outcome public."OutcomeStatus" DEFAULT 'pending'::public."OutcomeStatus" NOT NULL,
    outcome_notes text,
    outcome_at timestamp(3) without time zone,
    organization_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: thought_recalls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thought_recalls (
    id uuid NOT NULL,
    thought_id uuid NOT NULL,
    session_id text,
    channel_id uuid,
    query_text text NOT NULL,
    query_embedding public.vector(1536),
    similarity double precision,
    rank_position integer NOT NULL,
    retrieval_mode text DEFAULT 'hybrid'::text NOT NULL,
    was_injected boolean DEFAULT false NOT NULL,
    was_referenced boolean DEFAULT false NOT NULL,
    user_signal text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    requester_user_id uuid,
    output_audience_type public."ThoughtAudienceType",
    output_audience_id uuid,
    CONSTRAINT thought_recalls_user_signal_check CHECK ((user_signal = ANY (ARRAY['helpful'::text, 'irrelevant'::text, 'harmful'::text])))
);


--
-- Name: thoughts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thoughts (
    id uuid NOT NULL,
    content text NOT NULL,
    content_hash text NOT NULL,
    owner_id text NOT NULL,
    owner_type public."ThoughtOwnerType" NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    thread_id uuid,
    visibility public."ThoughtVisibility" DEFAULT 'private'::public."ThoughtVisibility" NOT NULL,
    sensitivity_tier public."SensitivityTier" DEFAULT 'normal'::public."SensitivityTier" NOT NULL,
    importance double precision DEFAULT 0.5 NOT NULL,
    metadata jsonb,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    embedding public.vector(1536),
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(content, ''::text))) STORED,
    last_accessed_at timestamp with time zone,
    access_count integer DEFAULT 0 NOT NULL,
    audience_type public."ThoughtAudienceType",
    audience_id uuid,
    user_id uuid,
    private_to_agent_id uuid,
    embedding_model text,
    dims integer,
    memory_type public."ThoughtMemoryType" DEFAULT 'semantic'::public."ThoughtMemoryType" NOT NULL,
    memory_category public."ThoughtMemoryCategory" DEFAULT 'fact'::public."ThoughtMemoryCategory" NOT NULL
);


--
-- Name: thread_read_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thread_read_states (
    id uuid NOT NULL,
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    last_read_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: thread_stream_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thread_stream_events (
    id bigint NOT NULL,
    thread_id uuid NOT NULL,
    event_name text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: thread_stream_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.thread_stream_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: thread_stream_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.thread_stream_events_id_seq OWNED BY public.thread_stream_events.id;


--
-- Name: threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.threads (
    id uuid NOT NULL,
    channel_id uuid NOT NULL,
    title text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: token_ledger_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_ledger_events (
    id uuid NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    thread_id uuid,
    session_id text,
    task_id uuid,
    agent_id uuid,
    actor_id text NOT NULL,
    request_id text NOT NULL,
    correlation_id text,
    provider text NOT NULL,
    model text NOT NULL,
    operation_type public."OperationType" NOT NULL,
    input_tokens integer,
    output_tokens integer,
    cached_input_tokens integer,
    cached_output_tokens integer,
    cache_read_tokens integer,
    cache_write_tokens integer,
    total_tokens integer,
    provider_cost_amount numeric(20,8),
    provider_cost_currency text,
    pricing_profile_id uuid,
    pricing_source public."PricingSource",
    pricing_currency text,
    pricing_input_per_m numeric(20,8),
    pricing_output_per_m numeric(20,8),
    estimated_cost_amount numeric(20,8),
    estimated_cost_currency text,
    metadata jsonb,
    inference_invocation_id text,
    provider_id uuid,
    model_id uuid,
    actor_type public."AuditActorType",
    run_id uuid,
    user_id uuid
);


--
-- Name: tool_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_bundles (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    api_version text NOT NULL,
    bundle_name text NOT NULL,
    version text NOT NULL,
    vendor text,
    source_url text,
    license text,
    signature_type text,
    signature_value text,
    policy jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public."ToolBundleStatus" DEFAULT 'pending_review'::public."ToolBundleStatus" NOT NULL,
    imported_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_calls (
    id uuid NOT NULL,
    run_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tool_name text NOT NULL,
    input_summary text NOT NULL,
    output_preview text,
    success boolean,
    started_at timestamp(3) without time zone NOT NULL,
    ended_at timestamp(3) without time zone,
    duration_ms integer
);


--
-- Name: tool_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_grants (
    id uuid NOT NULL,
    tool_id uuid NOT NULL,
    state public."ToolGrantState" DEFAULT 'inherit'::public."ToolGrantState" NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    source public."ToolGrantSource" NOT NULL,
    role_id uuid,
    agent_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tool_registry_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_registry_entries (
    id uuid NOT NULL,
    organization_id uuid,
    tool_id text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    safe boolean DEFAULT false NOT NULL,
    builtin boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    handler_kind text DEFAULT 'builtin'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    scope_key text NOT NULL,
    source public."ToolRegistrySource" DEFAULT 'builtin'::public."ToolRegistrySource" NOT NULL,
    transport public."ToolRegistryTransport" DEFAULT 'direct'::public."ToolRegistryTransport" NOT NULL,
    transport_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    bundle_id uuid,
    mcp_instance_id uuid,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_schema jsonb,
    tags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    status public."ToolRegistryEntryStatus" DEFAULT 'active'::public."ToolRegistryEntryStatus" NOT NULL,
    version text DEFAULT '0.0.0'::text NOT NULL,
    created_by text DEFAULT 'system'::text NOT NULL,
    overview text NOT NULL,
    instructions text DEFAULT ''::text NOT NULL,
    base_search_terms text[] DEFAULT ARRAY[]::text[] NOT NULL,
    allow_search_terms text[] DEFAULT ARRAY[]::text[] NOT NULL,
    base_prompt jsonb DEFAULT '{"content": "", "mergeMode": "append"}'::jsonb NOT NULL,
    common_prompt jsonb,
    default_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    searchable_text text DEFAULT ''::text NOT NULL,
    owner text DEFAULT 'system'::text NOT NULL
);


--
-- Name: uoa_session_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uoa_session_credentials (
    family_id uuid NOT NULL,
    user_id uuid NOT NULL,
    provider_id text NOT NULL,
    subject text NOT NULL,
    organization_id text NOT NULL,
    team_id text NOT NULL,
    token_version integer NOT NULL,
    config_url text NOT NULL,
    refresh_token_hash text NOT NULL,
    refresh_token_ciphertext text NOT NULL,
    refresh_token_iv text NOT NULL,
    refresh_token_auth_tag text NOT NULL,
    refresh_token_expires_at timestamp(6) with time zone NOT NULL,
    last_local_token_id uuid NOT NULL,
    generation integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT uoa_session_credentials_generation_nonnegative CHECK ((generation >= 0)),
    CONSTRAINT uoa_session_credentials_proof_nonempty CHECK (((length(btrim(provider_id)) > 0) AND (length(btrim(subject)) > 0) AND (length(btrim(organization_id)) > 0) AND (length(btrim(team_id)) > 0) AND (length(btrim(config_url)) > 0) AND (length(btrim(refresh_token_hash)) > 0) AND (length(btrim(refresh_token_ciphertext)) > 0) AND (length(btrim(refresh_token_iv)) > 0) AND (length(btrim(refresh_token_auth_tag)) > 0))),
    CONSTRAINT uoa_session_credentials_token_version_nonnegative CHECK ((token_version >= 0))
);


--
-- Name: user_presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_presence (
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    connections integer DEFAULT 0 NOT NULL,
    last_seen_at timestamp(3) without time zone NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    last_active_at timestamp(3) without time zone,
    manual_state public."UserPresenceManualState"
);


--
-- Name: user_status_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_status_rules (
    id uuid NOT NULL,
    status_id uuid NOT NULL,
    scope public."UserStatusRuleScope" DEFAULT 'fallback'::public."UserStatusRuleScope" NOT NULL,
    channel_id uuid,
    project_id uuid,
    agent_id uuid,
    agent_enabled boolean DEFAULT true NOT NULL,
    instructions text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    CONSTRAINT user_status_rules_scope_target_check CHECK ((((scope = 'fallback'::public."UserStatusRuleScope") AND (channel_id IS NULL) AND (project_id IS NULL)) OR ((scope = 'channel'::public."UserStatusRuleScope") AND (channel_id IS NOT NULL) AND (project_id IS NULL)) OR ((scope = 'project'::public."UserStatusRuleScope") AND (channel_id IS NULL) AND (project_id IS NOT NULL))))
);


--
-- Name: user_status_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_status_schedules (
    id uuid NOT NULL,
    status_id uuid NOT NULL,
    kind public."UserStatusScheduleKind" NOT NULL,
    label text,
    enabled boolean DEFAULT true NOT NULL,
    starts_at timestamp(3) without time zone,
    ends_at timestamp(3) without time zone,
    day_of_week integer,
    start_time text,
    end_time text,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    CONSTRAINT user_status_schedules_day_of_week_check CHECK (((day_of_week IS NULL) OR ((day_of_week >= 0) AND (day_of_week <= 6)))),
    CONSTRAINT user_status_schedules_kind_fields_check CHECK ((((kind = 'date_range'::public."UserStatusScheduleKind") AND (starts_at IS NOT NULL) AND (ends_at IS NOT NULL) AND (day_of_week IS NULL) AND (start_time IS NULL) AND (end_time IS NULL)) OR ((kind = 'weekly'::public."UserStatusScheduleKind") AND (starts_at IS NULL) AND (ends_at IS NULL) AND (day_of_week IS NOT NULL) AND (start_time IS NOT NULL) AND (end_time IS NOT NULL))))
);


--
-- Name: user_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_statuses (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    label text NOT NULL,
    emoji text,
    is_active boolean DEFAULT false NOT NULL,
    agent_enabled boolean DEFAULT false NOT NULL,
    agent_instructions text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    display_name text NOT NULL,
    password_hash text,
    avatar_url text,
    pronouns text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    preferences jsonb,
    super_admin boolean DEFAULT false NOT NULL,
    avatar_attachment_id uuid
);


--
-- Name: web_push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_push_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent text,
    last_seen_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: workflow_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_installations (
    id uuid NOT NULL,
    workflow_template_id uuid NOT NULL,
    workflow_template_version integer NOT NULL,
    organization_id uuid NOT NULL,
    project_id uuid,
    team_id uuid,
    channel_id uuid,
    status public."WorkflowInstallationStatus" DEFAULT 'draft'::public."WorkflowInstallationStatus" NOT NULL,
    active boolean DEFAULT true NOT NULL,
    resolved_bindings jsonb DEFAULT '{}'::jsonb NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_actor_type text NOT NULL,
    created_by_actor_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: workflow_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_runs (
    id uuid NOT NULL,
    installation_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    trigger_id uuid,
    trigger_delivery_id uuid,
    parent_run_id uuid,
    plan_id uuid,
    plan_step_id uuid,
    status public."WorkflowRunStatus" DEFAULT 'pending'::public."WorkflowRunStatus" NOT NULL,
    input jsonb DEFAULT '{}'::jsonb NOT NULL,
    output jsonb DEFAULT '{}'::jsonb,
    summary text,
    error_message text,
    started_by_actor_type text NOT NULL,
    started_by_actor_id text NOT NULL,
    started_at timestamp(3) without time zone,
    finished_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    retried_from_workflow_run_id uuid
);


--
-- Name: workflow_state_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_state_entries (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    workflow_installation_id uuid NOT NULL,
    workflow_run_id uuid,
    workflow_step_run_id uuid,
    state_key text NOT NULL,
    value jsonb NOT NULL,
    value_hash text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: workflow_step_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_step_runs (
    id uuid NOT NULL,
    workflow_run_id uuid NOT NULL,
    step_key text NOT NULL,
    step_type text NOT NULL,
    title text NOT NULL,
    sequence integer NOT NULL,
    status public."WorkflowStepRunStatus" DEFAULT 'pending'::public."WorkflowStepRunStatus" NOT NULL,
    input jsonb DEFAULT '{}'::jsonb NOT NULL,
    output jsonb DEFAULT '{}'::jsonb,
    error_message text,
    assigned_agent_id uuid,
    agent_run_id uuid,
    task_id uuid,
    started_at timestamp(3) without time zone,
    finished_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: workflow_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_templates (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    version integer DEFAULT 1 NOT NULL,
    graph_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    triggers_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    variable_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    binding_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    required_environment_template_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by_actor_type text NOT NULL,
    created_by_actor_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: realtime_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realtime_events ALTER COLUMN id SET DEFAULT nextval('public.realtime_events_id_seq'::regclass);


--
-- Name: thread_stream_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_stream_events ALTER COLUMN id SET DEFAULT nextval('public.thread_stream_events_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public._prisma_migrations VALUES ('d0973e91-0015-4a98-9947-0efae67e4e93', 'e0097baf6d037fac8aabc6fc13a4a70bf8133aa0c0ce30242d465d78788e8bd0', '2026-08-11 21:59:28.425639+00', '20260409020000_queue_idempotency_unique', NULL, NULL, '2026-08-11 21:59:28.423037+00', 1);
INSERT INTO public._prisma_migrations VALUES ('9c8d44c7-ef53-439c-be95-2a632f706c9e', 'dbe223c9db30e6b1a290bf7a5405f22f81dd5b109feb4c59c69104ff8053c9c6', '2026-08-11 21:59:28.257963+00', '20260408000223_phase1_step1_init', NULL, NULL, '2026-08-11 21:59:28.151644+00', 1);
INSERT INTO public._prisma_migrations VALUES ('5534b006-a7c2-4c18-8257-ec8fa3a7dcc1', 'a3a3ea8d63c3f2b9b2f102b61b759ff534301f4d04caf5660c12f2089e9bda3e', '2026-08-11 21:59:28.266395+00', '20260408030300_phase1_step3_realtime', NULL, NULL, '2026-08-11 21:59:28.25844+00', 1);
INSERT INTO public._prisma_migrations VALUES ('bf6cdc5b-e5ab-4cec-b0e9-333e3dfa9cfc', 'cb272f6e2818b6e04eba930e4538cef58d7f4642d48907180c2827a7b0d7116f', '2026-08-11 21:59:28.590921+00', '20260410210000_add_workflows_and_execution_control_plane', NULL, NULL, '2026-08-11 21:59:28.514592+00', 1);
INSERT INTO public._prisma_migrations VALUES ('1f83f98a-b277-4c02-8fe8-8394b23ff178', '79c4db77ef4d7ee6256435969fa03cc467bdbb456b6f1f028b2b2f33b85d5842', '2026-08-11 21:59:28.269199+00', '20260408113000_phase1_step3_thread_stream_event_fk', NULL, NULL, '2026-08-11 21:59:28.26673+00', 1);
INSERT INTO public._prisma_migrations VALUES ('81ca8c9e-4f79-465a-916e-4892777a66e4', '9662366d935785ffe3bd40b3b406e2a6547cff2ff6c3ebb206fd920838eee609', '2026-08-11 21:59:28.446609+00', '20260409100000_add_agent_triggers', NULL, NULL, '2026-08-11 21:59:28.42609+00', 1);
INSERT INTO public._prisma_migrations VALUES ('b4b53c80-9334-4cbb-b5c0-09aeaa53729c', 'a20866422aad5bc116e5e282cc2aa4acf9a0486b6fdfedc89d1f242c29bf6acd', '2026-08-11 21:59:28.28526+00', '20260408140000_enable_pgvector', NULL, NULL, '2026-08-11 21:59:28.269514+00', 1);
INSERT INTO public._prisma_migrations VALUES ('67687a7c-4669-467c-b2ba-cb207b172148', '196a9c35576578533a550ae45d9768ef8b9c81f200b7988e1ef3b7a9ac86ce54', '2026-08-11 21:59:28.315657+00', '20260408140100_memory_system_models', NULL, NULL, '2026-08-11 21:59:28.285761+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ec10ee09-bf34-425e-9337-b961e4d802be', '1c6d67ae45fac288b38816ac100ae76255168e889ea6590b75e4b4a8c9726ff2', '2026-08-11 21:59:28.332682+00', '20260408140200_memory_vector_columns_and_search', NULL, NULL, '2026-08-11 21:59:28.316115+00', 1);
INSERT INTO public._prisma_migrations VALUES ('0c5c6d9b-d7e9-400a-9437-2df1404f5ac5', '2566776ad26fa7afad437dcb3cd7e9bca60241f977b28a7de2fd5b12c2341696', '2026-08-11 21:59:28.455382+00', '20260409113000_harden_trigger_targets_and_dedupe', NULL, NULL, '2026-08-11 21:59:28.447224+00', 1);
INSERT INTO public._prisma_migrations VALUES ('becba7fe-7cd1-45f5-81e9-d33acb3c1926', 'bc2ab866038a6899fbe8024ec013eabc1f9dec648f5777dfdff0667c1394661c', '2026-08-11 21:59:28.346723+00', '20260408150000_add_agent_categories', NULL, NULL, '2026-08-11 21:59:28.333087+00', 1);
INSERT INTO public._prisma_migrations VALUES ('14c58396-e141-4419-bc1d-4114ea4658c4', '05440cc23114b534a005757337d030156ae4b82618474958f140c9bb25e36fc3', '2026-08-11 21:59:28.350253+00', '20260408160000_add_category_description_and_author_agent', NULL, NULL, '2026-08-11 21:59:28.347314+00', 1);
INSERT INTO public._prisma_migrations VALUES ('9b2e1369-ac6b-45fa-b60f-80827e43140f', '6274dbda4b2ec98d6423408605d3cd2398735e50159e0bfa0739584797f14e68', '2026-08-11 21:59:28.689545+00', '20260414173000_remove_agent_categories', NULL, NULL, '2026-08-11 21:59:28.685457+00', 1);
INSERT INTO public._prisma_migrations VALUES ('e2495652-8b38-4e01-afbe-98b1b4cb6f5b', '7b6d195b4787213954c64c44133421128a77ace488bbb8ba18971cfd80924da5', '2026-08-11 21:59:28.360181+00', '20260408193000_memory_hybrid_retrieval_and_recalls', NULL, NULL, '2026-08-11 21:59:28.350626+00', 1);
INSERT INTO public._prisma_migrations VALUES ('8f4f4f9d-355e-4057-bcbe-ce7c8bcbd5c0', '4d6e117e7aef3806653681570b60f42a2845b7d5390300db03321508264b2143', '2026-08-11 21:59:28.45779+00', '20260409120000_add_trigger_scheduler_claims', NULL, NULL, '2026-08-11 21:59:28.455765+00', 1);
INSERT INTO public._prisma_migrations VALUES ('59d9091a-ba29-45f1-a109-29b0da899e4f', 'c402836319d1188ef81c013bf4722bba5928dba89d02cffb8507c9737acc9c0c', '2026-08-11 21:59:28.361838+00', '20260408195925_add_agent_provider_and_model', NULL, NULL, '2026-08-11 21:59:28.360514+00', 1);
INSERT INTO public._prisma_migrations VALUES ('cc4c076f-8ea6-4cea-95f4-657155414d99', '47215da60366bf90a9e857535b0d832620d800f595d46ba6c59d23a9b3790cbc', '2026-08-11 21:59:28.375262+00', '20260408210000_add_message_reactions', NULL, NULL, '2026-08-11 21:59:28.362885+00', 1);
INSERT INTO public._prisma_migrations VALUES ('910ccdf6-7a52-4f67-990e-451d20727d99', 'fe43fe783619c7769f9206ec47aebc923488b9291c515f201453d51e4c026abc', '2026-08-11 21:59:28.651867+00', '20260410220000_add_inference_control_plane', NULL, NULL, '2026-08-11 21:59:28.59145+00', 1);
INSERT INTO public._prisma_migrations VALUES ('d1316887-8e35-492f-9268-e63cab6b7dd1', '7f7e7f8312ac79766f099007011ab3e6f8c50c1ea8ba4e5199ff9485dc2c5fd9', '2026-08-11 21:59:28.422375+00', '20260409010000_phase2_models', NULL, NULL, '2026-08-11 21:59:28.375749+00', 1);
INSERT INTO public._prisma_migrations VALUES ('61f48434-4e2d-49f3-a440-f229847afaf7', '90ed68b6c37a9cfcdb19134c70b27f59c444b2ceae5dc9fee8c719a4237ed2da', '2026-08-11 21:59:28.499866+00', '20260410140000_add_plans_registry_and_temp_context', NULL, NULL, '2026-08-11 21:59:28.458172+00', 1);
INSERT INTO public._prisma_migrations VALUES ('c6aa15b4-f20a-4241-9e00-9e31f577bfaf', 'bf9781184d7da740416b5978487acaa5c93b3f5f8d8ff0f7b73e4721f52c65c8', '2026-08-11 21:59:28.675763+00', '20260413213007_add_video_calls', NULL, NULL, '2026-08-11 21:59:28.664127+00', 1);
INSERT INTO public._prisma_migrations VALUES ('3391e9e2-59a5-456e-a329-51488f3e95ac', '1509ba8124659cb8d19fe26f16432da2ab816a9b507da93c02f2c48d611c6f6c', '2026-08-11 21:59:28.507236+00', '20260410153000_harden_control_plane_primitives', NULL, NULL, '2026-08-11 21:59:28.500412+00', 1);
INSERT INTO public._prisma_migrations VALUES ('3b3eaefc-b25d-4fcc-bf05-a7868c243efa', '2c281a23d13d3659cadbd991a4326129032428c4fcc4551bf602bfaebbab30ae', '2026-08-11 21:59:28.65555+00', '20260410230000_agent_triggers_workflow_target', NULL, NULL, '2026-08-11 21:59:28.652308+00', 1);
INSERT INTO public._prisma_migrations VALUES ('7a221b1e-3ab8-4a4c-ad3e-23426d64b3a0', '53d2e90f71bf931c7e72454075f9be2d4704746cddf2510d097175c46a1bc1c2', '2026-08-11 21:59:28.510204+00', '20260410170000_add_mailbox_thread_id', NULL, NULL, '2026-08-11 21:59:28.507671+00', 1);
INSERT INTO public._prisma_migrations VALUES ('afb38673-d443-4cba-89d2-4213b4ee5975', '27fd0a64e359ef8668fd48c1b0968b3872592f59e91ce3939414fc5231dc08af', '2026-08-11 21:59:28.514142+00', '20260410193000_add_mailbox_thread_fk', NULL, NULL, '2026-08-11 21:59:28.510553+00', 1);
INSERT INTO public._prisma_migrations VALUES ('f70fcf8c-f861-4f5b-abd4-399ed689b658', '5d96cf8904f2cfbb691e72611fb2d22533980c14cf1c09614ee8bf07d4a8ae03', '2026-08-11 21:59:28.659596+00', '20260411000000_workflow_run_retry_lineage', NULL, NULL, '2026-08-11 21:59:28.656258+00', 1);
INSERT INTO public._prisma_migrations VALUES ('4c2bf01f-1c04-4c18-83bd-8d197965ba67', '92aeb896b42a640c28a540451a5c69b342807a7149ef4cebeee6d2638a7ac8af', '2026-08-11 21:59:28.680896+00', '20260414000000_add_performance_indexes', NULL, NULL, '2026-08-11 21:59:28.676114+00', 1);
INSERT INTO public._prisma_migrations VALUES ('6bc67ea6-cdf0-47d6-aefc-8bfcf443a7ce', 'e78c18fb4967d57bcbd62579174fc073e0a4a785aaec31f4341c5c4e3815715f', '2026-08-11 21:59:28.661161+00', '20260413000000_add_user_preferences', NULL, NULL, '2026-08-11 21:59:28.660009+00', 1);
INSERT INTO public._prisma_migrations VALUES ('0ea90be0-0a44-46bc-ae97-b87cd5c81b21', '31cabd93b8d5ea6c15b609d576d465010422e1e7cb44d4716a9a0bdad2017af6', '2026-08-11 21:59:28.663644+00', '20260413100000_add_channel_type', NULL, NULL, '2026-08-11 21:59:28.661471+00', 1);
INSERT INTO public._prisma_migrations VALUES ('5ce1527a-3a99-4d58-a493-596fb0523cf4', '3c730992d7e935e63d658e60a183a2d6b613d35947e4209b51cb6f6f22d0b808', '2026-08-11 21:59:28.727134+00', '20260415110000_add_personal_assistant_system_fields', NULL, NULL, '2026-08-11 21:59:28.719676+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ff802c89-bad9-47f6-98ee-75f3d031e041', 'e81b1eff5ea790d8bd0f3a371a319a47c156fde11a209ae75f6f4f18cf5641e9', '2026-08-11 21:59:28.68508+00', '20260414010000_add_channel_dm_key', NULL, NULL, '2026-08-11 21:59:28.681317+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ed26e3b3-42e6-49df-a294-e81a0761b027', 'd6ee5eee89378e25379d802c47b8badc415a8e2c2f3e17defe4b8cd225811b68', '2026-08-11 21:59:28.719282+00', '20260415000000_add_workflow_state_entries', NULL, NULL, '2026-08-11 21:59:28.709299+00', 1);
INSERT INTO public._prisma_migrations VALUES ('48ff73a3-eba6-4333-ac79-68ad27eeb2a9', 'a6be6f2dbd7254843070ce87edd8b053d72e5d5bbb1480082186b9b53419f648', '2026-08-11 21:59:28.697454+00', '20260414202000_add_thread_read_states', NULL, NULL, '2026-08-11 21:59:28.689946+00', 1);
INSERT INTO public._prisma_migrations VALUES ('127702fb-4384-44a0-84bb-6a8205cad2c3', '882a37e68e0e78cc7ddc716fb23adb4de6b1d1cc79fe9f7797374250d0312544', '2026-08-11 21:59:28.708927+00', '20260414230000_add_thought_audience_scoping', NULL, NULL, '2026-08-11 21:59:28.698017+00', 1);
INSERT INTO public._prisma_migrations VALUES ('c7a76c08-26ef-473f-ab66-b71cfe8a5ea7', '61836170025e5bcf88b5e273ff74fbae09eacc4e0b59918b721378ea6a0d8935', '2026-08-11 21:59:28.730173+00', '20260415153000_personal_assistant_hidden_team_and_provenance', NULL, NULL, '2026-08-11 21:59:28.727514+00', 1);
INSERT INTO public._prisma_migrations VALUES ('19e3bfce-5377-47d8-b2db-6d4f36f3006a', '11277462f8c6ffe549ee120f2a016292d0192805de88bea1856bd3476c684df7', '2026-08-11 21:59:28.731747+00', '20260415162000_mailbox_actor_context', NULL, NULL, '2026-08-11 21:59:28.730571+00', 1);
INSERT INTO public._prisma_migrations VALUES ('9af86e32-a12d-4e38-ae0f-fb165e48db38', 'a04b61fdbbeafea42290a6d157f3fc3dea4f4a40d990863dd8d628c081fe0941', '2026-08-11 21:59:28.770959+00', '20260516191912_mcp_universal_connector', NULL, NULL, '2026-08-11 21:59:28.732193+00', 1);
INSERT INTO public._prisma_migrations VALUES ('416fc98c-fa3c-4ad2-9f65-db630b50baeb', '7fee3ac55970c4eab9955f7c8619ee9602e0136497722edfb979491d537a18ef', '2026-08-11 21:59:28.782102+00', '20260516202000_reconcile_drift', NULL, NULL, '2026-08-11 21:59:28.77139+00', 1);
INSERT INTO public._prisma_migrations VALUES ('95444dca-88fe-4bb8-af00-620bb35d0f8e', 'b8dc40a1bf1614b9cc26184f42e07a1926320bfb1727e83ff85957e249cb7db5', '2026-08-11 21:59:28.784731+00', '20260516203329_mcp_add_organization_principal', NULL, NULL, '2026-08-11 21:59:28.782693+00', 1);
INSERT INTO public._prisma_migrations VALUES ('9127eeef-7080-4029-bf4a-4159cc99adca', 'a913ed865f7d80f410bf9ad37fbaad868d9a7c226f419704ee48393347017da0', '2026-08-11 21:59:29.044237+00', '20260531010000_message_lifecycle_search', NULL, NULL, '2026-08-11 21:59:29.041407+00', 1);
INSERT INTO public._prisma_migrations VALUES ('648fb0ae-c94e-466f-abbd-a789e6bb1d8e', '6ee72907a0ab1f361a454d16c27871a40ffb3ca3e4acbd1a3d4edfd272fc0629', '2026-08-11 21:59:28.790808+00', '20260516220919_reconcile_tool_registry_entry', NULL, NULL, '2026-08-11 21:59:28.785302+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a8163624-ce45-4b25-b2d7-929e825887d1', '06b85fcabf8fe638317e3358fe70e03a464fed979d44da4aaa1f323d1db255d2', '2026-08-11 21:59:28.837057+00', '20260530170100_reinstate_inference_org_fkeys', NULL, NULL, '2026-08-11 21:59:28.832268+00', 1);
INSERT INTO public._prisma_migrations VALUES ('d5a404e8-2b64-45ad-9176-713b58ed46e1', '98a16919246c5abd8e7796ebc46b681807f2359fc0c6d6b0f6f2cab1a38d001a', '2026-08-11 21:59:28.792385+00', '20260516221500_add_last_error_to_mcp_server_instance', NULL, NULL, '2026-08-11 21:59:28.791179+00', 1);
INSERT INTO public._prisma_migrations VALUES ('caa157f8-7430-4f8b-af80-8566bc1eafa8', 'd89fb8691db55bb807fe8aab98100c179ba5650f0653afa270a7ce11aaa19872', '2026-08-11 21:59:28.79552+00', '20260517101122_tool_registry_spec_followups', NULL, NULL, '2026-08-11 21:59:28.792721+00', 1);
INSERT INTO public._prisma_migrations VALUES ('3d4c975b-d5d8-4919-8a13-1f5335bbc881', '8bbe88f36e2f988dc7e873c4a539bc7b30bbd3345ebf9f405f7e8af268753069', '2026-08-11 21:59:29.018409+00', '20260530170900_member_role_enum', NULL, NULL, '2026-08-11 21:59:29.005234+00', 1);
INSERT INTO public._prisma_migrations VALUES ('435e9aa2-e9a5-4353-a64e-dd24b8a92150', 'ed863e7efd721f8cfb18b8db474299efc08379a40e0e5fd398bdf83a7656aab5', '2026-08-11 21:59:28.799127+00', '20260529120000_agent_memory_scoping', NULL, NULL, '2026-08-11 21:59:28.796067+00', 1);
INSERT INTO public._prisma_migrations VALUES ('17c581cc-9de8-4b3c-b309-dbbd3b3c1f9f', '8d6464413e4f935bf3dfe0ac8f178e3ed9102bb38fec0f97231c8fb012bd729b', '2026-08-11 21:59:28.851429+00', '20260530170200_scope_fkeys', NULL, NULL, '2026-08-11 21:59:28.837534+00', 1);
INSERT INTO public._prisma_migrations VALUES ('4abbf51c-2c52-4346-8032-f797e955edb2', '5906bddc465db09f49e82efb5a29f56df5b03188eb43db787561c6f8b5b04f59', '2026-08-11 21:59:28.800954+00', '20260530120000_mcp_catalog_status_review_states', NULL, NULL, '2026-08-11 21:59:28.79973+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a1d62446-aa33-456d-975d-293b78ab434d', 'e222690e35246bfcdf55a374890f5056acc2d598beb63d40d2685bc6bed33955', '2026-08-11 21:59:28.806882+00', '20260530120100_mcp_catalog_visibility_approval', NULL, NULL, '2026-08-11 21:59:28.801257+00', 1);
INSERT INTO public._prisma_migrations VALUES ('5683d99c-223d-48ff-af7a-713ec6fe3973', '6302ec44c1f4c9441beb55a9129d269f8b73ff7cac41b3281def6eaa8c566117', '2026-08-11 21:59:28.814616+00', '20260530130000_human_work_distribution', NULL, NULL, '2026-08-11 21:59:28.807242+00', 1);
INSERT INTO public._prisma_migrations VALUES ('776babe9-5a74-4cb5-855f-7802f1423e28', '54e45db4d7ed77736d2f9bbae51477b9a6adcb6a98dd77076beb7d377f631ec6', '2026-08-11 21:59:28.853655+00', '20260530170300_mailbox_dispatch_partial_index', NULL, NULL, '2026-08-11 21:59:28.85182+00', 1);
INSERT INTO public._prisma_migrations VALUES ('c60d3293-14fb-4929-a41a-f93782ad6256', 'e0a19cef9d6b53f1affaf8d5b68035369e8c7103851d222b49d09fcef46e23b0', '2026-08-11 21:59:28.817008+00', '20260530140000_queue_jobs_status_index', NULL, NULL, '2026-08-11 21:59:28.815067+00', 1);
INSERT INTO public._prisma_migrations VALUES ('907dc30a-31e6-48ab-ac58-92bf9e7e3d23', '8cad5136be1ad91c30df670de6f60a085c9228a8f872389caee11f9fee5447cb', '2026-08-11 21:59:28.822463+00', '20260530150000_organization_budget', NULL, NULL, '2026-08-11 21:59:28.817384+00', 1);
INSERT INTO public._prisma_migrations VALUES ('830f943d-47a3-48f2-98f1-d252273c5891', '1acedd0b3db74f8e840349b78d8e04dd1d04c4122a51b76a77711578ee5b09be', '2026-08-11 21:59:28.824079+00', '20260530150100_org_budget_token_limit', NULL, NULL, '2026-08-11 21:59:28.822793+00', 1);
INSERT INTO public._prisma_migrations VALUES ('63971c5e-06fb-42fc-9bc5-c1489dc73a54', 'ffab7db30ef97dac40bba41e4ceeaf7e57edd97e52fc42e837566aecccfed258', '2026-08-11 21:59:28.856186+00', '20260530170400_index_prune', NULL, NULL, '2026-08-11 21:59:28.854002+00', 1);
INSERT INTO public._prisma_migrations VALUES ('1a833b03-32f0-422e-b365-a175b20d69fa', '2ed319dd281a3a4c2a9bef6e6f6ded407c181cd1c780e0a40d70ff41867b8ed7', '2026-08-11 21:59:28.826253+00', '20260530160000_budget_modes', NULL, NULL, '2026-08-11 21:59:28.824525+00', 1);
INSERT INTO public._prisma_migrations VALUES ('e7a8d6b4-8d96-4ad7-b7dd-6ae97b16a0d5', '52e74aaa129a92f1936649bbcb3097999c7cb309778317b2102b8151cfa64d2a', '2026-08-11 21:59:28.831969+00', '20260530170000_token_ledger_dimension_indexes', NULL, NULL, '2026-08-11 21:59:28.82661+00', 1);
INSERT INTO public._prisma_migrations VALUES ('6f2cbfd4-4916-410a-8277-7c5abed0437f', '756d907931d2b010a0058dd4fb8aafd1c13a76f400313ef94a5e419561111bf9', '2026-08-11 21:59:29.025667+00', '20260530180000_budgets_scoped', NULL, NULL, '2026-08-11 21:59:29.018802+00', 1);
INSERT INTO public._prisma_migrations VALUES ('dab9daee-30ca-4140-868c-cdcd814af77e', '89fd3ed798f632f3cc5361e5ade9c8af95a54b5173171bc2ef8630f67b2db2a2', '2026-08-11 21:59:28.859265+00', '20260530170500_recreate_queue_poll_index', NULL, NULL, '2026-08-11 21:59:28.856508+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a76ce46d-6845-424f-a0ee-1c9f010533d3', '67a86aaec5aba3805935df8d2d94076386688906850eb3fd7ee6cddd3261b10e', '2026-08-11 21:59:28.862148+00', '20260530170600_pricing_profile_active_unique', NULL, NULL, '2026-08-11 21:59:28.859645+00', 1);
INSERT INTO public._prisma_migrations VALUES ('56123af3-3208-42d4-9e28-749bd97643a2', '379f19c3899b809989dbd5df23a31c3274c47f49478cff56a5868fc7a840cdee', '2026-08-11 21:59:29.103779+00', '20260605120000_mcp_oauth_secret_store', NULL, NULL, '2026-08-11 21:59:29.098858+00', 1);
INSERT INTO public._prisma_migrations VALUES ('085007f1-9f13-4fab-94f6-cfb311fcc0b2', '0c52495e4b16b25c1f7e69cddd78c6b097d05853f3933cbe04219b0f06402df4', '2026-08-11 21:59:28.865744+00', '20260530170700_audit_resource_type_index', NULL, NULL, '2026-08-11 21:59:28.862574+00', 1);
INSERT INTO public._prisma_migrations VALUES ('15916de9-6f32-4776-ac1d-753d63d6f691', 'fde02d26313c0ea0534ee3374a3171afba3a892fb29c74fda69b8934edd1ec82', '2026-08-11 21:59:29.031038+00', '20260530180000_token_ledger_provider_model_fk', NULL, NULL, '2026-08-11 21:59:29.026011+00', 1);
INSERT INTO public._prisma_migrations VALUES ('5ebe80b8-8982-4ca6-801d-7284e8292a15', '1aeefc72640cacf93378f0e82a60c455c0462a010107013f589056d74db5d55f', '2026-08-11 21:59:29.004723+00', '20260530170800_ledger_decimal_idempotency', NULL, NULL, '2026-08-11 21:59:28.866114+00', 1);
INSERT INTO public._prisma_migrations VALUES ('39979434-9bc5-4790-aea5-e0553f4f7975', '26f14cd46e55f8d25ae8b311f0f8a02539b0b08f8c58d7ee6adbd8456a069fee', '2026-08-11 21:59:29.046863+00', '20260531010100_channel_lifecycle', NULL, NULL, '2026-08-11 21:59:29.044593+00', 1);
INSERT INTO public._prisma_migrations VALUES ('efe0cea6-2b60-4ce0-b2b9-26b501fda75c', 'f4c2a3c02c0fe8428a2723e452e23c3b1a3ed4b1f63f8c88e7f9b87d68486b36', '2026-08-11 21:59:29.033527+00', '20260530200000_budget_degrade', NULL, NULL, '2026-08-11 21:59:29.031448+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ba4fa0bd-1c79-4c8e-8568-aa8375b8f92e', '26bdc3adbb79adbb3a47162d32c7e28553e1ed0fd001e6c0037395ebf8a9a69b', '2026-08-11 21:59:29.041042+00', '20260530210000_remove_dead_inference_subsystems', NULL, NULL, '2026-08-11 21:59:29.03393+00', 1);
INSERT INTO public._prisma_migrations VALUES ('77e77ae7-a27e-4e39-88ca-b430944e04f8', 'ee138230a7220acb263fec542831098142d7621462e050018a81bdb73937ca75', '2026-08-11 21:59:29.055556+00', '20260531120000_thought_embedding_metadata', NULL, NULL, '2026-08-11 21:59:29.053949+00', 1);
INSERT INTO public._prisma_migrations VALUES ('71437802-721d-457c-8c7d-0ccc1e9fb14a', '4bf19fb720e1098f92defe69b879c90a9c94c662de79b55e8863c0726a1047c3', '2026-08-11 21:59:29.051246+00', '20260531010200_attachments', NULL, NULL, '2026-08-11 21:59:29.047274+00', 1);
INSERT INTO public._prisma_migrations VALUES ('263615d7-2718-44d4-9f72-e4999a05e40b', 'd6ea4f2da8e6aa22d9849a496ea71491b406123e16335e61161632f342aef603', '2026-08-11 21:59:29.098454+00', '20260531140000_knowledge_base_envelope', NULL, NULL, '2026-08-11 21:59:29.061736+00', 1);
INSERT INTO public._prisma_migrations VALUES ('23f07143-6939-4e4f-a62d-7256a2cb4ca2', '85fcdf3b62dbb380619c1bcaeb86659a124ee98ebeaae0b9b8ea80c86045e45b', '2026-08-11 21:59:29.053621+00', '20260531010300_webhook_delivery_retry', NULL, NULL, '2026-08-11 21:59:29.051608+00', 1);
INSERT INTO public._prisma_migrations VALUES ('23f1d8f5-40c2-432e-81af-7d1d163ecad7', '7c9e0ad236667617d267800fd6f310f2d5dc6209c702c51c9087009aebbfab85', '2026-08-11 21:59:29.061328+00', '20260531130000_km_phase_a_memory_hygiene', NULL, NULL, '2026-08-11 21:59:29.055967+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ab2fd780-910d-40aa-a7a2-d3a469c64ee3', 'c63fe465d46687949b6f88eda1f5fda2104409b1ea7328d66537fd219797e5d3', '2026-08-11 21:59:29.109249+00', '20260607120000_push_credentials', NULL, NULL, '2026-08-11 21:59:29.104135+00', 1);
INSERT INTO public._prisma_migrations VALUES ('30ee6d66-f519-47fc-b5da-acd059000afc', '3bab5d155d3ad40d6bcce38fc4780df1fd4773fb1f76543e7d195bfc65d72bc3', '2026-08-11 21:59:29.117071+00', '20260607130000_device_tokens', NULL, NULL, '2026-08-11 21:59:29.109609+00', 1);
INSERT INTO public._prisma_migrations VALUES ('fb66731d-9dff-40b5-b42f-4a271ee7f771', '24da32ab394e0906e9dd9e3a169ba3717535abcf8ba5ac07ac526ea8067cfb23', '2026-08-11 21:59:29.118878+00', '20260607140000_channel_member_muted', NULL, NULL, '2026-08-11 21:59:29.117559+00', 1);
INSERT INTO public._prisma_migrations VALUES ('763c26d9-d754-443d-aef2-e6f8489f94fd', 'f3a09393c78c6dbc0570e636d8cf2b6245e8df0303e20e015da0a32db2717610', '2026-08-11 21:59:29.12653+00', '20260607150000_push_deliveries', NULL, NULL, '2026-08-11 21:59:29.119197+00', 1);
INSERT INTO public._prisma_migrations VALUES ('bed0e948-4ac8-417e-b3ed-35b2129856f7', '640038719cf7d818521485a5e717a43016ff91569b8954b67e83112ae7faaa5f', '2026-08-11 21:59:29.134783+00', '20260607160000_realtime_events', NULL, NULL, '2026-08-11 21:59:29.12694+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a8113fe1-2838-4777-b5f2-4fa1e82f158d', '98e32a8b9664f97f7a14f24ee0a43b235fd59218d2748c0004c4c2c1eb7e1a53', '2026-08-11 21:59:29.308625+00', '20260614140000_token_ledger_scope_indexes', NULL, NULL, '2026-08-11 21:59:29.306232+00', 1);
INSERT INTO public._prisma_migrations VALUES ('104d5329-b081-45bb-9f11-79421314c460', 'dfc9cd6928891956598843e7bfbdee9d8db72aa5c6ee79ede9ceb2d4d03789ea', '2026-08-11 21:59:29.138555+00', '20260609120000_user_presence', NULL, NULL, '2026-08-11 21:59:29.135237+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ae58b2fa-69b4-417e-a8ad-465d1d3784c1', '3b6aeba0a78acb5714620f74491963d8dc7948fb1970d8ba8960ea5c1bafbf1d', '2026-08-11 21:59:29.226163+00', '20260612140000_add_task_assignee_agent', NULL, NULL, '2026-08-11 21:59:29.223698+00', 1);
INSERT INTO public._prisma_migrations VALUES ('d3918241-9b11-4020-8b44-4bc3ca47966d', '99a73efc2199061a17a23950ad126c43eefec770049567931fc1289cf71d5635', '2026-08-11 21:59:29.163448+00', '20260610120000_user_statuses', NULL, NULL, '2026-08-11 21:59:29.138992+00', 1);
INSERT INTO public._prisma_migrations VALUES ('31f2115f-d190-47fa-b692-01f501679058', '60f671b1cfc88a0408bd2d6c00909ab3a659d0bda6f4f4fd0ccab89f96ad513a', '2026-08-11 21:59:29.166231+00', '20260610121000_user_status_rule_target_cascade', NULL, NULL, '2026-08-11 21:59:29.163952+00', 1);
INSERT INTO public._prisma_migrations VALUES ('7494e3a2-4740-438f-a80b-f0248fe0278f', 'd1aecc6363a6f60ff173d55b12402400b3228cd81112c9a192cf8fc38c6a74c2', '2026-08-11 21:59:29.268079+00', '20260613130000_knowledge_annotation_reactions', NULL, NULL, '2026-08-11 21:59:29.260673+00', 1);
INSERT INTO public._prisma_migrations VALUES ('97c8acdd-b9bb-4f2b-b2f8-0425520b548b', 'a6a0fb0476750fe18415b800df42c1b5010d0866773bd582ee22a2675a19661f', '2026-08-11 21:59:29.168955+00', '20260611120000_add_organization_logo', NULL, NULL, '2026-08-11 21:59:29.166653+00', 1);
INSERT INTO public._prisma_migrations VALUES ('d98f2c24-3e2d-444f-817b-9e12950e0c4c', '67613d7503d9647a1b889531c08c9baaf0fa203218ae741dbd6693e4a1d76d5a', '2026-08-11 21:59:29.229685+00', '20260612140000_user_presence_activity_override', NULL, NULL, '2026-08-11 21:59:29.226514+00', 1);
INSERT INTO public._prisma_migrations VALUES ('2276f943-d258-42e8-9ff2-2babc5dfa162', 'dd361a7ae632951893e2ceff040314102c7c0d4fc64988cb66ad9dcff0f356c8', '2026-08-11 21:59:29.171373+00', '20260611130000_add_task_project_id', NULL, NULL, '2026-08-11 21:59:29.169257+00', 1);
INSERT INTO public._prisma_migrations VALUES ('42ee0eb7-ae70-4273-a6c1-8021cf1ee302', '3f1ff7deb97dd90064b36761e0218ce8ad4abb48fe859fff837a8a4b0fb14007', '2026-08-11 21:59:29.179559+00', '20260611140000_add_board_columns', NULL, NULL, '2026-08-11 21:59:29.171711+00', 1);
INSERT INTO public._prisma_migrations VALUES ('e3e717b6-c1c4-4e0c-94d3-4a3c51c3bcf4', 'f121cae6d232f08d1ebb8a9783509cd9e8605f0dbeb915c1585e551e4cfdd032', '2026-08-11 21:59:29.187148+00', '20260611140000_add_feedback', NULL, NULL, '2026-08-11 21:59:29.179991+00', 1);
INSERT INTO public._prisma_migrations VALUES ('c165341e-6d8f-479e-b2cc-7304f4b49339', 'f09dbcce711a802a686609c3970fbf95303dde7538e73c29f089ba1785d3a90a', '2026-08-11 21:59:29.231665+00', '20260612150000_add_task_archived_at', NULL, NULL, '2026-08-11 21:59:29.230172+00', 1);
INSERT INTO public._prisma_migrations VALUES ('5fec16d2-2f04-40ef-b836-ac78402ce004', '882112a2c293a6682dd9f817e42cd93ae04a7ae1bcfca7356e3888553078f62c', '2026-08-11 21:59:29.199439+00', '20260611150000_add_iterations', NULL, NULL, '2026-08-11 21:59:29.187533+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a32d421a-763b-4a97-8580-283504eedcdf', '1ed9cbec7c00695e6238b383a91ae7a20439ab9bbfd55d1b37e3518de91da932', '2026-08-11 21:59:29.207481+00', '20260611160000_knowledge_space_access', NULL, NULL, '2026-08-11 21:59:29.199818+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a4caaca0-06d8-46d9-825f-fffb8e8914c8', '593ed7fbff9f489d9f100818eeb1ad192887a53225ff8e86319f67a8962c7333', '2026-08-11 21:59:29.218611+00', '20260611160000_usage_billing_ledger', NULL, NULL, '2026-08-11 21:59:29.207835+00', 1);
INSERT INTO public._prisma_migrations VALUES ('7d4c53fd-625f-4fa4-9f01-a39e7531870b', 'b35e6fe6972e4b47ccbffb9835d365c6c6646b2e307af59888341129c4774f29', '2026-08-11 21:59:29.235715+00', '20260613100000_channel_project_slugs', NULL, NULL, '2026-08-11 21:59:29.232+00', 1);
INSERT INTO public._prisma_migrations VALUES ('9e2add4a-c686-4c18-ad71-1fca45ed2695', '4c70e41ec6c5adb83a00d164b0c0dd1f964e0b737140b3a616a726ecad9b5066', '2026-08-11 21:59:29.220555+00', '20260611170000_add_user_avatar_attachment', NULL, NULL, '2026-08-11 21:59:29.218982+00', 1);
INSERT INTO public._prisma_migrations VALUES ('eeff588f-55b0-4076-988c-49eaff80dc48', '9b189086458dfcbba6279cc1eb0f7620b89d0c4c2c64f8c76b9b0ba833aad9d8', '2026-08-11 21:59:29.222078+00', '20260612120000_add_task_priority_due_date', NULL, NULL, '2026-08-11 21:59:29.220888+00', 1);
INSERT INTO public._prisma_migrations VALUES ('1171012a-7201-45b7-ac30-8b4286b77d1f', '2ce67eb5c5aceae5829b23cb88adfade54c7890a241783055ea0f020a8e53ed2', '2026-08-11 21:59:29.276421+00', '20260613130000_refresh_tokens', NULL, NULL, '2026-08-11 21:59:29.268476+00', 1);
INSERT INTO public._prisma_migrations VALUES ('f4f45637-a1b9-419c-bb91-9cf8ec8052b4', 'c75962b2e8a19f14ce7750e7d7232d917f01c9ab786eeca494f74c61d9b6b394', '2026-08-11 21:59:29.223402+00', '20260612130000_add_task_detail', NULL, NULL, '2026-08-11 21:59:29.222369+00', 1);
INSERT INTO public._prisma_migrations VALUES ('5ccbc5ad-296b-47d9-a887-ce15f0c09d53', 'a67a3b5887c35bcd100ef889a9adbad6b79d0167fa9b173fa0f971d52f575b78', '2026-08-11 21:59:29.238606+00', '20260613110000_add_agent_avatar_attachment', NULL, NULL, '2026-08-11 21:59:29.236049+00', 1);
INSERT INTO public._prisma_migrations VALUES ('21863dec-9694-4d68-b5df-d25a344fbb6b', 'bcaaedf616c5803359669f06548b0d1ed82ef49127b9c5a42583be0545796375', '2026-08-11 21:59:29.246453+00', '20260613110000_user_favorites', NULL, NULL, '2026-08-11 21:59:29.239106+00', 1);
INSERT INTO public._prisma_migrations VALUES ('58bac237-6d00-45c0-a352-d89ca2697b17', '0a61c3d50a90703869d2265e91f4bd5afa5b9b41e462d0e80f518b4154ee8745', '2026-08-11 21:59:29.363665+00', '20260706194711_mcp_oauth_dynamic', NULL, NULL, '2026-08-11 21:59:29.352297+00', 1);
INSERT INTO public._prisma_migrations VALUES ('b22b6831-4ff8-4232-911d-3287df2052e5', '798cc21947a854c3a7863f8282031e6458bf3c49483e9f54430e7f76cb918de8', '2026-08-11 21:59:29.25781+00', '20260613120000_knowledge_page_annotations', NULL, NULL, '2026-08-11 21:59:29.246937+00', 1);
INSERT INTO public._prisma_migrations VALUES ('116162df-71f4-4381-bbf4-c2eba067b89f', 'dd82daae71bea5e5ed8a6e24f09b3e23e5c542c1fb4f953b0a59df27550d1133', '2026-08-11 21:59:29.29376+00', '20260613140000_kb_file_uploads', NULL, NULL, '2026-08-11 21:59:29.276843+00', 1);
INSERT INTO public._prisma_migrations VALUES ('73b4bf30-9865-4c35-b712-724c36275f0e', '233e1532f820567cdc8ad81f4207124d7abe903363052e2d69e60bf7fa509c24', '2026-08-11 21:59:29.26029+00', '20260613130000_add_task_position', NULL, NULL, '2026-08-11 21:59:29.258263+00', 1);
INSERT INTO public._prisma_migrations VALUES ('775afeb7-117c-45ce-9ca3-a0f204ae8b16', 'c6bde9aa34514c77675161c04d4cce179d74f5fd68ce8a0ec3f7a97a32752021', '2026-08-11 21:59:29.315508+00', '20260626120000_web_push_subscriptions', NULL, NULL, '2026-08-11 21:59:29.308968+00', 1);
INSERT INTO public._prisma_migrations VALUES ('9b172fd0-e57b-4923-9980-968ab4440421', '07d61941050284076786855aee3eb2318bf93cb88a86a07610a1dda82a8dab46', '2026-08-11 21:59:29.29627+00', '20260614120000_add_member_deactivation', NULL, NULL, '2026-08-11 21:59:29.294267+00', 1);
INSERT INTO public._prisma_migrations VALUES ('0ff6e6dc-7633-4427-ad64-2474baa03647', 'b2ae30fa1b0f44f7e093cc05eb095541ac6026fcf39fc783a48c63c4304cd97a', '2026-08-11 21:59:29.305897+00', '20260614130000_kb_search_trgm', NULL, NULL, '2026-08-11 21:59:29.296673+00', 1);
INSERT INTO public._prisma_migrations VALUES ('ebd21107-a2d2-4516-9ea0-7854a53834a3', 'c30af79a090297ccbebb74064a5d31d894e453ff9f410154111c48394e1a2e58', '2026-08-11 21:59:29.339788+00', '20260706170500_system_managed_shared_agents', NULL, NULL, '2026-08-11 21:59:29.338314+00', 1);
INSERT INTO public._prisma_migrations VALUES ('d5c93b9d-5d9d-4afd-b6fd-a4a425db58ed', 'de33f2d85ed6f3e1a6d886e7037c81bf8a393cd4469c0910ca00055bd5b8f656', '2026-08-11 21:59:29.333882+00', '20260701223000_kb_page_chunks_chonkie', NULL, NULL, '2026-08-11 21:59:29.315863+00', 1);
INSERT INTO public._prisma_migrations VALUES ('e7a4c4d7-aa76-4965-a1ff-a839b0a25f6f', 'a69d67ed565df2315a6a64ac3e9cb66cb5405be02ff3bf2d2cfdf21dc0aa0f38', '2026-08-11 21:59:29.337965+00', '20260706120000_kb_space_member_agents', NULL, NULL, '2026-08-11 21:59:29.334269+00', 1);
INSERT INTO public._prisma_migrations VALUES ('658aed83-e6b2-47f6-8a92-65bdf27300b6', '3741b11df04adc38d4676298eadab21a7e56984a1988be365311d8ee7a3b0100', '2026-08-11 21:59:29.351849+00', '20260706180000_kb_links_and_ticket_docs', NULL, NULL, '2026-08-11 21:59:29.340084+00', 1);
INSERT INTO public._prisma_migrations VALUES ('4e7d2cc9-bd5b-41a6-98f5-b4ea94264cb6', '4c87eca5d2a769dd7b2ae75dcf21b5b5e5dc4b0e47042fa9b33f9113eb8339e3', '2026-08-11 21:59:29.38204+00', '20260708133000_integrated_products', NULL, NULL, '2026-08-11 21:59:29.365784+00', 1);
INSERT INTO public._prisma_migrations VALUES ('3a219110-8c25-4e3f-9c2b-ea82514f8626', '25ea063c09eaa8e70ebaac821d6742f3d98e256e07d60a96ba99a5b376e855d2', '2026-08-11 21:59:29.365395+00', '20260706210000_mcp_catalog_locking', NULL, NULL, '2026-08-11 21:59:29.364107+00', 1);
INSERT INTO public._prisma_migrations VALUES ('566160c7-2b1e-498b-991e-b803f56a27da', 'e8abd52811629ca44ac737cb5923feac0db6847b35c8febf3385e63c8c5db9e7', '2026-08-11 21:59:29.392878+00', '20260708152000_product_team_enablements', NULL, NULL, '2026-08-11 21:59:29.382404+00', 1);
INSERT INTO public._prisma_migrations VALUES ('2351b1b5-dadf-4f16-a994-085023616560', '697672fb5027834d36d529599ed13e69f4b4d53179612bf3f3d2dd322edb370f', '2026-08-11 21:59:29.397805+00', '20260708161000_first_party_mcp_catalog_entries', NULL, NULL, '2026-08-11 21:59:29.393361+00', 1);
INSERT INTO public._prisma_migrations VALUES ('c26e7153-8d32-45e9-8d26-79496a692185', 'a5b4aa8bd57c6bdd364215b9046305740de94a9d2e42e81078b8ef20789efb32', '2026-08-11 21:59:29.399801+00', '20260709120000_agent_execution_mode_external_agent', NULL, NULL, '2026-08-11 21:59:29.398352+00', 1);
INSERT INTO public._prisma_migrations VALUES ('a56c3c39-868f-4e73-964c-c42bec45db9f', '7046fecb93f1d33521d9440bdb0772195ef665a7cb53ba480f357a9ca8fdc5e1', '2026-08-11 21:59:29.401783+00', '20260709121000_deepsignal_product', NULL, NULL, '2026-08-11 21:59:29.400166+00', 1);
INSERT INTO public._prisma_migrations VALUES ('182c672f-b8ba-42e2-8eda-9220f3fda2a3', '2eb02be91fef91bca3fd82ef723381259342aebe9ababab45f33702cde2a199f', '2026-08-11 21:59:29.499641+00', '20260722020000_bind_uoa_session_identity', NULL, NULL, '2026-08-11 21:59:29.491655+00', 1);
INSERT INTO public._prisma_migrations VALUES ('8842e27e-f9b5-48aa-b0d9-8f0121a8b9c7', '5ff77afd2d9d1a6032ec43b87e244f9e902634bb3abd39d66b1e01281db178ed', '2026-08-11 21:59:29.404218+00', '20260709122000_thread_metadata', NULL, NULL, '2026-08-11 21:59:29.402336+00', 1);
INSERT INTO public._prisma_migrations VALUES ('b0f5537c-6090-4fc1-aacd-941ce26f8a0d', 'bfa8a541c215a930ac9b8ae56546a1f3617f201525d8378dc348bdafe5632ecf', '2026-08-11 21:59:29.411204+00', '20260709123000_product_webhook_secret', NULL, NULL, '2026-08-11 21:59:29.404545+00', 1);
INSERT INTO public._prisma_migrations VALUES ('c2314d2d-e3ef-4d0f-a3db-c3b12c47d228', 'cedb42ee696b6311e1eff526afb163e5158bdd3f8d7ecaf4d8fbcc16f7e4c960', '2026-08-11 21:59:29.426894+00', '20260710103000_product_integration_runs', NULL, NULL, '2026-08-11 21:59:29.411595+00', 1);
INSERT INTO public._prisma_migrations VALUES ('1a1d21e0-76cb-4725-9b2a-3ca3f9ffa4ae', 'd5a3956be293ba84da5c88b2a1451002381ed6b5fc5cc6af9277067b9daeba2f', '2026-08-11 21:59:29.501613+00', '20260722033000_nessie_account_link_product', NULL, NULL, '2026-08-11 21:59:29.500056+00', 1);
INSERT INTO public._prisma_migrations VALUES ('3e39024d-57e4-4e0e-94f6-3e9e8ed837a5', '7303eefa712289a5a1b9830c31321d78bb4e43fc711df4f2d96aa7c5511600ff', '2026-08-11 21:59:29.42917+00', '20260710150000_team_external_workspace', NULL, NULL, '2026-08-11 21:59:29.42726+00', 1);
INSERT INTO public._prisma_migrations VALUES ('eae79a92-0c7f-4d06-9411-8118dec56f12', '80fbead0eb1d22cc93829295828d65d87f853cc7deaebddc2ec3d3e848864b3b', '2026-08-11 21:59:29.433956+00', '20260718120000_deepwater_via_ledger_mcp', NULL, NULL, '2026-08-11 21:59:29.430298+00', 1);
INSERT INTO public._prisma_migrations VALUES ('94ebe4e2-c142-448d-8e96-32360143ee09', '04fe22a08859bfdbc53ffeddcb2c86d6fad13e8144164293a4e04d2f1b0669f5', '2026-08-11 21:59:29.43815+00', '20260718190000_ledger_identity_attribution', NULL, NULL, '2026-08-11 21:59:29.434352+00', 1);
INSERT INTO public._prisma_migrations VALUES ('e568da0e-a8b4-4d5f-906e-0c75e5aced1f', '2b7d12a781d4cf7bd130d6f085c83f5ac4df80e74351ef2c704776242ebecde5', '2026-08-11 21:59:29.440735+00', '20260719143000_deepwater_app_api_key_boundary', NULL, NULL, '2026-08-11 21:59:29.438518+00', 1);
INSERT INTO public._prisma_migrations VALUES ('792f6185-bfa5-4f1a-96ab-b51a761d1d9a', '0c3d6eb4752a52cb830f86e1e7b6aac615a08b096fee96910447146e7abac400', '2026-08-11 21:59:29.444257+00', '20260719190000_deepsignal_app_api_key_boundary', NULL, NULL, '2026-08-11 21:59:29.441096+00', 1);
INSERT INTO public._prisma_migrations VALUES ('8e1b824a-f65a-4cf5-9898-c8485b9e75da', '6828290cc3f7aa2dcb4ae5fd2ef7541f9a0db479113ad22bca609d49cb3a32fc', '2026-08-11 21:59:29.447877+00', '20260720150000_deepwater_report_metadata_provenance', NULL, NULL, '2026-08-11 21:59:29.444636+00', 1);
INSERT INTO public._prisma_migrations VALUES ('6a4651ac-8992-458f-953a-038c96ed2882', 'd6b7f1e59c7e33c9b5d0615619942584411a223d3e7b8151f24223630dccb515', '2026-08-11 21:59:29.450082+00', '20260720234500_retire_deepwater_local_cost_mirror', NULL, NULL, '2026-08-11 21:59:29.44832+00', 1);
INSERT INTO public._prisma_migrations VALUES ('d281330c-a927-4543-aabd-81effbfe251a', 'd6a8bdb44d75c84c76f23834c53816f22a5bc37a1f1db1514de0b3dbfdf73c1b', '2026-08-11 21:59:29.451775+00', '20260721000000_agent_effort_level', NULL, NULL, '2026-08-11 21:59:29.450389+00', 1);
INSERT INTO public._prisma_migrations VALUES ('df3d9c74-bf90-48cb-83cc-9aa2a4a6d080', '1fa95f45526704a7a818d20750719f530955109073e32b5a7e68d0ec7a3acf1e', '2026-08-11 21:59:29.491123+00', '20260721120000_individual_comms_connectors', NULL, NULL, '2026-08-11 21:59:29.452226+00', 1);


--
-- Data for Name: agent_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_mailbox_messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_trigger_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_triggers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: board_columns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: call_participants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_connection_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_connections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_resources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: comms_sync_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: connector_usage_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: execution_environment_instances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: execution_environment_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: execution_leases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: execution_runners; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: execution_usage_ledger; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inference_credential_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inference_models; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inference_providers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inference_routing_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: integrated_products; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.integrated_products VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d103', 'buildme', 'buildme.live', 'Project definition, scheduling, and BuildMe project-board handoff.', 'project_management', 'https://buildme.live', NULL, 'uoa_sso', 'link_only', NULL, 'first-party/buildme', 'unknown', NULL, '{launch,uoa_account_link,project_board_source_pending}', 'Link through UOA now; native board pairing waits for the BuildMe board API contract.', 30, '2026-08-11 21:59:29.366', '2026-08-11 21:59:29.366');
INSERT INTO public.integrated_products VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d102', 'deeptest', 'DeepTest', 'Security review, local MCP execution, and share-safe reports.', 'security', 'https://deeptest.live', NULL, 'local_mcp', 'installable', '8f3a5a00-0e64-4d10-a517-0d0b69c1d112', 'first-party/deeptest', 'setup_required', NULL, '{security_review,share_safe_report,local_mcp}', 'Install or connect a DeepTest MCP runner before agents can request reviews.', 20, '2026-08-11 21:59:29.366', '2026-08-11 21:59:29.393');
INSERT INTO public.integrated_products VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d104', 'deepsignal', 'DeepSignal', 'Objective-first decision intelligence: autonomous signal monitoring that surfaces the opportunities and risks that matter.', 'research', 'https://deepsignal.live', NULL, 'uoa_sso', 'native', '8f3a5a00-0e64-4d10-a517-0d0b69c1d114', 'first-party/deepsignal', 'setup_required', 'Requires DEEPSIGNAL_MCP_APP_KEY and configured UOA signing/client credentials.', '{external_agent,signal_monitoring,insight_digest,conversation}', 'Activate DeepSignal using your existing Nessie UOA identity. Nessie authenticates with its dedicated DeepSignal app key and delegates your active workspace per request.', 15, '2026-08-11 21:59:29.4', '2026-08-11 21:59:29.441');
INSERT INTO public.integrated_products VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d101', 'deep-water', 'Deep Water', 'Ledger-metered Deep Water research jobs, sources, and reports. Customer totals come only from UOA.', 'research', NULL, NULL, 'uoa_sso', 'native', '8f3a5a00-0e64-4d10-a517-0d0b69c1d111', 'first-party/deep-water', 'setup_required', 'Requires LEDGER_DEEPWATER_MCP_URL, Nessie''s product-bound Ledger app API key in LEDGER_PROXY_TOKEN, and configured UOA signing credentials.', '{deep_research,sources,raw_usage,knowledge_import}', 'Enable Deep Water after configuring Nessie''s dedicated Ledger app API key. Signed SSO identity attributes raw usage to its user, organization, and team; UOA supplies customer totals.', 10, '2026-08-11 21:59:29.366', '2026-08-11 21:59:29.448');
INSERT INTO public.integrated_products VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d100', 'nessie', 'Nessie', 'Internal first-party UOA account-link identity anchor.', 'project_management', 'https://app.nessie.works', 'https://api.nessie.works', 'uoa_sso', 'native', NULL, 'first-party/nessie', 'healthy', NULL, '{uoa_account_link}', NULL, 0, '2026-08-11 21:59:29.5', '2026-08-11 21:59:29.5');


--
-- Data for Name: iterations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_page_annotation_reactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_page_annotations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_page_chunks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_page_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_page_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_pages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_space_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: knowledge_spaces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_catalog_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.mcp_catalog_entries VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d112', NULL, 'deeptest', 'DeepTest', 'DeepTest MCP server for local-first security review requests, review status, and share-safe report retrieval.', 'http', 'none', '{"method": "none"}', '{"setup": "Set a DeepTest local runner or remote-runner MCP endpoint when installing this connector.", "urlEnv": "DEEPTEST_MCP_URL", "localOnly": true}', NULL, 'UnlikeOtherAI', 'https://deeptest.live', NULL, 'published', '00000000-0000-0000-0000-000000000000', '2026-08-11 21:59:29.393', '2026-08-11 21:59:29.393', 'public', NULL, NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.mcp_catalog_entries VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d111', NULL, 'deep-water', 'Deep Water', 'Ledger-metered Deep Water research MCP adapter for starting jobs, polling status, reading reports, listing jobs, and cancelling jobs.', 'http', 'bearer', '{"method": "bearer"}', '{"setup": "Set the Ledger DeepWater MCP adapter URL and Nessie''s dedicated Ledger app API key in LEDGER_PROXY_TOKEN. Signed SSO caller identity is supplied independently; never reuse webhook signing secrets as this key.", "urlEnv": "LEDGER_DEEPWATER_MCP_URL"}', NULL, 'UnlikeOtherAI', NULL, NULL, 'published', '00000000-0000-0000-0000-000000000000', '2026-08-11 21:59:29.393', '2026-08-11 21:59:29.439', 'public', NULL, NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.mcp_catalog_entries VALUES ('8f3a5a00-0e64-4d10-a517-0d0b69c1d114', NULL, 'deepsignal', 'DeepSignal', 'DeepSignal MCP server for app-key-authenticated Nessie conversations, history, and insight actions with independently signed UOA actor context.', 'http', 'bearer', '{"method": "bearer"}', '{"url": "https://api.deepsignal.live/mcp", "transport": "http"}', NULL, 'DeepSignal', 'https://deepsignal.live', NULL, 'published', '00000000-0000-0000-0000-000000000000', '2026-08-11 21:59:29.4', '2026-08-11 21:59:29.441', 'public', NULL, NULL, NULL, NULL, NULL, false, NULL, NULL);


--
-- Data for Name: mcp_oauth_clients; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_oauth_secret; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_server_credential_overrides; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_server_instances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: message_reactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_pricing_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organization_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: page_labels; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_steps; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: policy_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: policy_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_account_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_integration_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_team_enablements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_webhook_secrets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: push_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: push_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: queue_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: realtime_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: resource_locks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: storage_usage_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: temporary_context_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thought_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thought_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thought_reasonings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thought_recalls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thoughts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thread_read_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: thread_stream_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: threads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: token_ledger_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tool_bundles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tool_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tool_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tool_registry_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: uoa_session_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_presence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_status_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_status_schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_statuses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: web_push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_installations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_state_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_step_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: realtime_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.realtime_events_id_seq', 1, false);


--
-- Name: thread_stream_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.thread_stream_events_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: agent_bindings agent_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bindings
    ADD CONSTRAINT agent_bindings_pkey PRIMARY KEY (id);


--
-- Name: agent_mailbox_messages agent_mailbox_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mailbox_messages
    ADD CONSTRAINT agent_mailbox_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_trigger_deliveries agent_trigger_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_trigger_deliveries
    ADD CONSTRAINT agent_trigger_deliveries_pkey PRIMARY KEY (id);


--
-- Name: agent_triggers agent_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: board_columns board_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_columns
    ADD CONSTRAINT board_columns_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: call_participants call_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_participants
    ADD CONSTRAINT call_participants_pkey PRIMARY KEY (id);


--
-- Name: calls calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_pkey PRIMARY KEY (id);


--
-- Name: channel_members channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_members
    ADD CONSTRAINT channel_members_pkey PRIMARY KEY (id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: comms_connection_credentials comms_connection_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_connection_credentials
    ADD CONSTRAINT comms_connection_credentials_pkey PRIMARY KEY (id);


--
-- Name: comms_connections comms_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_connections
    ADD CONSTRAINT comms_connections_pkey PRIMARY KEY (id);


--
-- Name: comms_events comms_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_events
    ADD CONSTRAINT comms_events_pkey PRIMARY KEY (id);


--
-- Name: comms_oauth_states comms_oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_oauth_states
    ADD CONSTRAINT comms_oauth_states_pkey PRIMARY KEY (token);


--
-- Name: comms_resources comms_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_resources
    ADD CONSTRAINT comms_resources_pkey PRIMARY KEY (id);


--
-- Name: comms_subscriptions comms_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_subscriptions
    ADD CONSTRAINT comms_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: comms_sync_jobs comms_sync_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_sync_jobs
    ADD CONSTRAINT comms_sync_jobs_pkey PRIMARY KEY (id);


--
-- Name: connector_usage_events connector_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_usage_events
    ADD CONSTRAINT connector_usage_events_pkey PRIMARY KEY (id);


--
-- Name: device_tokens device_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_pkey PRIMARY KEY (id);


--
-- Name: execution_environment_instances execution_environment_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_instances
    ADD CONSTRAINT execution_environment_instances_pkey PRIMARY KEY (id);


--
-- Name: execution_environment_templates execution_environment_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_templates
    ADD CONSTRAINT execution_environment_templates_pkey PRIMARY KEY (id);


--
-- Name: execution_leases execution_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_leases
    ADD CONSTRAINT execution_leases_pkey PRIMARY KEY (id);


--
-- Name: execution_runners execution_runners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_runners
    ADD CONSTRAINT execution_runners_pkey PRIMARY KEY (id);


--
-- Name: execution_usage_ledger execution_usage_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_usage_ledger
    ADD CONSTRAINT execution_usage_ledger_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: inference_credential_bindings inference_credential_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_credential_bindings
    ADD CONSTRAINT inference_credential_bindings_pkey PRIMARY KEY (id);


--
-- Name: inference_models inference_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_models
    ADD CONSTRAINT inference_models_pkey PRIMARY KEY (id);


--
-- Name: inference_providers inference_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_providers
    ADD CONSTRAINT inference_providers_pkey PRIMARY KEY (id);


--
-- Name: inference_routing_profiles inference_routing_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_routing_profiles
    ADD CONSTRAINT inference_routing_profiles_pkey PRIMARY KEY (id);


--
-- Name: integrated_products integrated_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integrated_products
    ADD CONSTRAINT integrated_products_pkey PRIMARY KEY (id);


--
-- Name: iterations iterations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iterations
    ADD CONSTRAINT iterations_pkey PRIMARY KEY (id);


--
-- Name: knowledge_page_annotation_reactions knowledge_page_annotation_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_annotation_reactions
    ADD CONSTRAINT knowledge_page_annotation_reactions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_page_annotations knowledge_page_annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_annotations
    ADD CONSTRAINT knowledge_page_annotations_pkey PRIMARY KEY (id);


--
-- Name: knowledge_page_chunks knowledge_page_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_chunks
    ADD CONSTRAINT knowledge_page_chunks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_page_links knowledge_page_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_links
    ADD CONSTRAINT knowledge_page_links_pkey PRIMARY KEY (id);


--
-- Name: knowledge_page_versions knowledge_page_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_versions
    ADD CONSTRAINT knowledge_page_versions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_pages knowledge_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_pages
    ADD CONSTRAINT knowledge_pages_pkey PRIMARY KEY (id);


--
-- Name: knowledge_space_members knowledge_space_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_space_members
    ADD CONSTRAINT knowledge_space_members_pkey PRIMARY KEY (id);


--
-- Name: knowledge_spaces knowledge_spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_spaces
    ADD CONSTRAINT knowledge_spaces_pkey PRIMARY KEY (id);


--
-- Name: mcp_catalog_entries mcp_catalog_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_catalog_entries
    ADD CONSTRAINT mcp_catalog_entries_pkey PRIMARY KEY (id);


--
-- Name: mcp_oauth_clients mcp_oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_oauth_clients
    ADD CONSTRAINT mcp_oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: mcp_oauth_secret mcp_oauth_secret_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_oauth_secret
    ADD CONSTRAINT mcp_oauth_secret_pkey PRIMARY KEY (ref);


--
-- Name: mcp_oauth_states mcp_oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_oauth_states
    ADD CONSTRAINT mcp_oauth_states_pkey PRIMARY KEY (token);


--
-- Name: mcp_server_credential_overrides mcp_server_credential_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_credential_overrides
    ADD CONSTRAINT mcp_server_credential_overrides_pkey PRIMARY KEY (id);


--
-- Name: mcp_server_instances mcp_server_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_instances
    ADD CONSTRAINT mcp_server_instances_pkey PRIMARY KEY (id);


--
-- Name: message_reactions message_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: model_pricing_profiles model_pricing_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_pricing_profiles
    ADD CONSTRAINT model_pricing_profiles_pkey PRIMARY KEY (id);


--
-- Name: organization_members organization_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: page_labels page_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_labels
    ADD CONSTRAINT page_labels_pkey PRIMARY KEY (id);


--
-- Name: plan_steps plan_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_steps
    ADD CONSTRAINT plan_steps_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: policy_bindings policy_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_bindings
    ADD CONSTRAINT policy_bindings_pkey PRIMARY KEY (id);


--
-- Name: policy_rules policy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_rules
    ADD CONSTRAINT policy_rules_pkey PRIMARY KEY (id);


--
-- Name: product_account_links product_account_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_account_links
    ADD CONSTRAINT product_account_links_pkey PRIMARY KEY (id);


--
-- Name: product_integration_runs product_integration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_pkey PRIMARY KEY (id);


--
-- Name: product_team_enablements product_team_enablements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_team_enablements
    ADD CONSTRAINT product_team_enablements_pkey PRIMARY KEY (id);


--
-- Name: product_webhook_secrets product_webhook_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook_secrets
    ADD CONSTRAINT product_webhook_secrets_pkey PRIMARY KEY (id);


--
-- Name: project_members project_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: push_credentials push_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_credentials
    ADD CONSTRAINT push_credentials_pkey PRIMARY KEY (id);


--
-- Name: push_deliveries push_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_deliveries
    ADD CONSTRAINT push_deliveries_pkey PRIMARY KEY (id);


--
-- Name: queue_jobs queue_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue_jobs
    ADD CONSTRAINT queue_jobs_pkey PRIMARY KEY (id);


--
-- Name: realtime_events realtime_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realtime_events
    ADD CONSTRAINT realtime_events_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: resource_locks resource_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_locks
    ADD CONSTRAINT resource_locks_pkey PRIMARY KEY (id);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (id);


--
-- Name: storage_usage_events storage_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_usage_events
    ADD CONSTRAINT storage_usage_events_pkey PRIMARY KEY (id);


--
-- Name: task_events task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: temporary_context_sessions temporary_context_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.temporary_context_sessions
    ADD CONSTRAINT temporary_context_sessions_pkey PRIMARY KEY (id);


--
-- Name: thought_audit_logs thought_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_audit_logs
    ADD CONSTRAINT thought_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: thought_links thought_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_links
    ADD CONSTRAINT thought_links_pkey PRIMARY KEY (id);


--
-- Name: thought_reasonings thought_reasonings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_reasonings
    ADD CONSTRAINT thought_reasonings_pkey PRIMARY KEY (id);


--
-- Name: thought_recalls thought_recalls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_recalls
    ADD CONSTRAINT thought_recalls_pkey PRIMARY KEY (id);


--
-- Name: thoughts thoughts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thoughts
    ADD CONSTRAINT thoughts_pkey PRIMARY KEY (id);


--
-- Name: thread_read_states thread_read_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_read_states
    ADD CONSTRAINT thread_read_states_pkey PRIMARY KEY (id);


--
-- Name: thread_stream_events thread_stream_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_stream_events
    ADD CONSTRAINT thread_stream_events_pkey PRIMARY KEY (id);


--
-- Name: threads threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_pkey PRIMARY KEY (id);


--
-- Name: token_ledger_events token_ledger_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_ledger_events
    ADD CONSTRAINT token_ledger_events_pkey PRIMARY KEY (id);


--
-- Name: tool_bundles tool_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_bundles
    ADD CONSTRAINT tool_bundles_pkey PRIMARY KEY (id);


--
-- Name: tool_calls tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_pkey PRIMARY KEY (id);


--
-- Name: tool_grants tool_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_grants
    ADD CONSTRAINT tool_grants_pkey PRIMARY KEY (id);


--
-- Name: tool_registry_entries tool_registry_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_registry_entries
    ADD CONSTRAINT tool_registry_entries_pkey PRIMARY KEY (id);


--
-- Name: uoa_session_credentials uoa_session_credentials_last_local_token_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoa_session_credentials
    ADD CONSTRAINT uoa_session_credentials_last_local_token_id_key UNIQUE (last_local_token_id);


--
-- Name: uoa_session_credentials uoa_session_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoa_session_credentials
    ADD CONSTRAINT uoa_session_credentials_pkey PRIMARY KEY (family_id);


--
-- Name: uoa_session_credentials uoa_session_credentials_refresh_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoa_session_credentials
    ADD CONSTRAINT uoa_session_credentials_refresh_token_hash_key UNIQUE (refresh_token_hash);


--
-- Name: user_presence user_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_presence
    ADD CONSTRAINT user_presence_pkey PRIMARY KEY (user_id);


--
-- Name: user_status_rules user_status_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_rules
    ADD CONSTRAINT user_status_rules_pkey PRIMARY KEY (id);


--
-- Name: user_status_schedules user_status_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_schedules
    ADD CONSTRAINT user_status_schedules_pkey PRIMARY KEY (id);


--
-- Name: user_statuses user_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_statuses
    ADD CONSTRAINT user_statuses_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: web_push_subscriptions web_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: workflow_installations workflow_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_installations
    ADD CONSTRAINT workflow_installations_pkey PRIMARY KEY (id);


--
-- Name: workflow_runs workflow_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_pkey PRIMARY KEY (id);


--
-- Name: workflow_state_entries workflow_state_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_state_entries
    ADD CONSTRAINT workflow_state_entries_pkey PRIMARY KEY (id);


--
-- Name: workflow_step_runs workflow_step_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_step_runs
    ADD CONSTRAINT workflow_step_runs_pkey PRIMARY KEY (id);


--
-- Name: workflow_templates workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_pkey PRIMARY KEY (id);


--
-- Name: agent_bindings_agent_id_channel_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_bindings_agent_id_channel_id_key ON public.agent_bindings USING btree (agent_id, channel_id);


--
-- Name: agent_bindings_channel_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_bindings_channel_id_idx ON public.agent_bindings USING btree (channel_id);


--
-- Name: agent_mailbox_messages_organization_id_status_visible_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_mailbox_messages_organization_id_status_visible_at_idx ON public.agent_mailbox_messages USING btree (organization_id, status, visible_at);


--
-- Name: agent_mailbox_messages_plan_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_mailbox_messages_plan_id_created_at_idx ON public.agent_mailbox_messages USING btree (plan_id, created_at);


--
-- Name: agent_mailbox_messages_thread_id_status_visible_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_mailbox_messages_thread_id_status_visible_at_idx ON public.agent_mailbox_messages USING btree (thread_id, status, visible_at);


--
-- Name: agent_mailbox_messages_to_agent_id_correlation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_mailbox_messages_to_agent_id_correlation_id_key ON public.agent_mailbox_messages USING btree (to_agent_id, correlation_id);


--
-- Name: agent_mailbox_messages_to_agent_id_status_visible_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_mailbox_messages_to_agent_id_status_visible_at_idx ON public.agent_mailbox_messages USING btree (to_agent_id, status, visible_at);


--
-- Name: agent_mailbox_messages_workflow_run_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_mailbox_messages_workflow_run_id_created_at_idx ON public.agent_mailbox_messages USING btree (workflow_run_id, created_at);


--
-- Name: agent_trigger_deliveries_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_trigger_deliveries_status_created_at_idx ON public.agent_trigger_deliveries USING btree (status, created_at);


--
-- Name: agent_trigger_deliveries_status_next_retry_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_trigger_deliveries_status_next_retry_at_idx ON public.agent_trigger_deliveries USING btree (status, next_retry_at);


--
-- Name: agent_trigger_deliveries_trigger_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_trigger_deliveries_trigger_id_created_at_idx ON public.agent_trigger_deliveries USING btree (trigger_id, created_at);


--
-- Name: agent_trigger_deliveries_trigger_id_dedupe_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_trigger_deliveries_trigger_id_dedupe_key_key ON public.agent_trigger_deliveries USING btree (trigger_id, dedupe_key);


--
-- Name: agent_triggers_agent_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_agent_id_created_at_idx ON public.agent_triggers USING btree (agent_id, created_at);


--
-- Name: agent_triggers_agent_id_enabled_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_agent_id_enabled_status_idx ON public.agent_triggers USING btree (agent_id, enabled, status);


--
-- Name: agent_triggers_target_channel_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_target_channel_id_idx ON public.agent_triggers USING btree (target_channel_id);


--
-- Name: agent_triggers_target_thread_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_target_thread_id_idx ON public.agent_triggers USING btree (target_thread_id);


--
-- Name: agent_triggers_type_enabled_status_next_run_at_scheduler_cl_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_type_enabled_status_next_run_at_scheduler_cl_idx ON public.agent_triggers USING btree (type, enabled, status, next_run_at, scheduler_claimed_at);


--
-- Name: agent_triggers_workflow_installation_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_workflow_installation_id_created_at_idx ON public.agent_triggers USING btree (workflow_installation_id, created_at);


--
-- Name: agent_triggers_workflow_installation_id_enabled_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_triggers_workflow_installation_id_enabled_status_idx ON public.agent_triggers USING btree (workflow_installation_id, enabled, status);


--
-- Name: agents_avatar_attachment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_avatar_attachment_id_idx ON public.agents USING btree (avatar_attachment_id);


--
-- Name: agents_organization_id_agent_kind_system_managed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_organization_id_agent_kind_system_managed_idx ON public.agents USING btree (organization_id, agent_kind, system_managed);


--
-- Name: agents_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_organization_id_idx ON public.agents USING btree (organization_id);


--
-- Name: agents_organization_id_project_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_organization_id_project_id_idx ON public.agents USING btree (organization_id, project_id);


--
-- Name: agents_personal_assistant_organization_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agents_personal_assistant_organization_id_key ON public.agents USING btree (organization_id) WHERE ((agent_kind = 'personal_assistant'::public."AgentKind") AND (system_managed = true));


--
-- Name: agents_routing_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_routing_profile_id_idx ON public.agents USING btree (routing_profile_id);


--
-- Name: approval_requests_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_requests_agent_id_status_idx ON public.approval_requests USING btree (agent_id, status);


--
-- Name: approval_requests_organization_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_requests_organization_id_status_idx ON public.approval_requests USING btree (organization_id, status);


--
-- Name: approval_requests_status_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_requests_status_expires_at_idx ON public.approval_requests USING btree (status, expires_at);


--
-- Name: attachments_knowledge_page_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_knowledge_page_id_idx ON public.attachments USING btree (knowledge_page_id);


--
-- Name: attachments_message_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_message_id_idx ON public.attachments USING btree (message_id);


--
-- Name: attachments_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_organization_id_created_at_idx ON public.attachments USING btree (organization_id, created_at);


--
-- Name: audit_logs_organization_id_action_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_organization_id_action_created_at_idx ON public.audit_logs USING btree (organization_id, action, created_at DESC);


--
-- Name: audit_logs_organization_id_actor_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_organization_id_actor_id_created_at_idx ON public.audit_logs USING btree (organization_id, actor_id, created_at DESC);


--
-- Name: audit_logs_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_organization_id_created_at_idx ON public.audit_logs USING btree (organization_id, created_at DESC);


--
-- Name: audit_logs_organization_id_resource_type_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_organization_id_resource_type_created_at_idx ON public.audit_logs USING btree (organization_id, resource_type, created_at DESC);


--
-- Name: audit_logs_organization_id_resource_type_resource_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_organization_id_resource_type_resource_id_idx ON public.audit_logs USING btree (organization_id, resource_type, resource_id);


--
-- Name: board_columns_project_id_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX board_columns_project_id_position_idx ON public.board_columns USING btree (project_id, "position");


--
-- Name: budgets_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budgets_organization_id_idx ON public.budgets USING btree (organization_id);


--
-- Name: budgets_scope_type_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX budgets_scope_type_scope_id_key ON public.budgets USING btree (scope_type, scope_id);


--
-- Name: call_participants_call_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX call_participants_call_id_user_id_key ON public.call_participants USING btree (call_id, user_id);


--
-- Name: calls_channel_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calls_channel_id_idx ON public.calls USING btree (channel_id);


--
-- Name: calls_room_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX calls_room_id_key ON public.calls USING btree (room_id);


--
-- Name: calls_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calls_status_idx ON public.calls USING btree (status);


--
-- Name: channel_members_channel_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channel_members_channel_id_user_id_key ON public.channel_members USING btree (channel_id, user_id);


--
-- Name: channel_members_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_members_user_id_idx ON public.channel_members USING btree (user_id);


--
-- Name: channels_dm_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channels_dm_key_key ON public.channels USING btree (dm_key);


--
-- Name: channels_organization_id_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channels_organization_id_type_idx ON public.channels USING btree (organization_id, type);


--
-- Name: channels_project_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channels_project_id_idx ON public.channels USING btree (project_id);


--
-- Name: channels_project_slug_standard_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channels_project_slug_standard_key ON public.channels USING btree (project_id, slug) WHERE (type = 'standard'::public."ChannelType");


--
-- Name: comms_connection_credentials_connection_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX comms_connection_credentials_connection_id_key ON public.comms_connection_credentials USING btree (connection_id);


--
-- Name: comms_connections_organization_id_owner_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_connections_organization_id_owner_user_id_idx ON public.comms_connections USING btree (organization_id, owner_user_id);


--
-- Name: comms_connections_organization_id_owner_user_id_provider_ext_ke; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX comms_connections_organization_id_owner_user_id_provider_ext_ke ON public.comms_connections USING btree (organization_id, owner_user_id, provider, external_tenant_id, external_user_id);


--
-- Name: comms_connections_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_connections_status_idx ON public.comms_connections USING btree (status);


--
-- Name: comms_events_connection_id_canonical_message_id_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX comms_events_connection_id_canonical_message_id_version_key ON public.comms_events USING btree (connection_id, canonical_message_id, version);


--
-- Name: comms_events_connection_id_conversation_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_events_connection_id_conversation_id_occurred_at_idx ON public.comms_events USING btree (connection_id, conversation_id, occurred_at);


--
-- Name: comms_events_organization_id_connection_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_events_organization_id_connection_id_occurred_at_idx ON public.comms_events USING btree (organization_id, connection_id, occurred_at);


--
-- Name: comms_oauth_states_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_oauth_states_expires_at_idx ON public.comms_oauth_states USING btree (expires_at);


--
-- Name: comms_oauth_states_organization_id_user_id_provider_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_oauth_states_organization_id_user_id_provider_idx ON public.comms_oauth_states USING btree (organization_id, user_id, provider);


--
-- Name: comms_resources_connection_id_external_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX comms_resources_connection_id_external_id_key ON public.comms_resources USING btree (connection_id, external_id);


--
-- Name: comms_resources_connection_id_sync_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_resources_connection_id_sync_enabled_idx ON public.comms_resources USING btree (connection_id, sync_enabled);


--
-- Name: comms_subscriptions_connection_id_external_subscription_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX comms_subscriptions_connection_id_external_subscription_id_key ON public.comms_subscriptions USING btree (connection_id, external_subscription_id);


--
-- Name: comms_subscriptions_status_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_subscriptions_status_expires_at_idx ON public.comms_subscriptions USING btree (status, expires_at);


--
-- Name: comms_sync_jobs_connection_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_sync_jobs_connection_id_status_idx ON public.comms_sync_jobs USING btree (connection_id, status);


--
-- Name: comms_sync_jobs_resource_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comms_sync_jobs_resource_id_idx ON public.comms_sync_jobs USING btree (resource_id);


--
-- Name: connector_usage_events_org_agent_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_org_agent_id_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, agent_id, occurred_at DESC);


--
-- Name: connector_usage_events_org_channel_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_org_channel_id_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, channel_id, occurred_at DESC);


--
-- Name: connector_usage_events_org_connector_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_org_connector_id_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, connector_id, occurred_at DESC);


--
-- Name: connector_usage_events_org_connector_type_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_org_connector_type_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, connector_type, occurred_at DESC);


--
-- Name: connector_usage_events_org_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_org_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, occurred_at DESC);


--
-- Name: connector_usage_events_org_run_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_org_run_id_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, run_id, occurred_at DESC);


--
-- Name: connector_usage_events_organization_id_user_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_usage_events_organization_id_user_id_occurred_at_idx ON public.connector_usage_events USING btree (organization_id, user_id, occurred_at DESC);


--
-- Name: device_tokens_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX device_tokens_organization_id_idx ON public.device_tokens USING btree (organization_id);


--
-- Name: device_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX device_tokens_user_id_idx ON public.device_tokens USING btree (user_id);


--
-- Name: device_tokens_user_id_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX device_tokens_user_id_token_key ON public.device_tokens USING btree (user_id, token);


--
-- Name: execution_environment_instances_organization_id_status_crea_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_environment_instances_organization_id_status_crea_idx ON public.execution_environment_instances USING btree (organization_id, status, created_at DESC);


--
-- Name: execution_environment_instances_template_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_environment_instances_template_id_created_at_idx ON public.execution_environment_instances USING btree (template_id, created_at DESC);


--
-- Name: execution_environment_instances_workflow_run_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_environment_instances_workflow_run_id_created_at_idx ON public.execution_environment_instances USING btree (workflow_run_id, created_at DESC);


--
-- Name: execution_environment_instances_workflow_step_run_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX execution_environment_instances_workflow_step_run_id_key ON public.execution_environment_instances USING btree (workflow_step_run_id);


--
-- Name: execution_environment_templates_organization_id_enabled_cre_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_environment_templates_organization_id_enabled_cre_idx ON public.execution_environment_templates USING btree (organization_id, enabled, created_at DESC);


--
-- Name: execution_environment_templates_organization_id_provider_mo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_environment_templates_organization_id_provider_mo_idx ON public.execution_environment_templates USING btree (organization_id, provider, mode);


--
-- Name: execution_leases_instance_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_leases_instance_id_status_created_at_idx ON public.execution_leases USING btree (instance_id, status, created_at DESC);


--
-- Name: execution_leases_lease_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX execution_leases_lease_token_key ON public.execution_leases USING btree (lease_token);


--
-- Name: execution_leases_runner_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_leases_runner_id_status_created_at_idx ON public.execution_leases USING btree (runner_id, status, created_at DESC);


--
-- Name: execution_runners_organization_id_provider_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_runners_organization_id_provider_status_idx ON public.execution_runners USING btree (organization_id, provider, status);


--
-- Name: execution_runners_provider_label_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX execution_runners_provider_label_key ON public.execution_runners USING btree (provider, label);


--
-- Name: execution_usage_ledger_instance_id_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_usage_ledger_instance_id_recorded_at_idx ON public.execution_usage_ledger USING btree (instance_id, recorded_at DESC);


--
-- Name: execution_usage_ledger_organization_id_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_usage_ledger_organization_id_recorded_at_idx ON public.execution_usage_ledger USING btree (organization_id, recorded_at DESC);


--
-- Name: execution_usage_ledger_workflow_run_id_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_usage_ledger_workflow_run_id_recorded_at_idx ON public.execution_usage_ledger USING btree (workflow_run_id, recorded_at DESC);


--
-- Name: favorites_organization_id_target_type_target_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX favorites_organization_id_target_type_target_id_idx ON public.favorites USING btree (organization_id, target_type, target_id);


--
-- Name: favorites_user_id_organization_id_target_type_target_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX favorites_user_id_organization_id_target_type_target_id_key ON public.favorites USING btree (user_id, organization_id, target_type, target_id);


--
-- Name: feedback_organization_id_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_organization_id_user_id_created_at_idx ON public.feedback USING btree (organization_id, user_id, created_at);


--
-- Name: idx_agent_mailbox_messages_dispatch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_mailbox_messages_dispatch ON public.agent_mailbox_messages USING btree (visible_at, created_at) WHERE ((status = 'queued'::public."MailboxMessageStatus") AND (to_agent_id IS NOT NULL));


--
-- Name: idx_queue_jobs_poll; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_queue_jobs_poll ON public.queue_jobs USING btree (topic, status, locked_until) WHERE (status = ANY (ARRAY['pending'::text, 'processing'::text]));


--
-- Name: idx_realtime_events_replay; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realtime_events_replay ON public.realtime_events USING btree (channel_id, id);


--
-- Name: idx_thread_stream_events_replay; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_thread_stream_events_replay ON public.thread_stream_events USING btree (thread_id, id);


--
-- Name: inference_credential_bindings_organization_id_provider_id_c_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_credential_bindings_organization_id_provider_id_c_idx ON public.inference_credential_bindings USING btree (organization_id, provider_id, created_at DESC);


--
-- Name: inference_credential_bindings_provider_id_label_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inference_credential_bindings_provider_id_label_key ON public.inference_credential_bindings USING btree (provider_id, label);


--
-- Name: inference_models_organization_id_provider_id_enabled_lifecy_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_models_organization_id_provider_id_enabled_lifecy_idx ON public.inference_models USING btree (organization_id, provider_id, enabled, lifecycle_status);


--
-- Name: inference_models_provider_id_model_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inference_models_provider_id_model_key ON public.inference_models USING btree (provider_id, model);


--
-- Name: inference_providers_active_credential_binding_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inference_providers_active_credential_binding_id_key ON public.inference_providers USING btree (active_credential_binding_id);


--
-- Name: inference_providers_organization_id_enabled_lifecycle_statu_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_providers_organization_id_enabled_lifecycle_statu_idx ON public.inference_providers USING btree (organization_id, enabled, lifecycle_status);


--
-- Name: inference_providers_organization_id_health_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_providers_organization_id_health_status_idx ON public.inference_providers USING btree (organization_id, health_status);


--
-- Name: inference_providers_organization_id_provider_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_providers_organization_id_provider_key_idx ON public.inference_providers USING btree (organization_id, provider_key);


--
-- Name: inference_routing_profiles_organization_id_enabled_lifecycl_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_routing_profiles_organization_id_enabled_lifecycl_idx ON public.inference_routing_profiles USING btree (organization_id, enabled, lifecycle_status);


--
-- Name: inference_routing_profiles_organization_id_exposure_lifecyc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inference_routing_profiles_organization_id_exposure_lifecyc_idx ON public.inference_routing_profiles USING btree (organization_id, exposure, lifecycle_status);


--
-- Name: inference_routing_profiles_organization_id_label_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inference_routing_profiles_organization_id_label_key ON public.inference_routing_profiles USING btree (organization_id, label);


--
-- Name: integrated_products_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX integrated_products_category_idx ON public.integrated_products USING btree (category);


--
-- Name: integrated_products_health_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX integrated_products_health_status_idx ON public.integrated_products USING btree (health_status);


--
-- Name: integrated_products_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX integrated_products_slug_key ON public.integrated_products USING btree (slug);


--
-- Name: iterations_project_id_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iterations_project_id_position_idx ON public.iterations USING btree (project_id, "position");


--
-- Name: iterations_project_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iterations_project_id_status_idx ON public.iterations USING btree (project_id, status);


--
-- Name: kb_annotation_reactions_agent_emoji_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX kb_annotation_reactions_agent_emoji_key ON public.knowledge_page_annotation_reactions USING btree (annotation_id, agent_id, emoji);


--
-- Name: kb_annotation_reactions_annotation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_annotation_reactions_annotation_idx ON public.knowledge_page_annotation_reactions USING btree (annotation_id);


--
-- Name: kb_annotation_reactions_user_emoji_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX kb_annotation_reactions_user_emoji_key ON public.knowledge_page_annotation_reactions USING btree (annotation_id, user_id, emoji);


--
-- Name: kb_annotations_org_page_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_annotations_org_page_idx ON public.knowledge_page_annotations USING btree (organization_id, page_id);


--
-- Name: kb_annotations_page_kind_parent_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_annotations_page_kind_parent_created_idx ON public.knowledge_page_annotations USING btree (page_id, kind, parent_id, created_at DESC);


--
-- Name: kb_annotations_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_annotations_parent_idx ON public.knowledge_page_annotations USING btree (parent_id);


--
-- Name: knowledge_page_chunks_content_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_content_hash_idx ON public.knowledge_page_chunks USING btree (content_hash);


--
-- Name: knowledge_page_chunks_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_embedding_idx ON public.knowledge_page_chunks USING hnsw (embedding public.vector_cosine_ops) WITH (m='16', ef_construction='64');


--
-- Name: knowledge_page_chunks_org_project_updated_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_org_project_updated_id_idx ON public.knowledge_page_chunks USING btree (organization_id, project_id, updated_at DESC, id DESC);


--
-- Name: knowledge_page_chunks_org_sensitivity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_org_sensitivity_idx ON public.knowledge_page_chunks USING btree (organization_id, sensitivity_tier);


--
-- Name: knowledge_page_chunks_org_visibility_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_org_visibility_updated_idx ON public.knowledge_page_chunks USING btree (organization_id, visibility, updated_at);


--
-- Name: knowledge_page_chunks_page_version_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_page_version_idx ON public.knowledge_page_chunks USING btree (page_id, version_id);


--
-- Name: knowledge_page_chunks_private_to_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_private_to_agent_id_idx ON public.knowledge_page_chunks USING btree (private_to_agent_id);


--
-- Name: knowledge_page_chunks_search_vector_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_search_vector_idx ON public.knowledge_page_chunks USING gin (search_vector);


--
-- Name: knowledge_page_chunks_task_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_chunks_task_id_idx ON public.knowledge_page_chunks USING btree (task_id);


--
-- Name: knowledge_page_chunks_version_chunk_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_page_chunks_version_chunk_key ON public.knowledge_page_chunks USING btree (version_id, chunk_index);


--
-- Name: knowledge_page_links_organization_id_target_title_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_links_organization_id_target_title_idx ON public.knowledge_page_links USING btree (organization_id, target_title);


--
-- Name: knowledge_page_links_source_page_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_links_source_page_id_idx ON public.knowledge_page_links USING btree (source_page_id);


--
-- Name: knowledge_page_links_target_page_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_links_target_page_id_idx ON public.knowledge_page_links USING btree (target_page_id);


--
-- Name: knowledge_page_versions_attachment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_versions_attachment_id_idx ON public.knowledge_page_versions USING btree (attachment_id);


--
-- Name: knowledge_page_versions_page_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_page_versions_page_created_idx ON public.knowledge_page_versions USING btree (page_id, created_at DESC);


--
-- Name: knowledge_page_versions_page_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_page_versions_page_version_key ON public.knowledge_page_versions USING btree (page_id, version_number);


--
-- Name: knowledge_pages_org_project_updated_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_org_project_updated_id_idx ON public.knowledge_pages USING btree (organization_id, project_id, updated_at DESC, id DESC);


--
-- Name: knowledge_pages_org_sensitivity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_org_sensitivity_idx ON public.knowledge_pages USING btree (organization_id, sensitivity_tier);


--
-- Name: knowledge_pages_org_visibility_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_org_visibility_updated_idx ON public.knowledge_pages USING btree (organization_id, visibility, updated_at);


--
-- Name: knowledge_pages_private_to_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_private_to_agent_id_idx ON public.knowledge_pages USING btree (private_to_agent_id);


--
-- Name: knowledge_pages_published_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_published_version_id_idx ON public.knowledge_pages USING btree (published_version_id);


--
-- Name: knowledge_pages_published_version_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_pages_published_version_id_key ON public.knowledge_pages USING btree (published_version_id);


--
-- Name: knowledge_pages_space_parent_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_space_parent_position_idx ON public.knowledge_pages USING btree (space_id, parent_page_id, "position");


--
-- Name: knowledge_pages_summary_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_summary_trgm_idx ON public.knowledge_pages USING gin (summary public.gin_trgm_ops);


--
-- Name: knowledge_pages_task_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_task_id_idx ON public.knowledge_pages USING btree (task_id);


--
-- Name: knowledge_pages_title_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_pages_title_trgm_idx ON public.knowledge_pages USING gin (title public.gin_trgm_ops);


--
-- Name: knowledge_space_members_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_space_members_agent_id_idx ON public.knowledge_space_members USING btree (agent_id);


--
-- Name: knowledge_space_members_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_space_members_organization_id_idx ON public.knowledge_space_members USING btree (organization_id);


--
-- Name: knowledge_space_members_space_id_agent_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_space_members_space_id_agent_id_key ON public.knowledge_space_members USING btree (space_id, agent_id);


--
-- Name: knowledge_space_members_space_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_space_members_space_id_user_id_key ON public.knowledge_space_members USING btree (space_id, user_id);


--
-- Name: knowledge_space_members_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_space_members_user_id_idx ON public.knowledge_space_members USING btree (user_id);


--
-- Name: knowledge_spaces_org_project_updated_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_spaces_org_project_updated_id_idx ON public.knowledge_spaces USING btree (organization_id, project_id, updated_at DESC, id DESC);


--
-- Name: knowledge_spaces_org_sensitivity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_spaces_org_sensitivity_idx ON public.knowledge_spaces USING btree (organization_id, sensitivity_tier);


--
-- Name: knowledge_spaces_org_visibility_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_spaces_org_visibility_updated_idx ON public.knowledge_spaces USING btree (organization_id, visibility, updated_at);


--
-- Name: knowledge_spaces_private_to_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_spaces_private_to_agent_id_idx ON public.knowledge_spaces USING btree (private_to_agent_id);


--
-- Name: mcp_catalog_entries_organization_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_catalog_entries_organization_id_status_idx ON public.mcp_catalog_entries USING btree (organization_id, status);


--
-- Name: mcp_catalog_entries_owner_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mcp_catalog_entries_owner_name_key ON public.mcp_catalog_entries USING btree (owner_user_id, name) WHERE (visibility = 'private'::public."McpCatalogVisibility");


--
-- Name: mcp_catalog_entries_owner_user_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_catalog_entries_owner_user_id_status_idx ON public.mcp_catalog_entries USING btree (owner_user_id, status);


--
-- Name: mcp_catalog_entries_public_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mcp_catalog_entries_public_name_key ON public.mcp_catalog_entries USING btree (name) WHERE (visibility = 'public'::public."McpCatalogVisibility");


--
-- Name: mcp_catalog_entries_visibility_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_catalog_entries_visibility_status_idx ON public.mcp_catalog_entries USING btree (visibility, status);


--
-- Name: mcp_oauth_clients_organization_id_issuer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mcp_oauth_clients_organization_id_issuer_key ON public.mcp_oauth_clients USING btree (organization_id, issuer);


--
-- Name: mcp_server_credential_overrides_instance_id_principal_type__key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mcp_server_credential_overrides_instance_id_principal_type__key ON public.mcp_server_credential_overrides USING btree (instance_id, principal_type, principal_id);


--
-- Name: mcp_server_credential_overrides_principal_type_principal_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_server_credential_overrides_principal_type_principal_id_idx ON public.mcp_server_credential_overrides USING btree (principal_type, principal_id);


--
-- Name: mcp_server_instances_catalog_entry_id_scope_type_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mcp_server_instances_catalog_entry_id_scope_type_scope_id_key ON public.mcp_server_instances USING btree (catalog_entry_id, scope_type, scope_id);


--
-- Name: mcp_server_instances_organization_id_lifecycle_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_server_instances_organization_id_lifecycle_state_idx ON public.mcp_server_instances USING btree (organization_id, lifecycle_state);


--
-- Name: mcp_server_instances_organization_id_scope_type_scope_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_server_instances_organization_id_scope_type_scope_id_idx ON public.mcp_server_instances USING btree (organization_id, scope_type, scope_id);


--
-- Name: message_reactions_message_id_agent_id_emoji_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_reactions_message_id_agent_id_emoji_key ON public.message_reactions USING btree (message_id, agent_id, emoji);


--
-- Name: message_reactions_message_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_reactions_message_id_idx ON public.message_reactions USING btree (message_id);


--
-- Name: message_reactions_message_id_user_id_emoji_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_reactions_message_id_user_id_emoji_key ON public.message_reactions USING btree (message_id, user_id, emoji);


--
-- Name: messages_agent_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_agent_id_created_at_idx ON public.messages USING btree (agent_id, created_at);


--
-- Name: messages_content_fts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_content_fts_idx ON public.messages USING gin (to_tsvector('english'::regconfig, content));


--
-- Name: messages_thread_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_thread_id_created_at_idx ON public.messages USING btree (thread_id, created_at);


--
-- Name: model_pricing_profiles_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX model_pricing_profiles_active_unique ON public.model_pricing_profiles USING btree (organization_id, provider, model_pattern) WHERE (effective_to IS NULL);


--
-- Name: model_pricing_profiles_organization_id_provider_model_patte_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_pricing_profiles_organization_id_provider_model_patte_idx ON public.model_pricing_profiles USING btree (organization_id, provider, model_pattern);


--
-- Name: organization_members_organization_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX organization_members_organization_id_user_id_key ON public.organization_members USING btree (organization_id, user_id);


--
-- Name: page_labels_normalized_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX page_labels_normalized_trgm_idx ON public.page_labels USING gin (normalized_name public.gin_trgm_ops);


--
-- Name: page_labels_org_normalized_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX page_labels_org_normalized_idx ON public.page_labels USING btree (organization_id, normalized_name);


--
-- Name: page_labels_page_normalized_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX page_labels_page_normalized_key ON public.page_labels USING btree (page_id, normalized_name);


--
-- Name: plan_steps_assigned_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plan_steps_assigned_agent_id_status_idx ON public.plan_steps USING btree (assigned_agent_id, status);


--
-- Name: plan_steps_plan_id_sequence_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plan_steps_plan_id_sequence_idx ON public.plan_steps USING btree (plan_id, sequence);


--
-- Name: plan_steps_plan_id_sequence_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plan_steps_plan_id_sequence_key ON public.plan_steps USING btree (plan_id, sequence);


--
-- Name: plans_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plans_agent_id_status_idx ON public.plans USING btree (agent_id, status);


--
-- Name: plans_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plans_organization_id_created_at_idx ON public.plans USING btree (organization_id, created_at DESC);


--
-- Name: plans_organization_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plans_organization_id_status_created_at_idx ON public.plans USING btree (organization_id, status, created_at DESC);


--
-- Name: policy_bindings_actor_type_actor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX policy_bindings_actor_type_actor_id_idx ON public.policy_bindings USING btree (actor_type, actor_id);


--
-- Name: policy_bindings_policy_rule_id_actor_type_actor_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX policy_bindings_policy_rule_id_actor_type_actor_id_key ON public.policy_bindings USING btree (policy_rule_id, actor_type, actor_id);


--
-- Name: policy_rules_organization_id_scope_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX policy_rules_organization_id_scope_id_idx ON public.policy_rules USING btree (organization_id, scope_id);


--
-- Name: policy_rules_organization_id_scope_resource_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX policy_rules_organization_id_scope_resource_type_idx ON public.policy_rules USING btree (organization_id, scope, resource_type);


--
-- Name: product_account_links_organization_id_user_id_product_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_account_links_organization_id_user_id_product_slug_key ON public.product_account_links USING btree (organization_id, user_id, product_slug);


--
-- Name: product_account_links_product_slug_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_account_links_product_slug_status_idx ON public.product_account_links USING btree (product_slug, status);


--
-- Name: product_integration_runs_connector_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_integration_runs_connector_idx ON public.product_integration_runs USING btree (connector_id, requested_at DESC);


--
-- Name: product_integration_runs_knowledge_page_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_integration_runs_knowledge_page_idx ON public.product_integration_runs USING btree (knowledge_page_id);


--
-- Name: product_integration_runs_message_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_integration_runs_message_idx ON public.product_integration_runs USING btree (message_id);


--
-- Name: product_integration_runs_org_product_external_run_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_integration_runs_org_product_external_run_key ON public.product_integration_runs USING btree (organization_id, product_slug, external_run_id) WHERE (external_run_id IS NOT NULL);


--
-- Name: product_integration_runs_scope_requested_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_integration_runs_scope_requested_idx ON public.product_integration_runs USING btree (organization_id, team_id, product_slug, requested_at DESC);


--
-- Name: product_integration_runs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_integration_runs_status_idx ON public.product_integration_runs USING btree (organization_id, product_slug, status);


--
-- Name: product_team_enablements_organization_id_team_id_product_slug_k; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_team_enablements_organization_id_team_id_product_slug_k ON public.product_team_enablements USING btree (organization_id, team_id, product_slug);


--
-- Name: product_team_enablements_product_slug_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_team_enablements_product_slug_enabled_idx ON public.product_team_enablements USING btree (product_slug, enabled);


--
-- Name: product_webhook_secrets_organization_id_product_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_webhook_secrets_organization_id_product_slug_key ON public.product_webhook_secrets USING btree (organization_id, product_slug);


--
-- Name: project_members_project_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_members_project_id_user_id_key ON public.project_members USING btree (project_id, user_id);


--
-- Name: push_credentials_provider_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX push_credentials_provider_key ON public.push_credentials USING btree (provider);


--
-- Name: push_deliveries_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_deliveries_organization_id_created_at_idx ON public.push_deliveries USING btree (organization_id, created_at);


--
-- Name: push_deliveries_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_deliveries_user_id_idx ON public.push_deliveries USING btree (user_id);


--
-- Name: queue_jobs_idempotency_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX queue_jobs_idempotency_key_key ON public.queue_jobs USING btree (idempotency_key);


--
-- Name: queue_jobs_status_enqueued_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX queue_jobs_status_enqueued_at_idx ON public.queue_jobs USING btree (status, enqueued_at);


--
-- Name: realtime_events_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX realtime_events_organization_id_created_at_idx ON public.realtime_events USING btree (organization_id, created_at);


--
-- Name: refresh_tokens_family_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_family_id_idx ON public.refresh_tokens USING btree (family_id);


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX refresh_tokens_token_hash_key ON public.refresh_tokens USING btree (token_hash);


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_user_id_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: resource_locks_agent_id_released_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX resource_locks_agent_id_released_at_idx ON public.resource_locks USING btree (agent_id, released_at);


--
-- Name: resource_locks_organization_id_resource_path_released_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX resource_locks_organization_id_resource_path_released_at_idx ON public.resource_locks USING btree (organization_id, resource_path, released_at);


--
-- Name: runs_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_agent_id_status_idx ON public.runs USING btree (agent_id, status);


--
-- Name: runs_thread_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_thread_id_created_at_idx ON public.runs USING btree (thread_id, created_at);


--
-- Name: runs_trigger_delivery_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX runs_trigger_delivery_id_key ON public.runs USING btree (trigger_delivery_id);


--
-- Name: runs_trigger_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_trigger_id_created_at_idx ON public.runs USING btree (trigger_id, created_at);


--
-- Name: storage_usage_events_organization_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_usage_events_organization_id_occurred_at_idx ON public.storage_usage_events USING btree (organization_id, occurred_at DESC);


--
-- Name: storage_usage_events_organization_id_project_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_usage_events_organization_id_project_id_idx ON public.storage_usage_events USING btree (organization_id, project_id);


--
-- Name: storage_usage_events_organization_id_space_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_usage_events_organization_id_space_id_idx ON public.storage_usage_events USING btree (organization_id, space_id);


--
-- Name: storage_usage_events_organization_id_team_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_usage_events_organization_id_team_id_idx ON public.storage_usage_events USING btree (organization_id, team_id);


--
-- Name: storage_usage_events_organization_id_uploader_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_usage_events_organization_id_uploader_id_idx ON public.storage_usage_events USING btree (organization_id, uploader_id);


--
-- Name: task_events_task_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_events_task_id_created_at_idx ON public.task_events USING btree (task_id, created_at);


--
-- Name: tasks_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_agent_id_status_idx ON public.tasks USING btree (agent_id, status);


--
-- Name: tasks_assignee_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_assignee_agent_id_status_idx ON public.tasks USING btree (assignee_agent_id, status);


--
-- Name: tasks_assignee_user_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_assignee_user_id_status_idx ON public.tasks USING btree (assignee_user_id, status);


--
-- Name: tasks_column_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_column_id_idx ON public.tasks USING btree (column_id);


--
-- Name: tasks_column_id_position_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_column_id_position_idx ON public.tasks USING btree (column_id, "position");


--
-- Name: tasks_iteration_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_iteration_id_idx ON public.tasks USING btree (iteration_id);


--
-- Name: tasks_organization_id_project_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_organization_id_project_id_status_idx ON public.tasks USING btree (organization_id, project_id, status);


--
-- Name: tasks_organization_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_organization_id_status_idx ON public.tasks USING btree (organization_id, status);


--
-- Name: tasks_owner_user_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_owner_user_id_status_idx ON public.tasks USING btree (owner_user_id, status);


--
-- Name: tasks_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_run_id_idx ON public.tasks USING btree (run_id);


--
-- Name: team_members_team_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX team_members_team_id_user_id_key ON public.team_members USING btree (team_id, user_id);


--
-- Name: teams_external_workspace_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX teams_external_workspace_id_key ON public.teams USING btree (external_workspace_id);


--
-- Name: temporary_context_sessions_agent_id_dropped_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX temporary_context_sessions_agent_id_dropped_at_idx ON public.temporary_context_sessions USING btree (agent_id, dropped_at);


--
-- Name: temporary_context_sessions_organization_id_dropped_at_creat_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX temporary_context_sessions_organization_id_dropped_at_creat_idx ON public.temporary_context_sessions USING btree (organization_id, dropped_at, created_at DESC);


--
-- Name: temporary_context_sessions_run_id_dropped_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX temporary_context_sessions_run_id_dropped_at_idx ON public.temporary_context_sessions USING btree (run_id, dropped_at);


--
-- Name: temporary_context_sessions_thread_id_dropped_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX temporary_context_sessions_thread_id_dropped_at_idx ON public.temporary_context_sessions USING btree (thread_id, dropped_at);


--
-- Name: thought_audit_logs_thought_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_audit_logs_thought_id_created_at_idx ON public.thought_audit_logs USING btree (thought_id, created_at);


--
-- Name: thought_links_source_id_target_id_relation_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX thought_links_source_id_target_id_relation_key ON public.thought_links USING btree (source_id, target_id, relation);


--
-- Name: thought_links_target_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_links_target_id_idx ON public.thought_links USING btree (target_id);


--
-- Name: thought_reasonings_organization_id_actor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_reasonings_organization_id_actor_id_idx ON public.thought_reasonings USING btree (organization_id, actor_id);


--
-- Name: thought_reasonings_organization_id_outcome_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_reasonings_organization_id_outcome_idx ON public.thought_reasonings USING btree (organization_id, outcome);


--
-- Name: thought_reasonings_thought_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_reasonings_thought_id_created_at_idx ON public.thought_reasonings USING btree (thought_id, created_at);


--
-- Name: thought_recalls_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_recalls_created_at_idx ON public.thought_recalls USING btree (created_at DESC);


--
-- Name: thought_recalls_output_audience_type_output_audience_id_cre_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_recalls_output_audience_type_output_audience_id_cre_idx ON public.thought_recalls USING btree (output_audience_type, output_audience_id, created_at DESC);


--
-- Name: thought_recalls_requester_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_recalls_requester_user_id_created_at_idx ON public.thought_recalls USING btree (requester_user_id, created_at DESC);


--
-- Name: thought_recalls_session_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_recalls_session_id_created_at_idx ON public.thought_recalls USING btree (session_id, created_at DESC);


--
-- Name: thought_recalls_thought_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thought_recalls_thought_id_idx ON public.thought_recalls USING btree (thought_id);


--
-- Name: thoughts_channel_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_channel_id_created_at_idx ON public.thoughts USING btree (channel_id, created_at);


--
-- Name: thoughts_content_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_content_hash_idx ON public.thoughts USING btree (content_hash);


--
-- Name: thoughts_organization_id_audience_type_audience_id_created__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_organization_id_audience_type_audience_id_created__idx ON public.thoughts USING btree (organization_id, audience_type, audience_id, created_at);


--
-- Name: thoughts_organization_id_memory_type_memory_category_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_organization_id_memory_type_memory_category_created_at ON public.thoughts USING btree (organization_id, memory_type, memory_category, created_at);


--
-- Name: thoughts_organization_id_owner_id_owner_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_organization_id_owner_id_owner_type_idx ON public.thoughts USING btree (organization_id, owner_id, owner_type);


--
-- Name: thoughts_organization_id_visibility_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_organization_id_visibility_created_at_idx ON public.thoughts USING btree (organization_id, visibility, created_at);


--
-- Name: thoughts_private_to_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_private_to_agent_id_idx ON public.thoughts USING btree (private_to_agent_id);


--
-- Name: thoughts_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thoughts_user_id_created_at_idx ON public.thoughts USING btree (user_id, created_at);


--
-- Name: thread_read_states_thread_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX thread_read_states_thread_id_user_id_key ON public.thread_read_states USING btree (thread_id, user_id);


--
-- Name: thread_read_states_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX thread_read_states_user_id_idx ON public.thread_read_states USING btree (user_id);


--
-- Name: threads_channel_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX threads_channel_id_created_at_idx ON public.threads USING btree (channel_id, created_at);


--
-- Name: token_ledger_events_inference_invocation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX token_ledger_events_inference_invocation_id_key ON public.token_ledger_events USING btree (inference_invocation_id);


--
-- Name: token_ledger_events_organization_id_actor_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_actor_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, actor_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_agent_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_agent_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, agent_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_channel_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_channel_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, channel_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_project_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_project_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, project_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_provider_model_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_provider_model_occurred_idx ON public.token_ledger_events USING btree (organization_id, provider, model, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_run_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_run_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, run_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_team_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_team_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, team_id, occurred_at DESC);


--
-- Name: token_ledger_events_organization_id_user_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_organization_id_user_id_occurred_at_idx ON public.token_ledger_events USING btree (organization_id, user_id, occurred_at DESC);


--
-- Name: token_ledger_events_project_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_project_id_occurred_at_idx ON public.token_ledger_events USING btree (project_id, occurred_at DESC);


--
-- Name: token_ledger_events_team_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX token_ledger_events_team_id_occurred_at_idx ON public.token_ledger_events USING btree (team_id, occurred_at DESC);


--
-- Name: tool_bundles_organization_id_bundle_name_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tool_bundles_organization_id_bundle_name_version_key ON public.tool_bundles USING btree (organization_id, bundle_name, version);


--
-- Name: tool_bundles_organization_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_bundles_organization_id_status_idx ON public.tool_bundles USING btree (organization_id, status);


--
-- Name: tool_calls_run_id_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_calls_run_id_started_at_idx ON public.tool_calls USING btree (run_id, started_at);


--
-- Name: tool_grants_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_grants_agent_id_idx ON public.tool_grants USING btree (agent_id);


--
-- Name: tool_grants_role_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_grants_role_id_idx ON public.tool_grants USING btree (role_id);


--
-- Name: tool_grants_tool_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_grants_tool_id_idx ON public.tool_grants USING btree (tool_id);


--
-- Name: tool_registry_entries_builtin_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_builtin_enabled_idx ON public.tool_registry_entries USING btree (builtin, enabled);


--
-- Name: tool_registry_entries_bundle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_bundle_id_idx ON public.tool_registry_entries USING btree (bundle_id);


--
-- Name: tool_registry_entries_mcp_instance_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_mcp_instance_id_idx ON public.tool_registry_entries USING btree (mcp_instance_id);


--
-- Name: tool_registry_entries_org_scope_tool_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tool_registry_entries_org_scope_tool_key ON public.tool_registry_entries USING btree (organization_id, scope_key, tool_id);


--
-- Name: tool_registry_entries_organization_id_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_organization_id_enabled_idx ON public.tool_registry_entries USING btree (organization_id, enabled);


--
-- Name: tool_registry_entries_organization_id_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_organization_id_source_idx ON public.tool_registry_entries USING btree (organization_id, source);


--
-- Name: tool_registry_entries_organization_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_organization_id_status_idx ON public.tool_registry_entries USING btree (organization_id, status);


--
-- Name: tool_registry_entries_tags_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_tags_idx ON public.tool_registry_entries USING gin (tags);


--
-- Name: tool_registry_entries_updated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_registry_entries_updated_at_idx ON public.tool_registry_entries USING btree (updated_at);


--
-- Name: uoa_session_credentials_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX uoa_session_credentials_user_id_idx ON public.uoa_session_credentials USING btree (user_id);


--
-- Name: user_presence_last_seen_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_presence_last_seen_at_idx ON public.user_presence USING btree (last_seen_at);


--
-- Name: user_presence_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_presence_organization_id_idx ON public.user_presence USING btree (organization_id);


--
-- Name: user_status_rules_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_status_rules_agent_id_idx ON public.user_status_rules USING btree (agent_id);


--
-- Name: user_status_rules_channel_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_status_rules_channel_id_idx ON public.user_status_rules USING btree (channel_id);


--
-- Name: user_status_rules_project_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_status_rules_project_id_idx ON public.user_status_rules USING btree (project_id);


--
-- Name: user_status_rules_status_id_priority_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_status_rules_status_id_priority_idx ON public.user_status_rules USING btree (status_id, priority);


--
-- Name: user_status_schedules_kind_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_status_schedules_kind_enabled_idx ON public.user_status_schedules USING btree (kind, enabled);


--
-- Name: user_status_schedules_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_status_schedules_status_id_idx ON public.user_status_schedules USING btree (status_id);


--
-- Name: user_statuses_one_active_manual_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_statuses_one_active_manual_idx ON public.user_statuses USING btree (organization_id, user_id) WHERE is_active;


--
-- Name: user_statuses_organization_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_statuses_organization_id_user_id_idx ON public.user_statuses USING btree (organization_id, user_id);


--
-- Name: user_statuses_user_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_statuses_user_id_is_active_idx ON public.user_statuses USING btree (user_id, is_active);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: web_push_subscriptions_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX web_push_subscriptions_organization_id_idx ON public.web_push_subscriptions USING btree (organization_id);


--
-- Name: web_push_subscriptions_user_id_endpoint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX web_push_subscriptions_user_id_endpoint_key ON public.web_push_subscriptions USING btree (user_id, endpoint);


--
-- Name: web_push_subscriptions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX web_push_subscriptions_user_id_idx ON public.web_push_subscriptions USING btree (user_id);


--
-- Name: workflow_installations_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_installations_organization_id_created_at_idx ON public.workflow_installations USING btree (organization_id, created_at DESC);


--
-- Name: workflow_installations_organization_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_installations_organization_id_status_created_at_idx ON public.workflow_installations USING btree (organization_id, status, created_at DESC);


--
-- Name: workflow_installations_workflow_template_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_installations_workflow_template_id_created_at_idx ON public.workflow_installations USING btree (workflow_template_id, created_at DESC);


--
-- Name: workflow_runs_installation_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_runs_installation_id_created_at_idx ON public.workflow_runs USING btree (installation_id, created_at DESC);


--
-- Name: workflow_runs_organization_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_runs_organization_id_status_created_at_idx ON public.workflow_runs USING btree (organization_id, status, created_at DESC);


--
-- Name: workflow_runs_parent_run_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_runs_parent_run_id_created_at_idx ON public.workflow_runs USING btree (parent_run_id, created_at DESC);


--
-- Name: workflow_runs_retried_from_workflow_run_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_runs_retried_from_workflow_run_id_created_at_idx ON public.workflow_runs USING btree (retried_from_workflow_run_id, created_at DESC);


--
-- Name: workflow_runs_trigger_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_runs_trigger_id_created_at_idx ON public.workflow_runs USING btree (trigger_id, created_at DESC);


--
-- Name: workflow_state_entries_organization_id_updated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_state_entries_organization_id_updated_at_idx ON public.workflow_state_entries USING btree (organization_id, updated_at DESC);


--
-- Name: workflow_state_entries_workflow_installation_id_state_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workflow_state_entries_workflow_installation_id_state_key_key ON public.workflow_state_entries USING btree (workflow_installation_id, state_key);


--
-- Name: workflow_state_entries_workflow_installation_id_updated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_state_entries_workflow_installation_id_updated_at_idx ON public.workflow_state_entries USING btree (workflow_installation_id, updated_at DESC);


--
-- Name: workflow_step_runs_assigned_agent_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_step_runs_assigned_agent_id_status_idx ON public.workflow_step_runs USING btree (assigned_agent_id, status);


--
-- Name: workflow_step_runs_workflow_run_id_sequence_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workflow_step_runs_workflow_run_id_sequence_key ON public.workflow_step_runs USING btree (workflow_run_id, sequence);


--
-- Name: workflow_step_runs_workflow_run_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_step_runs_workflow_run_id_status_idx ON public.workflow_step_runs USING btree (workflow_run_id, status);


--
-- Name: workflow_templates_organization_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_templates_organization_id_created_at_idx ON public.workflow_templates USING btree (organization_id, created_at DESC);


--
-- Name: workflow_templates_organization_id_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_templates_organization_id_name_idx ON public.workflow_templates USING btree (organization_id, name);


--
-- Name: connector_usage_events connector_usage_events_deepwater_cost_boundary; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER connector_usage_events_deepwater_cost_boundary BEFORE INSERT OR UPDATE ON public.connector_usage_events FOR EACH ROW EXECUTE FUNCTION public.nessie_reject_deepwater_usage_cost();


--
-- Name: agent_bindings agent_bindings_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bindings
    ADD CONSTRAINT agent_bindings_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_bindings agent_bindings_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bindings
    ADD CONSTRAINT agent_bindings_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_mailbox_messages agent_mailbox_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mailbox_messages
    ADD CONSTRAINT agent_mailbox_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: agent_trigger_deliveries agent_trigger_deliveries_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_trigger_deliveries
    ADD CONSTRAINT agent_trigger_deliveries_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.agent_triggers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_target_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_target_channel_id_fkey FOREIGN KEY (target_channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: agent_triggers agent_triggers_target_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_target_thread_id_fkey FOREIGN KEY (target_thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: agent_triggers agent_triggers_workflow_installation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_workflow_installation_id_fkey FOREIGN KEY (workflow_installation_id) REFERENCES public.workflow_installations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agents agents_avatar_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_avatar_attachment_id_fkey FOREIGN KEY (avatar_attachment_id) REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: agents agents_parent_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_parent_agent_id_fkey FOREIGN KEY (parent_agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: agents agents_routing_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_routing_profile_id_fkey FOREIGN KEY (routing_profile_id) REFERENCES public.inference_routing_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: board_columns board_columns_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_columns
    ADD CONSTRAINT board_columns_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budgets budgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: call_participants call_participants_call_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_participants
    ADD CONSTRAINT call_participants_call_id_fkey FOREIGN KEY (call_id) REFERENCES public.calls(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: call_participants call_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_participants
    ADD CONSTRAINT call_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: calls calls_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: calls calls_started_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_started_by_id_fkey FOREIGN KEY (started_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channel_members channel_members_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_members
    ADD CONSTRAINT channel_members_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channel_members channel_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_members
    ADD CONSTRAINT channel_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channels channels_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channels channels_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channels channels_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comms_connection_credentials comms_connection_credentials_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_connection_credentials
    ADD CONSTRAINT comms_connection_credentials_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.comms_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comms_events comms_events_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_events
    ADD CONSTRAINT comms_events_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.comms_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comms_resources comms_resources_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_resources
    ADD CONSTRAINT comms_resources_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.comms_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comms_subscriptions comms_subscriptions_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_subscriptions
    ADD CONSTRAINT comms_subscriptions_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.comms_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comms_subscriptions comms_subscriptions_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_subscriptions
    ADD CONSTRAINT comms_subscriptions_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.comms_resources(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: comms_sync_jobs comms_sync_jobs_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_sync_jobs
    ADD CONSTRAINT comms_sync_jobs_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.comms_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comms_sync_jobs comms_sync_jobs_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comms_sync_jobs
    ADD CONSTRAINT comms_sync_jobs_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.comms_resources(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: execution_environment_instances execution_environment_instances_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_instances
    ADD CONSTRAINT execution_environment_instances_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: execution_environment_instances execution_environment_instances_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_instances
    ADD CONSTRAINT execution_environment_instances_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: execution_environment_instances execution_environment_instances_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_instances
    ADD CONSTRAINT execution_environment_instances_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.execution_environment_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: execution_environment_instances execution_environment_instances_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_instances
    ADD CONSTRAINT execution_environment_instances_workflow_run_id_fkey FOREIGN KEY (workflow_run_id) REFERENCES public.workflow_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: execution_environment_instances execution_environment_instances_workflow_step_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_environment_instances
    ADD CONSTRAINT execution_environment_instances_workflow_step_run_id_fkey FOREIGN KEY (workflow_step_run_id) REFERENCES public.workflow_step_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: execution_leases execution_leases_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_leases
    ADD CONSTRAINT execution_leases_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.execution_environment_instances(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: execution_leases execution_leases_runner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_leases
    ADD CONSTRAINT execution_leases_runner_id_fkey FOREIGN KEY (runner_id) REFERENCES public.execution_runners(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: execution_usage_ledger execution_usage_ledger_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_usage_ledger
    ADD CONSTRAINT execution_usage_ledger_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.execution_environment_instances(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: execution_usage_ledger execution_usage_ledger_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_usage_ledger
    ADD CONSTRAINT execution_usage_ledger_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.execution_environment_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: execution_usage_ledger execution_usage_ledger_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_usage_ledger
    ADD CONSTRAINT execution_usage_ledger_workflow_run_id_fkey FOREIGN KEY (workflow_run_id) REFERENCES public.workflow_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: execution_usage_ledger execution_usage_ledger_workflow_step_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_usage_ledger
    ADD CONSTRAINT execution_usage_ledger_workflow_step_run_id_fkey FOREIGN KEY (workflow_step_run_id) REFERENCES public.workflow_step_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: favorites favorites_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedback feedback_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: feedback feedback_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedback feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inference_credential_bindings inference_credential_bindings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_credential_bindings
    ADD CONSTRAINT inference_credential_bindings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inference_credential_bindings inference_credential_bindings_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_credential_bindings
    ADD CONSTRAINT inference_credential_bindings_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.inference_providers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inference_models inference_models_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_models
    ADD CONSTRAINT inference_models_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inference_models inference_models_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_models
    ADD CONSTRAINT inference_models_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.inference_providers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inference_providers inference_providers_active_credential_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_providers
    ADD CONSTRAINT inference_providers_active_credential_binding_id_fkey FOREIGN KEY (active_credential_binding_id) REFERENCES public.inference_credential_bindings(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inference_providers inference_providers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_providers
    ADD CONSTRAINT inference_providers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inference_routing_profiles inference_routing_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_routing_profiles
    ADD CONSTRAINT inference_routing_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integrated_products integrated_products_mcp_catalog_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integrated_products
    ADD CONSTRAINT integrated_products_mcp_catalog_entry_id_fkey FOREIGN KEY (mcp_catalog_entry_id) REFERENCES public.mcp_catalog_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: iterations iterations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iterations
    ADD CONSTRAINT iterations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_page_annotation_reactions knowledge_page_annotation_reactions_annotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_annotation_reactions
    ADD CONSTRAINT knowledge_page_annotation_reactions_annotation_id_fkey FOREIGN KEY (annotation_id) REFERENCES public.knowledge_page_annotations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_page_annotations knowledge_page_annotations_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_annotations
    ADD CONSTRAINT knowledge_page_annotations_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_page_annotations knowledge_page_annotations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_annotations
    ADD CONSTRAINT knowledge_page_annotations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_page_annotations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_page_chunks knowledge_page_chunks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_chunks
    ADD CONSTRAINT knowledge_page_chunks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: knowledge_page_chunks knowledge_page_chunks_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_chunks
    ADD CONSTRAINT knowledge_page_chunks_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.knowledge_pages(id) ON DELETE CASCADE;


--
-- Name: knowledge_page_chunks knowledge_page_chunks_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_chunks
    ADD CONSTRAINT knowledge_page_chunks_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.knowledge_page_versions(id) ON DELETE CASCADE;


--
-- Name: knowledge_page_links knowledge_page_links_source_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_links
    ADD CONSTRAINT knowledge_page_links_source_page_id_fkey FOREIGN KEY (source_page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_page_links knowledge_page_links_target_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_links
    ADD CONSTRAINT knowledge_page_links_target_page_id_fkey FOREIGN KEY (target_page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: knowledge_page_versions knowledge_page_versions_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_page_versions
    ADD CONSTRAINT knowledge_page_versions_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_pages knowledge_pages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_pages
    ADD CONSTRAINT knowledge_pages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_pages knowledge_pages_parent_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_pages
    ADD CONSTRAINT knowledge_pages_parent_page_id_fkey FOREIGN KEY (parent_page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: knowledge_pages knowledge_pages_published_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_pages
    ADD CONSTRAINT knowledge_pages_published_version_id_fkey FOREIGN KEY (published_version_id) REFERENCES public.knowledge_page_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: knowledge_pages knowledge_pages_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_pages
    ADD CONSTRAINT knowledge_pages_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.knowledge_spaces(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_space_members knowledge_space_members_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_space_members
    ADD CONSTRAINT knowledge_space_members_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_space_members knowledge_space_members_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_space_members
    ADD CONSTRAINT knowledge_space_members_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.knowledge_spaces(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_space_members knowledge_space_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_space_members
    ADD CONSTRAINT knowledge_space_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: knowledge_spaces knowledge_spaces_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_spaces
    ADD CONSTRAINT knowledge_spaces_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mcp_catalog_entries mcp_catalog_entries_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_catalog_entries
    ADD CONSTRAINT mcp_catalog_entries_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mcp_catalog_entries mcp_catalog_entries_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_catalog_entries
    ADD CONSTRAINT mcp_catalog_entries_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: mcp_catalog_entries mcp_catalog_entries_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_catalog_entries
    ADD CONSTRAINT mcp_catalog_entries_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: mcp_oauth_clients mcp_oauth_clients_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_oauth_clients
    ADD CONSTRAINT mcp_oauth_clients_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mcp_server_credential_overrides mcp_server_credential_overrides_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_credential_overrides
    ADD CONSTRAINT mcp_server_credential_overrides_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.mcp_server_instances(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mcp_server_instances mcp_server_instances_catalog_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_instances
    ADD CONSTRAINT mcp_server_instances_catalog_entry_id_fkey FOREIGN KEY (catalog_entry_id) REFERENCES public.mcp_catalog_entries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: message_reactions message_reactions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: message_reactions message_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: message_reactions message_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: organization_members organization_members_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: organization_members organization_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: organizations organizations_logo_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_logo_attachment_id_fkey FOREIGN KEY (logo_attachment_id) REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: page_labels page_labels_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_labels
    ADD CONSTRAINT page_labels_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plans plans_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: plans plans_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: plans plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plans plans_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: plans plans_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: plans plans_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: policy_bindings policy_bindings_policy_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_bindings
    ADD CONSTRAINT policy_bindings_policy_rule_id_fkey FOREIGN KEY (policy_rule_id) REFERENCES public.policy_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_account_links product_account_links_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_account_links
    ADD CONSTRAINT product_account_links_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_account_links product_account_links_product_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_account_links
    ADD CONSTRAINT product_account_links_product_slug_fkey FOREIGN KEY (product_slug) REFERENCES public.integrated_products(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_account_links product_account_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_account_links
    ADD CONSTRAINT product_account_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_integration_runs product_integration_runs_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_integration_runs product_integration_runs_connector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_connector_id_fkey FOREIGN KEY (connector_id) REFERENCES public.mcp_server_instances(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_integration_runs product_integration_runs_knowledge_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_knowledge_page_id_fkey FOREIGN KEY (knowledge_page_id) REFERENCES public.knowledge_pages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_integration_runs product_integration_runs_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_integration_runs product_integration_runs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_integration_runs product_integration_runs_product_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_product_slug_fkey FOREIGN KEY (product_slug) REFERENCES public.integrated_products(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_integration_runs product_integration_runs_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_integration_runs product_integration_runs_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_integration_runs product_integration_runs_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_integration_runs
    ADD CONSTRAINT product_integration_runs_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_team_enablements product_team_enablements_configured_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_team_enablements
    ADD CONSTRAINT product_team_enablements_configured_by_user_id_fkey FOREIGN KEY (configured_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_team_enablements product_team_enablements_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_team_enablements
    ADD CONSTRAINT product_team_enablements_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_team_enablements product_team_enablements_product_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_team_enablements
    ADD CONSTRAINT product_team_enablements_product_slug_fkey FOREIGN KEY (product_slug) REFERENCES public.integrated_products(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_team_enablements product_team_enablements_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_team_enablements
    ADD CONSTRAINT product_team_enablements_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_webhook_secrets product_webhook_secrets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook_secrets
    ADD CONSTRAINT product_webhook_secrets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_members project_members_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_members project_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resource_locks resource_locks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_locks
    ADD CONSTRAINT resource_locks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resource_locks resource_locks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_locks
    ADD CONSTRAINT resource_locks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resource_locks resource_locks_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_locks
    ADD CONSTRAINT resource_locks_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: resource_locks resource_locks_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_locks
    ADD CONSTRAINT resource_locks_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: runs runs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: runs runs_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: runs runs_trigger_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_trigger_delivery_id_fkey FOREIGN KEY (trigger_delivery_id) REFERENCES public.agent_trigger_deliveries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: runs runs_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.agent_triggers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: task_events task_events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_assignee_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_agent_id_fkey FOREIGN KEY (assignee_agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_assignee_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_user_id_fkey FOREIGN KEY (assignee_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.board_columns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_iteration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_iteration_id_fkey FOREIGN KEY (iteration_id) REFERENCES public.iterations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: team_members team_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teams teams_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thought_audit_logs thought_audit_logs_thought_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_audit_logs
    ADD CONSTRAINT thought_audit_logs_thought_id_fkey FOREIGN KEY (thought_id) REFERENCES public.thoughts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thought_links thought_links_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_links
    ADD CONSTRAINT thought_links_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.thoughts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thought_links thought_links_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_links
    ADD CONSTRAINT thought_links_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.thoughts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thought_reasonings thought_reasonings_thought_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_reasonings
    ADD CONSTRAINT thought_reasonings_thought_id_fkey FOREIGN KEY (thought_id) REFERENCES public.thoughts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thought_recalls thought_recalls_thought_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thought_recalls
    ADD CONSTRAINT thought_recalls_thought_id_fkey FOREIGN KEY (thought_id) REFERENCES public.thoughts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thoughts thoughts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thoughts
    ADD CONSTRAINT thoughts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thread_read_states thread_read_states_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_read_states
    ADD CONSTRAINT thread_read_states_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thread_read_states thread_read_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_read_states
    ADD CONSTRAINT thread_read_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thread_stream_events thread_stream_events_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_stream_events
    ADD CONSTRAINT thread_stream_events_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: threads threads_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: token_ledger_events token_ledger_events_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_ledger_events
    ADD CONSTRAINT token_ledger_events_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.inference_models(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: token_ledger_events token_ledger_events_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_ledger_events
    ADD CONSTRAINT token_ledger_events_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.inference_providers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tool_calls tool_calls_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tool_grants tool_grants_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_grants
    ADD CONSTRAINT tool_grants_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tool_grants tool_grants_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_grants
    ADD CONSTRAINT tool_grants_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.tool_registry_entries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tool_registry_entries tool_registry_entries_bundle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_registry_entries
    ADD CONSTRAINT tool_registry_entries_bundle_id_fkey FOREIGN KEY (bundle_id) REFERENCES public.tool_bundles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tool_registry_entries tool_registry_entries_mcp_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_registry_entries
    ADD CONSTRAINT tool_registry_entries_mcp_instance_id_fkey FOREIGN KEY (mcp_instance_id) REFERENCES public.mcp_server_instances(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: uoa_session_credentials uoa_session_credentials_last_local_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoa_session_credentials
    ADD CONSTRAINT uoa_session_credentials_last_local_token_id_fkey FOREIGN KEY (last_local_token_id) REFERENCES public.refresh_tokens(id) ON DELETE CASCADE;


--
-- Name: uoa_session_credentials uoa_session_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uoa_session_credentials
    ADD CONSTRAINT uoa_session_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_status_rules user_status_rules_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_rules
    ADD CONSTRAINT user_status_rules_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_status_rules user_status_rules_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_rules
    ADD CONSTRAINT user_status_rules_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_status_rules user_status_rules_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_rules
    ADD CONSTRAINT user_status_rules_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_status_rules user_status_rules_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_rules
    ADD CONSTRAINT user_status_rules_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.user_statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_status_schedules user_status_schedules_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_status_schedules
    ADD CONSTRAINT user_status_schedules_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.user_statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_statuses user_statuses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_statuses
    ADD CONSTRAINT user_statuses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_statuses user_statuses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_statuses
    ADD CONSTRAINT user_statuses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_avatar_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_avatar_attachment_id_fkey FOREIGN KEY (avatar_attachment_id) REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_installations workflow_installations_workflow_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_installations
    ADD CONSTRAINT workflow_installations_workflow_template_id_fkey FOREIGN KEY (workflow_template_id) REFERENCES public.workflow_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflow_runs workflow_runs_installation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_installation_id_fkey FOREIGN KEY (installation_id) REFERENCES public.workflow_installations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflow_runs workflow_runs_parent_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_parent_run_id_fkey FOREIGN KEY (parent_run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_runs workflow_runs_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_runs workflow_runs_plan_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_plan_step_id_fkey FOREIGN KEY (plan_step_id) REFERENCES public.plan_steps(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_runs workflow_runs_retried_from_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_retried_from_workflow_run_id_fkey FOREIGN KEY (retried_from_workflow_run_id) REFERENCES public.workflow_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_runs workflow_runs_trigger_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_trigger_delivery_id_fkey FOREIGN KEY (trigger_delivery_id) REFERENCES public.agent_trigger_deliveries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_runs workflow_runs_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.agent_triggers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_state_entries workflow_state_entries_workflow_installation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_state_entries
    ADD CONSTRAINT workflow_state_entries_workflow_installation_id_fkey FOREIGN KEY (workflow_installation_id) REFERENCES public.workflow_installations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflow_state_entries workflow_state_entries_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_state_entries
    ADD CONSTRAINT workflow_state_entries_workflow_run_id_fkey FOREIGN KEY (workflow_run_id) REFERENCES public.workflow_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_state_entries workflow_state_entries_workflow_step_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_state_entries
    ADD CONSTRAINT workflow_state_entries_workflow_step_run_id_fkey FOREIGN KEY (workflow_step_run_id) REFERENCES public.workflow_step_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_step_runs workflow_step_runs_agent_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_step_runs
    ADD CONSTRAINT workflow_step_runs_agent_run_id_fkey FOREIGN KEY (agent_run_id) REFERENCES public.runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_step_runs workflow_step_runs_assigned_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_step_runs
    ADD CONSTRAINT workflow_step_runs_assigned_agent_id_fkey FOREIGN KEY (assigned_agent_id) REFERENCES public.agents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_step_runs workflow_step_runs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_step_runs
    ADD CONSTRAINT workflow_step_runs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_step_runs workflow_step_runs_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_step_runs
    ADD CONSTRAINT workflow_step_runs_workflow_run_id_fkey FOREIGN KEY (workflow_run_id) REFERENCES public.workflow_runs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict rKXiwBraP3bBVLfCuv48jU310eumMq4qcN1pxwrZbKkh0s04DkqaGxo7ODyVvJn

